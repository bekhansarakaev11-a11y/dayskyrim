import { GameState, createInitialResources, createInitialMarketPrices, CURRENT_SAVE_VERSION } from '../core/gameEngine';
import { createStartingSurvivors } from '../data/survivors';
import { createStartingFactions } from '../data/factions';
import { createStartingLocations } from '../data/locations';
import { createStartingBuildings } from '../data/buildings';
import { generateRandomSurvivor } from '../systems/survivorGenerator';

export function createNewGame(): GameState {
  // 6 именных жителей с проработанной предысторией + 1 случайный странник,
  // сгенерированный процедурно (демонстрирует систему генерации жителей,
  // которая также будет использоваться для будущих новоприбывших в Phase 3+).
  const wanderer = generateRandomSurvivor(1);
  const survivors = [...createStartingSurvivors(), wanderer];

  return {
    version: CURRENT_SAVE_VERSION,
    campaignId: 'last_hearth_of_skyrim',
    day: 1,
    hour: 7, // раннее утро
    maxDays: 30,
    resources: createInitialResources(),
    survivors,
    buildings: createStartingBuildings(),
    factions: createStartingFactions(),
    locations: createStartingLocations(),
    journal: [
      { day: 1, text: 'Небольшая группа беженцев разбила лагерь на окраине Фолкрита. Так начинается история Последнего очага.' },
      { day: 1, text: `${wanderer.name} присоединился(ась) к поселению по пути.` },
    ],
    isGameOver: false,
    endingId: null,
    createdAt: Date.now(),
    lastSavedAt: Date.now(),
    marketPrices: createInitialMarketPrices(),
    caravan: null,
    foodShortageStreak: 0,
    lastHourResourceDelta: {},
  };
}
