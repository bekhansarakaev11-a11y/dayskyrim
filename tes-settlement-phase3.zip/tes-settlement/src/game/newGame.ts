import { GameState, ScenarioId, createInitialResources, createInitialMarketPrices, CURRENT_SAVE_VERSION } from '../core/gameEngine';
import { createStartingSurvivors } from '../data/survivors';
import { createStartingFactions } from '../data/factions';
import { createStartingLocations } from '../data/locations';
import { createStartingBuildings } from '../data/buildings';
import { generateRandomSurvivor } from '../systems/survivorGenerator';
import { SCENARIOS } from '../data/scenarios';
import { Survivor } from '../entities/survivor';

const COMBAT_SKILLS: Array<keyof Survivor['skills']> = ['oneHanded', 'twoHanded', 'archery', 'block'];

export function createNewGame(scenarioId: ScenarioId = 'peaceful_times'): GameState {
  const scenario = SCENARIOS[scenarioId];

  // 6 именных жителей с проработанной предысторией + 1 случайный странник,
  // сгенерированный процедурно (демонстрирует систему генерации жителей,
  // которая также будет использоваться для будущих новоприбывших в Phase 3+).
  const wanderer = generateRandomSurvivor(1);
  let survivors = [...createStartingSurvivors(), wanderer];

  // Сценарий влияет на модификаторы, но НЕ меняет именных персонажей как таковых —
  // только числовые бонусы к их навыкам, как и требуется.
  if (scenario.skillBonus > 0 || scenario.combatSkillBonus > 0) {
    survivors = survivors.map((s) => {
      const skills = { ...s.skills };
      (Object.keys(skills) as Array<keyof Survivor['skills']>).forEach((key) => {
        skills[key] += scenario.skillBonus;
        if (COMBAT_SKILLS.includes(key)) skills[key] += scenario.combatSkillBonus;
      });
      return { ...s, skills };
    });
  }

  const baseResources = createInitialResources();
  const resources = { ...baseResources };
  (Object.keys(resources) as Array<keyof typeof resources>).forEach((key) => {
    if (key === 'gold') return; // золото не урезаем — иначе сценарий "суровая зима" ломает рынок с первого часа
    resources[key] = Math.round(resources[key] * scenario.resourceMultiplier);
  });

  const factions = createStartingFactions().map((f) => ({
    ...f,
    reputation: Math.max(-100, Math.min(100, f.reputation + scenario.factionReputationModifier)),
  }));

  const journal = [
    { day: 1, text: 'Небольшая группа беженцев разбила лагерь на окраине Фолкрита. Так начинается история Последнего очага.' },
    { day: 1, text: `${wanderer.name} присоединился(ась) к поселению по пути.` },
  ];
  if (scenarioId !== 'peaceful_times') {
    journal.push({ day: 1, text: `Сценарий: «${scenario.title}». ${scenario.description}` });
  }

  return {
    version: CURRENT_SAVE_VERSION,
    campaignId: 'last_hearth_of_skyrim',
    day: 1,
    hour: 7, // раннее утро
    maxDays: 30,
    resources,
    survivors,
    buildings: createStartingBuildings(),
    factions,
    locations: createStartingLocations(),
    journal,
    isGameOver: false,
    endingId: null,
    createdAt: Date.now(),
    lastSavedAt: Date.now(),
    marketPrices: createInitialMarketPrices(),
    caravan: null,
    foodShortageStreak: 0,
    lastHourResourceDelta: {},
    expeditions: [],
    activeFactionQuests: [],
    pendingEvent: null,
    scenarioId,
    raidChanceMultiplier: scenario.raidChanceMultiplier,
    negativeEventChanceMultiplier: scenario.negativeEventChanceMultiplier,
  };
}
