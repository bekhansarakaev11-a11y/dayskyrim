export type BuildingType =
  | 'housing' | 'warehouse' | 'kitchen' | 'forge' | 'farm'
  | 'huntingPost' | 'infirmary' | 'alchemyLab' | 'workshop'
  | 'watchtower' | 'palisade' | 'stable' | 'shrine';

export interface ResourceCost {
  food?: number;
  water?: number;
  wood?: number;
  stone?: number;
  ore?: number;
  iron?: number;
  ingredients?: number;
  medicine?: number;
  gold?: number;
  fuel?: number;
}

export interface Building {
  id: string;
  type: BuildingType;
  name: string;
  level: number;
  maxLevel: number;
  cost: ResourceCost;
  buildTimeHours: number;
  isBuilt: boolean;
  isUnderConstruction: boolean;
  constructionProgress: number; // 0-100
  assignedSurvivorIds: string[];
  effectDescription: string;
}
