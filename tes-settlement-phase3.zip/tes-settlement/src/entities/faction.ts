export type FactionId =
  | 'imperialLegion' | 'stormcloaks' | 'darkBrotherhood'
  | 'collegeOfWinterhold' | 'thievesGuild' | 'companions' | 'caravanTraders';

export interface Faction {
  id: FactionId;
  name: string;
  reputation: number; // -100..100
  trust: number;       // 0..100
  isDiscovered: boolean; // Тёмное Братство скрыто до контакта
  isHostileWith: FactionId[];
  completedQuestIds: string[];
  availableQuestIds: string[];
}
