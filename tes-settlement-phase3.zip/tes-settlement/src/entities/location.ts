export type LocationType =
  | 'settlement' | 'city' | 'forest' | 'mine' | 'farm' | 'ruinedHut'
  | 'banditCamp' | 'nordicRuins' | 'cave' | 'tradingPost' | 'unknown';

export interface MapLocation {
  id: string;
  type: LocationType;
  name: string;
  x: number; // 0-100, проценты для стилизованной карты
  y: number;
  isDiscovered: boolean;
  dangerLevel: number; // 0-10
  description: string;
}
