export type ExpeditionGoal = 'explore' | 'loot' | 'huntThreat';

export type ExpeditionOutcomeType =
  | 'loot' | 'discovery' | 'injury' | 'death' | 'encounter' | 'combatWin' | 'combatLoss' | 'rareItem' | 'nothing';

export interface ExpeditionOutcome {
  type: ExpeditionOutcomeType;
  description: string;
}

export interface Expedition {
  id: string;
  locationId: string;
  survivorIds: string[];
  goal: ExpeditionGoal;
  departedAbsoluteHour: number; // day*24+hour на момент отправки
  returnsAtAbsoluteHour: number; // day*24+hour на момент возвращения
  status: 'traveling' | 'completed';
  outcomes: ExpeditionOutcome[]; // заполняется при разрешении
}
