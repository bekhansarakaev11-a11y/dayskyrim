export type Race =
  | 'nord' | 'imperial' | 'breton' | 'redguard' | 'dunmer'
  | 'altmer' | 'bosmer' | 'orsimer' | 'khajiit' | 'argonian';

export type Gender = 'male' | 'female';

export type Profession =
  | 'hunter' | 'gatherer' | 'blacksmith' | 'farmer' | 'healer'
  | 'guard' | 'trader' | 'builder' | 'alchemist' | 'scout' | 'cook';

export type SkillId =
  | 'oneHanded' | 'twoHanded' | 'archery' | 'block'
  | 'smithing' | 'alchemy' | 'hunting' | 'gathering'
  | 'construction' | 'trading' | 'speech' | 'medicine';

export type Trait =
  | 'brave' | 'cowardly' | 'greedy' | 'kind' | 'cruel'
  | 'calm' | 'hotTempered' | 'hardworking' | 'lazy' | 'loyal' | 'independent';

export type CurrentTask =
  | 'idle' | 'cooking' | 'hunting' | 'gathering' | 'woodcutting'
  | 'mining' | 'smithing' | 'building' | 'repairing' | 'healing' | 'guarding'
  | 'trading' | 'exploring' | 'expedition' | 'resting';

export interface SurvivorSkills {
  oneHanded: number;
  twoHanded: number;
  archery: number;
  block: number;
  smithing: number;
  alchemy: number;
  hunting: number;
  gathering: number;
  construction: number;
  trading: number;
  speech: number;
  medicine: number;
}

export interface SurvivorState {
  health: number;      // 0-100
  hunger: number;       // 0-100, 100 = сыт
  fatigue: number;      // 0-100, 0 = бодр
  morale: number;       // 0-100
  fear: number;         // 0-100
  isSick: boolean;
  isInjured: boolean;
}

export interface RelationshipEntry {
  targetId: string;
  type: 'friendship' | 'rivalry' | 'respect' | 'love' | 'kinship';
  value: number; // -100..100
}

export interface Survivor {
  id: string;
  name: string;
  age: number;
  race: Race;
  gender: Gender;
  origin: string;
  profession: Profession;
  skills: SurvivorSkills;
  state: SurvivorState;
  traits: Trait[];
  currentTask: CurrentTask;
  relationships: RelationshipEntry[];
  history: string[]; // короткие записи биографии/журнала, связанные с этим жителем
  inventory: string[]; // itemId[]
  isAlive: boolean;
  joinedOnDay: number;
}

export function createSkillsBase(): SurvivorSkills {
  return {
    oneHanded: 5, twoHanded: 5, archery: 5, block: 5,
    smithing: 5, alchemy: 5, hunting: 5, gathering: 5,
    construction: 5, trading: 5, speech: 5, medicine: 5,
  };
}

export function createStateBase(): SurvivorState {
  return { health: 100, hunger: 100, fatigue: 0, morale: 60, fear: 0, isSick: false, isInjured: false };
}
