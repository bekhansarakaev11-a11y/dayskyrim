export type ItemCategory = 'weapon' | 'armor' | 'potion' | 'ingredient' | 'valuable' | 'tool' | 'misc';

export interface Item {
  id: string;
  name: string;
  category: ItemCategory;
  value: number; // золото
  description: string;
  rarity: 'common' | 'uncommon' | 'rare' | 'unique';
}
