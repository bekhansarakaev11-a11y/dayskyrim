export type EnemyType = 'wolf' | 'bear' | 'bandit' | 'draugr' | 'dragon';

export interface EnemyTemplate {
  type: EnemyType;
  name: string;
  threatLevel: number; // условная "сила" для разрешения столкновений
  isRareEvent: boolean; // дракон — крайне редкое событие, не обычный противник
}

export const ENEMY_TEMPLATES: Record<EnemyType, EnemyTemplate> = {
  wolf: { type: 'wolf', name: 'Волки', threatLevel: 12, isRareEvent: false },
  bear: { type: 'bear', name: 'Медведь', threatLevel: 22, isRareEvent: false },
  bandit: { type: 'bandit', name: 'Бандиты', threatLevel: 18, isRareEvent: false },
  draugr: { type: 'draugr', name: 'Драугры', threatLevel: 28, isRareEvent: false },
  dragon: { type: 'dragon', name: 'Дракон', threatLevel: 90, isRareEvent: true },
};
