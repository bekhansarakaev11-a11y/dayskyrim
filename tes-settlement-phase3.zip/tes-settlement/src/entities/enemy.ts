export type EnemyType = 'skeever' | 'wolf' | 'bear' | 'bandit' | 'draugr' | 'iceTroll' | 'vampire' | 'dragon';

export interface EnemyTemplate {
  type: EnemyType;
  name: string;
  threatLevel: number; // условная "сила" для разрешения столкновений
  isRareEvent: boolean; // дракон — крайне редкое событие, не обычный противник
}

export const ENEMY_TEMPLATES: Record<EnemyType, EnemyTemplate> = {
  skeever: { type: 'skeever', name: 'Скивер', threatLevel: 6, isRareEvent: false },
  wolf: { type: 'wolf', name: 'Волки', threatLevel: 12, isRareEvent: false },
  bear: { type: 'bear', name: 'Медведь', threatLevel: 22, isRareEvent: false },
  bandit: { type: 'bandit', name: 'Бандиты', threatLevel: 18, isRareEvent: false },
  draugr: { type: 'draugr', name: 'Драугры', threatLevel: 28, isRareEvent: false },
  vampire: { type: 'vampire', name: 'Вампир-одиночка', threatLevel: 32, isRareEvent: false },
  iceTroll: { type: 'iceTroll', name: 'Ледяной тролль', threatLevel: 40, isRareEvent: false },
  dragon: { type: 'dragon', name: 'Дракон', threatLevel: 90, isRareEvent: true },
};
