import { ResourceCost } from './building';
import { FactionId } from './faction';

export type EventCategory =
  | 'raid' | 'illness' | 'discovery' | 'wanderer' | 'trade' | 'conflict'
  | 'theft' | 'shortage' | 'wildlife' | 'faction' | 'magic' | 'rare' | 'moral';

/** Единый набор последствий одного исхода события (либо автоматического,
 * либо одного из вариантов выбора игрока). Все поля опциональны — применяется
 * только то, что задано. */
export interface EventOutcome {
  journalText: string;
  resourceChanges?: Partial<Record<keyof Required<ResourceCost>, number>>;
  moraleAllDelta?: number;
  randomSurvivorHealthDelta?: number;
  randomSurvivorMoraleDelta?: number;
  /** Небольшое сближение двух случайных живых жителей (дружба/уважение). */
  relationshipBoost?: boolean;
  /** Небольшое охлаждение отношений двух случайных живых жителей (конфликт). */
  relationshipStrain?: boolean;
  factionReputationDelta?: { factionId: FactionId; amount: number };
}

export interface EventChoice {
  id: string;
  label: string;
  outcome: EventOutcome;
}

export interface GameEvent {
  id: string;
  category: EventCategory;
  title: string;
  description: string;
  weight: number; // относительная вероятность выбора из пула
  minDay?: number; // не раньше какого дня кампании может произойти
  /** Если задано — событие требует решения игрока и приостанавливает
   * течение времени до выбора. Если не задано — исход применяется сразу. */
  choices?: EventChoice[];
  outcome?: EventOutcome;
}
