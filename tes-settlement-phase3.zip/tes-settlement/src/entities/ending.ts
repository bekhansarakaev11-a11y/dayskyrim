export type EndingId =
  | 'prosperous_settlement'
  | 'pyrrhic_victory'
  | 'alliance_of_lands'
  | 'fortress_of_bones'
  | 'trade_route'
  | 'ruined_settlement';

export interface EndingStats {
  daysSurvived: number;
  survivorsAlive: number;
  survivorsTotal: number;
  deathsCount: number;
  averageFactionReputation: number;
  completedQuests: number;
  buildingLevelsTotal: number;
  gold: number;
}

export interface EndingDefinition {
  id: EndingId;
  title: string;
  paragraphs: string[]; // 2-3 абзаца в духе журнальных записей
}
