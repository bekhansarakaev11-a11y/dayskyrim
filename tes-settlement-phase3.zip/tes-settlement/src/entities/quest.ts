import { FactionId } from './faction';
import { TradableResource } from '../core/gameEngine';

export type QuestRewardType = 'gold' | 'resource' | 'item';

export interface QuestReward {
  type: QuestRewardType;
  resourceKey?: TradableResource;
  amount: number;
  itemLabel?: string; // для type='item' — флейвор-название редкого предмета/снаряжения
}

export interface FactionQuest {
  id: string;
  factionId: FactionId;
  title: string;
  description: string;
  minReputation: number; // репутация, необходимая для доступа к заданию
  durationHours: number;
  rewards: QuestReward[];
  reputationReward: number;
  trustReward: number;
  /** Выполнение портит отношения с враждебной фракцией (Империя vs Братья Бури). */
  conflictReputationPenalty?: number;
  /** Скрытые задания (Тёмное Братство) недоступны, пока фракция не "обнаружена". */
  isHidden?: boolean;
  /** Задание одноразовое — после выполнения больше не появляется. */
  repeatable: boolean;
}

export interface ActiveFactionQuest {
  id: string;
  questId: string;
  factionId: FactionId;
  survivorId: string;
  departedAbsoluteHour: number;
  returnsAtAbsoluteHour: number;
  status: 'active' | 'completed';
}
