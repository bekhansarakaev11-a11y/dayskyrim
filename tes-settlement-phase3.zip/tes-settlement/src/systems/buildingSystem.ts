import { GameState } from '../core/gameEngine';
import { Building, ResourceCost } from '../entities/building';
import { BUILDING_TEMPLATES, BUILD_PRIORITY } from '../data/buildings';

export type BuildCostKey = 'wood' | 'stone' | 'iron' | 'gold';
const COST_KEYS: BuildCostKey[] = ['wood', 'stone', 'iron', 'gold'];

/** Полная стоимость постройки/улучшения здания (не почасовой инкремент,
 * а весь объём целиком) — используется для проверки "хватит ли вообще". */
export function getBuildingFullCost(building: Building): Record<BuildCostKey, number> {
  const template = BUILDING_TEMPLATES[building.type];
  const multiplier = building.isBuilt ? building.level : 1; // улучшение дороже с уровнем
  const cost: Record<BuildCostKey, number> = { wood: 0, stone: 0, iron: 0, gold: 0 };
  COST_KEYS.forEach((key) => {
    cost[key] = (template.cost[key as keyof ResourceCost] ?? 0) * multiplier;
  });
  return cost;
}

/** Каких ресурсов не хватает для этого здания прямо сейчас (пусто — хватает всего). */
export function getMissingResources(building: Building, resources: GameState['resources']): Partial<Record<BuildCostKey, number>> {
  const cost = getBuildingFullCost(building);
  const missing: Partial<Record<BuildCostKey, number>> = {};
  COST_KEYS.forEach((key) => {
    if (cost[key] > 0 && resources[key] < cost[key]) {
      missing[key] = cost[key] - resources[key];
    }
  });
  return missing;
}

export function isBuildingAffordable(building: Building, resources: GameState['resources']): boolean {
  return Object.keys(getMissingResources(building, resources)).length === 0;
}

/** Здание, рекомендуемое к постройке по прежней очереди приоритета —
 * теперь это лишь подсказка, а не жёсткое ограничение (раздел 10.4 ТЗ). */
export function getRecommendedBuildingType(state: GameState) {
  return BUILD_PRIORITY.find((type) => !state.buildings.find((b) => b.type === type)?.isBuilt);
}

export interface AssignBuilderResult {
  state: GameState;
  success: boolean;
  message: string;
}

/** Назначает конкретного жителя строителем конкретного здания. Если житель уже
 * строил что-то другое — снимается оттуда. Требует, чтобы ресурсов хватало на
 * полную стоимость постройки (не позволяет начать заведомо невыполнимую стройку). */
export function assignBuilderToBuilding(state: GameState, survivorId: string, buildingId: string): AssignBuilderResult {
  const survivor = state.survivors.find((s) => s.id === survivorId);
  if (!survivor || !survivor.isAlive) {
    return { state, success: false, message: 'Житель недоступен.' };
  }
  if (survivor.currentTask === 'expedition' || survivor.currentTask === 'trading') {
    return { state, success: false, message: 'Житель сейчас в отъезде и не может строить.' };
  }

  const target = state.buildings.find((b) => b.id === buildingId);
  if (!target) return { state, success: false, message: 'Здание не найдено.' };
  if (target.isBuilt && target.level >= target.maxLevel) {
    return { state, success: false, message: 'Здание уже улучшено до максимума.' };
  }

  const missing = getMissingResources(target, state.resources);
  if (Object.keys(missing).length > 0) {
    return { state, success: false, message: 'Не хватает ресурсов для этой стройки.' };
  }

  const buildings = state.buildings.map((b) => {
    if (b.id === buildingId) {
      return { ...b, assignedSurvivorIds: Array.from(new Set([...b.assignedSurvivorIds, survivorId])) };
    }
    // Снимаем жителя со всех прочих строек, если он строил что-то другое.
    if (b.assignedSurvivorIds.includes(survivorId)) {
      return { ...b, assignedSurvivorIds: b.assignedSurvivorIds.filter((id) => id !== survivorId) };
    }
    return b;
  });

  const survivors = state.survivors.map((s) => (s.id === survivorId ? { ...s, currentTask: 'building' as const } : s));

  return {
    state: { ...state, buildings, survivors },
    success: true,
    message: `${survivor.name} назначен(а) строить «${target.name}».`,
  };
}

/** Снимает жителя со стройки (возвращает к "без дела"). */
export function unassignBuilder(state: GameState, survivorId: string): GameState {
  const buildings = state.buildings.map((b) =>
    b.assignedSurvivorIds.includes(survivorId) ? { ...b, assignedSurvivorIds: b.assignedSurvivorIds.filter((id) => id !== survivorId) } : b,
  );
  const survivors = state.survivors.map((s) => (s.id === survivorId && s.currentTask === 'building' ? { ...s, currentTask: 'idle' as const } : s));
  return { ...state, buildings, survivors };
}
