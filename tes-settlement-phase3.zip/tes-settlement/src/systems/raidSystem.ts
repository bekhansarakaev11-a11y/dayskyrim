import { GameState } from '../core/gameEngine';

const BASE_RAID_CHANCE_PER_DAY = 0.06;

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export interface RaidResult {
  state: GameState;
  journalEntries: string[];
}

/** Раз в сутки проверяет риск набега бандитов на поселение. Частокол и
 * сторожевая башня реально снижают шанс набега и его последствия — это их
 * заявленный, но ранее ничем не подкреплённый эффект. Минимальная, но
 * настоящая механика (не "Coming Soon"): угроза, защита, урон или отражение. */
export function maybeRaidSettlement(state: GameState): RaidResult {
  const palisadeLevel = state.buildings.find((b) => b.type === 'palisade' && b.isBuilt)?.level ?? 0;
  const watchtowerLevel = state.buildings.find((b) => b.type === 'watchtower' && b.isBuilt)?.level ?? 0;

  const chanceReduction = clamp(palisadeLevel * 0.12 + watchtowerLevel * 0.1, 0, 0.8);
  const raidChance = BASE_RAID_CHANCE_PER_DAY * (1 - chanceReduction) * state.raidChanceMultiplier;

  if (Math.random() >= raidChance) {
    return { state, journalEntries: [] };
  }

  const guards = state.survivors.filter((s) => s.isAlive && s.currentTask === 'guarding');
  const defensePower =
    guards.reduce((sum, s) => sum + s.skills.oneHanded + s.skills.block, 0) * 0.5 +
    watchtowerLevel * 15 +
    palisadeLevel * 10;

  const attackPower = 20 + Math.random() * 25;

  const journalEntries: string[] = ['На поселение напали бандиты!'];
  let survivors = state.survivors;
  const resources = { ...state.resources };

  if (defensePower >= attackPower) {
    journalEntries.push('Нападение отражено — защита поселения выстояла.');
    if (guards.length > 0) resources.gold += 2 + Math.random() * 5; // трофеи с отбитого набега
  } else {
    const lootedGold = Math.min(resources.gold, 5 + Math.random() * 15);
    resources.gold -= lootedGold;
    journalEntries.push(`Бандиты разграбили поселение и унесли ${lootedGold.toFixed(0)} золота.`);

    const nonGuards = state.survivors.filter((s) => s.isAlive && s.currentTask !== 'guarding');
    if (nonGuards.length > 0 && Math.random() < 0.5) {
      const victim = nonGuards[Math.floor(Math.random() * nonGuards.length)];
      journalEntries.push(`${victim.name} получил(а) ранение при нападении.`);
      survivors = survivors.map((s) =>
        s.id === victim.id
          ? { ...s, state: { ...s.state, health: clamp(s.state.health - (10 + Math.random() * 15), 1, 100), isInjured: true } }
          : s,
      );
    }
  }

  return { state: { ...state, survivors, resources }, journalEntries };
}
