import { GameState } from '../core/gameEngine';
import { EndingId, EndingStats } from '../entities/ending';

export function computeEndingStats(state: GameState): EndingStats {
  const aliveSurvivors = state.survivors.filter((s) => s.isAlive).length;
  const totalSurvivors = state.survivors.length;
  const discoveredFactions = state.factions.filter((f) => f.isDiscovered);
  const averageFactionReputation = discoveredFactions.length
    ? discoveredFactions.reduce((sum, f) => sum + f.reputation, 0) / discoveredFactions.length
    : 0;
  const completedQuests = state.factions.reduce((sum, f) => sum + f.completedQuestIds.length, 0);
  const buildingLevelsTotal = state.buildings.reduce((sum, b) => sum + (b.isBuilt ? b.level : 0), 0);

  return {
    daysSurvived: state.day,
    survivorsAlive: aliveSurvivors,
    survivorsTotal: totalSurvivors,
    deathsCount: totalSurvivors - aliveSurvivors,
    averageFactionReputation,
    completedQuests,
    buildingLevelsTotal,
    gold: state.resources.gold,
  };
}

/** Определяет концовку кампании по финальному состоянию поселения.
 * Проверка идёт по приоритету — от самого специфичного/впечатляющего
 * исхода к базовому, чтобы избежать конфликтов между условиями. */
export function calculateEnding(state: GameState): EndingId {
  const stats = computeEndingStats(state);
  const survivalRate = stats.survivorsTotal > 0 ? stats.survivorsAlive / stats.survivorsTotal : 0;

  if (survivalRate <= 0.15 || stats.survivorsAlive === 0) {
    return 'ruined_settlement';
  }

  const palisade = state.buildings.find((b) => b.type === 'palisade');
  const watchtower = state.buildings.find((b) => b.type === 'watchtower');
  const militaryLevel = (palisade?.isBuilt ? palisade.level : 0) + (watchtower?.isBuilt ? watchtower.level : 0);

  const economyScore =
    stats.gold + state.resources.food * 2 + state.resources.wood + state.resources.stone + state.resources.iron * 3;

  const discoveredFactions = state.factions.filter((f) => f.isDiscovered);
  const allFactionsFriendly = discoveredFactions.length >= 4 && discoveredFactions.every((f) => f.reputation >= 20);
  if (allFactionsFriendly) {
    return 'alliance_of_lands';
  }

  if (stats.completedQuests >= 4 && stats.gold >= 150) {
    return 'trade_route';
  }

  if (militaryLevel >= 4 && economyScore < 120) {
    return 'fortress_of_bones';
  }

  if (survivalRate < 0.6) {
    return 'pyrrhic_victory';
  }

  if (survivalRate >= 0.85 && economyScore >= 150) {
    return 'prosperous_settlement';
  }

  return 'pyrrhic_victory';
}
