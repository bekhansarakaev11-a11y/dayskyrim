import { GameState } from '../core/gameEngine';
import { Expedition, ExpeditionGoal, ExpeditionOutcome } from '../entities/expedition';
import { Survivor } from '../entities/survivor';
import { MapLocation } from '../entities/location';
import { LOCATION_ENEMIES, DRAGON_ENCOUNTER_CHANCE } from '../data/enemies';
import { ENEMY_TEMPLATES } from '../entities/enemy';

const SETTLEMENT_X = 50;
const SETTLEMENT_Y = 55;

function distanceHours(location: MapLocation, buildings: GameState['buildings']): number {
  const dx = location.x - SETTLEMENT_X;
  const dy = location.y - SETTLEMENT_Y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  const stable = buildings.find((b) => b.type === 'stable' && b.isBuilt);
  // Конюшня ("stable") реально ускоряет экспедиции — соответствует её описанию.
  const stableSpeedBonus = 1 - (stable?.level ?? 0) * 0.15; // -15% времени в пути за уровень
  // 1 час на ~5 условных единиц расстояния в одну сторону, туда-обратно, плюс время на месте.
  const base = Math.max(2, Math.round((distance / 5) * 2 + 2));
  return Math.max(1, Math.round(base * stableSpeedBonus));
}

export interface StartExpeditionResult {
  state: GameState;
  success: boolean;
  message: string;
}

const FOOD_PER_PARTICIPANT_PROVISIONS = 1.5;
export { FOOD_PER_PARTICIPANT_PROVISIONS };

export function startExpedition(
  state: GameState,
  locationId: string,
  survivorIds: string[],
  goal: ExpeditionGoal,
): StartExpeditionResult {
  const location = state.locations.find((l) => l.id === locationId);
  if (!location) return { state, success: false, message: 'Локация не найдена.' };
  if (location.type === 'settlement') return { state, success: false, message: 'Это ваше поселение.' };
  if (survivorIds.length === 0) return { state, success: false, message: 'Нужен хотя бы один участник.' };

  const participants = state.survivors.filter((s) => survivorIds.includes(s.id));
  const allEligible = participants.every((s) => s.isAlive && s.currentTask !== 'expedition' && s.state.health > 20);
  if (!allEligible || participants.length !== survivorIds.length) {
    return { state, success: false, message: 'Не все выбранные жители готовы к походу (здоровье или уже заняты).' };
  }

  const durationHours = distanceHours(location, state.buildings);
  const departedAbsoluteHour = state.day * 24 + state.hour;

  // Провиант в дорогу — списывается из общих запасов поселения при отправке.
  // Если еды не хватает, поход всё равно отправляется, но с повышенным риском
  // (Block 10.5) — отряд идёт налегке, без запаса на непредвиденное.
  const provisionsNeeded = survivorIds.length * FOOD_PER_PARTICIPANT_PROVISIONS;
  const hasProvisions = state.resources.food >= provisionsNeeded;
  const resources = {
    ...state.resources,
    food: Math.max(0, state.resources.food - Math.min(provisionsNeeded, state.resources.food)),
  };

  const expedition: Expedition = {
    id: `exp_${Date.now()}`,
    locationId,
    survivorIds,
    goal,
    departedAbsoluteHour,
    returnsAtAbsoluteHour: departedAbsoluteHour + durationHours,
    status: 'traveling',
    outcomes: [],
    hasProvisions,
  };

  const survivors = state.survivors.map((s) =>
    survivorIds.includes(s.id) ? { ...s, currentTask: 'expedition' as const } : s,
  );

  return {
    state: { ...state, resources, survivors, expeditions: [...state.expeditions, expedition] },
    success: true,
    message: hasProvisions
      ? `Экспедиция отправлена к «${location.name}» (~${durationHours}ч в пути).`
      : `Экспедиция отправлена к «${location.name}» (~${durationHours}ч в пути) — но провианта в дорогу не хватило, риск похода выше обычного.`,
  };
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function groupCombatPower(participants: Survivor[]): number {
  return participants.reduce((sum, s) => {
    const eff = clamp(s.state.health, 0, 100) / 100;
    return sum + (s.skills.oneHanded + s.skills.twoHanded + s.skills.archery + s.skills.block) * 0.5 * eff;
  }, 0);
}

function groupGatherPower(participants: Survivor[]): number {
  return participants.reduce((sum, s) => sum + s.skills.hunting + s.skills.gathering + s.skills.trading, 0) / 3;
}

/** Разрешает результат одной экспедиции: столкновения, находки, травмы, открытие локации. */
function resolveOne(state: GameState, expedition: Expedition): { survivors: Survivor[]; resources: GameState['resources']; locations: MapLocation[]; outcomes: ExpeditionOutcome[]; deathIds: string[] } {
  const location = state.locations.find((l) => l.id === expedition.locationId)!;
  const participants = state.survivors.filter((s) => expedition.survivorIds.includes(s.id));
  const outcomes: ExpeditionOutcome[] = [];
  const deathIds: string[] = [];
  let survivors = state.survivors;
  const resources = { ...state.resources };
  let locations = state.locations;

  // Локация становится известной в любом случае — группа там побывала.
  locations = locations.map((l) => (l.id === location.id ? { ...l, isDiscovered: true } : l));
  if (!location.isDiscovered) {
    outcomes.push({ type: 'discovery', description: `Обнаружена новая локация: ${location.name}.` });
  }

  // Крайне редкая встреча с драконом — большое, опасное событие.
  const dragonEncounter = Math.random() < DRAGON_ENCOUNTER_CHANCE;
  const possibleEnemies = dragonEncounter ? ['dragon' as const] : LOCATION_ENEMIES[location.type];
  // Без провианта отряд идёт налегке и measurably слабее в стычках (Block 10.5).
  const provisionsPenalty = expedition.hasProvisions ? 0 : 12;
  const combatPower = groupCombatPower(participants) - provisionsPenalty;

  if (possibleEnemies && possibleEnemies.length > 0 && Math.random() < 0.4 + location.dangerLevel * 0.03) {
    const enemyType = possibleEnemies[Math.floor(Math.random() * possibleEnemies.length)];
    const enemy = ENEMY_TEMPLATES[enemyType];
    outcomes.push({ type: 'encounter', description: `Отряд столкнулся с угрозой: ${enemy.name}.` });
    if (!expedition.hasProvisions) {
      outcomes.push({ type: 'nothing', description: 'Отряд шёл налегке без провианта — силы были на исходе перед стычкой.' });
    }

    const roll = combatPower + Math.random() * 20 - enemy.threatLevel;
    if (roll >= 0) {
      outcomes.push({ type: 'combatWin', description: `Отряд одержал верх над противником (${enemy.name}).` });
      resources.gold += 3 + Math.random() * 8;
      if (enemy.isRareEvent) {
        outcomes.push({ type: 'rareItem', description: 'Отряд принёс из схватки с драконом редкий трофей — драконью кость.' });
      }
    } else {
      const victim = participants[Math.floor(Math.random() * participants.length)];
      const severity = clamp(-roll, 5, 60);
      if (severity > 40 && Math.random() < 0.3) {
        outcomes.push({ type: 'death', description: `${victim.name} погиб(ла) в стычке с угрозой «${enemy.name}».` });
        survivors = survivors.map((s) => (s.id === victim.id ? { ...s, isAlive: false } : s));
        deathIds.push(victim.id);
      } else {
        outcomes.push({ type: 'injury', description: `${victim.name} получил(а) ранение в стычке с «${enemy.name}».` });
        survivors = survivors.map((s) =>
          s.id === victim.id
            ? { ...s, state: { ...s.state, health: clamp(s.state.health - severity, 1, 100), isInjured: true } }
            : s,
        );
      }
    }
  } else if (expedition.goal === 'loot' || expedition.goal === 'explore') {
    const gatherPower = groupGatherPower(participants);
    const lootRoll = Math.random();
    if (lootRoll < 0.15) {
      outcomes.push({ type: 'nothing', description: 'Экспедиция вернулась ни с чем — место оказалось пустым.' });
    } else {
      const goldFound = 2 + gatherPower / 4 + Math.random() * 10;
      const ingredientsFound = Math.random() * 3;
      resources.gold += goldFound;
      resources.ingredients += ingredientsFound;
      outcomes.push({
        type: 'loot',
        description: `Экспедиция принесла ${goldFound.toFixed(0)} септимов и ${ingredientsFound.toFixed(1)} ингредиентов.`,
      });
      if (Math.random() < 0.08) {
        outcomes.push({ type: 'rareItem', description: 'Среди находок — редкий предмет неясного происхождения.' });
      }
    }
  } else {
    outcomes.push({ type: 'nothing', description: 'Отряд обследовал местность — угроз не найдено.' });
  }

  // Усталость от похода.
  survivors = survivors.map((s) => {
    if (!expedition.survivorIds.includes(s.id) || !s.isAlive) return s;
    return { ...s, currentTask: 'idle' as const, state: { ...s.state, fatigue: clamp(s.state.fatigue + 25, 0, 100) } };
  });

  return { survivors, resources, locations, outcomes, deathIds };
}

export interface ResolveExpeditionsResult {
  state: GameState;
  journalAdditions: string[];
  deathIds: string[];
}

/** Проверяет и разрешает все экспедиции, чьё время в пути истекло. Вызывается каждый час. */
export function resolveDueExpeditions(state: GameState): ResolveExpeditionsResult {
  const nowAbsoluteHour = state.day * 24 + state.hour;
  const due = state.expeditions.filter((e) => e.status === 'traveling' && nowAbsoluteHour >= e.returnsAtAbsoluteHour);
  if (due.length === 0) return { state, journalAdditions: [], deathIds: [] };

  let nextState = state;
  const journalAdditions: string[] = [];
  const allDeathIds: string[] = [];

  due.forEach((expedition) => {
    const location = nextState.locations.find((l) => l.id === expedition.locationId);
    const result = resolveOne(nextState, expedition);
    nextState = { ...nextState, survivors: result.survivors, resources: result.resources, locations: result.locations };
    journalAdditions.push(`Экспедиция к «${location?.name ?? '?'}» вернулась.`);
    result.outcomes.forEach((o) => journalAdditions.push(o.description));
    allDeathIds.push(...result.deathIds);
  });

  nextState = {
    ...nextState,
    expeditions: nextState.expeditions.filter((e) => !due.find((d) => d.id === e.id)),
  };

  return { state: nextState, journalAdditions, deathIds: allDeathIds };
}
