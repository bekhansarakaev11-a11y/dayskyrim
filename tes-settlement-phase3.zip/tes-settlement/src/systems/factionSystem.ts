import { GameState } from '../core/gameEngine';
import { FactionQuest, ActiveFactionQuest } from '../entities/quest';
import { FACTION_QUESTS } from '../data/quests';
import { FactionId } from '../entities/faction';

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/** Задания, доступные для фракции прямо сейчас: репутация достаточна,
 * задание ещё не выполнено (если одноразовое), и оно не скрыто (либо фракция уже обнаружена). */
export function getAvailableQuests(state: GameState, factionId: FactionId): FactionQuest[] {
  const faction = state.factions.find((f) => f.id === factionId);
  if (!faction || !faction.isDiscovered) return [];

  return FACTION_QUESTS.filter((q) => {
    if (q.factionId !== factionId) return false;
    if (q.minReputation > faction.reputation) return false;
    if (!q.repeatable && faction.completedQuestIds.includes(q.id)) return false;
    const alreadyActive = state.activeFactionQuests.some((a) => a.questId === q.id && a.status === 'active');
    if (alreadyActive) return false;
    return true;
  });
}

export interface StartQuestResult {
  state: GameState;
  success: boolean;
  message: string;
}

export function startFactionQuest(state: GameState, questId: string, survivorId: string): StartQuestResult {
  const quest = FACTION_QUESTS.find((q) => q.id === questId);
  if (!quest) return { state, success: false, message: 'Задание не найдено.' };

  const available = getAvailableQuests(state, quest.factionId);
  if (!available.find((q) => q.id === questId)) {
    return { state, success: false, message: 'Задание сейчас недоступно.' };
  }

  const survivor = state.survivors.find((s) => s.id === survivorId);
  if (!survivor || !survivor.isAlive || survivor.currentTask === 'expedition' || survivor.currentTask === 'trading') {
    return { state, success: false, message: 'Житель не может отправиться на задание.' };
  }

  const departedAbsoluteHour = state.day * 24 + state.hour;
  const active: ActiveFactionQuest = {
    id: `fq_${Date.now()}`,
    questId,
    factionId: quest.factionId,
    survivorId,
    departedAbsoluteHour,
    returnsAtAbsoluteHour: departedAbsoluteHour + quest.durationHours,
    status: 'active',
  };

  const survivors = state.survivors.map((s) => (s.id === survivorId ? { ...s, currentTask: 'trading' as const } : s));

  return {
    state: { ...state, survivors, activeFactionQuests: [...state.activeFactionQuests, active] },
    success: true,
    message: `«${quest.title}» начато — вернётся через ~${quest.durationHours}ч.`,
  };
}

export interface ResolveQuestsResult {
  state: GameState;
  journalAdditions: string[];
}

/** Разрешает все задания фракций, чьё время истекло: начисляет награды,
 * репутацию/доверие, применяет конфликт (Империя vs Братья Бури), может
 * обнаружить Тёмное Братство при первом выполненном тайном контракте. */
export function resolveDueFactionQuests(state: GameState): ResolveQuestsResult {
  const nowAbsoluteHour = state.day * 24 + state.hour;
  const due = state.activeFactionQuests.filter((a) => a.status === 'active' && nowAbsoluteHour >= a.returnsAtAbsoluteHour);
  if (due.length === 0) return { state, journalAdditions: [] };

  const resources = { ...state.resources };
  let survivors = state.survivors;
  let factions = state.factions;
  const journalAdditions: string[] = [];

  due.forEach((active) => {
    const quest = FACTION_QUESTS.find((q) => q.id === active.questId);
    if (!quest) return;

    quest.rewards.forEach((reward) => {
      if (reward.type === 'gold') resources.gold += reward.amount;
      else if (reward.type === 'resource' && reward.resourceKey) {
        resources[reward.resourceKey] += reward.amount;
      } else if (reward.type === 'item') {
        survivors = survivors.map((s) =>
          s.id === active.survivorId ? { ...s, inventory: [...s.inventory, reward.itemLabel ?? 'редкий предмет'] } : s,
        );
      }
    });

    factions = factions.map((f) => {
      if (f.id !== quest.factionId) return f;
      return {
        ...f,
        reputation: clamp(f.reputation + quest.reputationReward, -100, 100),
        trust: clamp(f.trust + quest.trustReward, 0, 100),
        completedQuestIds: quest.repeatable ? f.completedQuestIds : [...f.completedQuestIds, quest.id],
      };
    });

    // Конфликт Империя vs Братья Бури: услуга одной стороне портит отношения с другой.
    if (quest.conflictReputationPenalty) {
      const hostileTargets = factions.find((f) => f.id === quest.factionId)?.isHostileWith ?? [];
      const penalty = quest.conflictReputationPenalty;
      factions = factions.map((f) =>
        hostileTargets.includes(f.id) ? { ...f, reputation: clamp(f.reputation - penalty, -100, 100) } : f,
      );
    }

    survivors = survivors.map((s) => (s.id === active.survivorId ? { ...s, currentTask: 'idle' as const } : s));
    journalAdditions.push(`Задание «${quest.title}» для фракции «${factions.find((f) => f.id === quest.factionId)?.name}» выполнено.`);
  });

  return {
    state: {
      ...state,
      resources,
      survivors,
      factions,
      activeFactionQuests: state.activeFactionQuests.filter((a) => !due.find((d) => d.id === a.id)),
    },
    journalAdditions,
  };
}

const DARK_BROTHERHOOD_CONTACT_CHANCE = 0.02;

/** Раз в сутки небольшой шанс тайного контакта, раскрывающего Тёмное Братство.
 * До этого момента фракция не отображается в обычном списке — соответствует
 * требованию "не показывай кнопкой меню, используй события и скрытые контакты". */
export function maybeRevealDarkBrotherhood(state: GameState): { state: GameState; journalEntry: string | null } {
  const faction = state.factions.find((f) => f.id === 'darkBrotherhood');
  if (!faction || faction.isDiscovered) return { state, journalEntry: null };

  if (Math.random() < DARK_BROTHERHOOD_CONTACT_CHANCE) {
    const factions = state.factions.map((f) => (f.id === 'darkBrotherhood' ? { ...f, isDiscovered: true } : f));
    return {
      state: { ...state, factions },
      journalEntry: 'Ночью к поселению приходил незнакомец в тёмном плаще и оставил записку с чёрной печатью...',
    };
  }
  return { state, journalEntry: null };
}
