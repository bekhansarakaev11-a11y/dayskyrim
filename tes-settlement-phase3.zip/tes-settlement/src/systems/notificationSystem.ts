export type ToastKind = 'danger' | 'success';

export interface Toast {
  id: string;
  kind: ToastKind;
  icon: string;
  text: string;
}

interface Rule {
  test: (text: string) => boolean;
  kind: ToastKind;
  icon: string;
}

// Порядок важен: более специфичные правила (например, "отражено") должны
// проверяться раньше общих ("напали"), иначе отражённый набег ошибочно
// подсветится как поражение.
const RULES: Rule[] = [
  { test: (t) => t.includes('погиб'), kind: 'danger', icon: '💀' },
  { test: (t) => t.toLowerCase().includes('нападение отражено'), kind: 'success', icon: '🛡️' },
  { test: (t) => t.includes('разграбили'), kind: 'danger', icon: '⚔️' },
  { test: (t) => t.includes('заболел'), kind: 'danger', icon: '🤒' },
  { test: (t) => t.includes('выполнено'), kind: 'success', icon: '✅' },
  { test: (t) => t.toLowerCase().includes('построено новое здание'), kind: 'success', icon: '🏗️' },
];

/** Превращает новые (ещё не показанные) записи журнала в короткие
 * visual-уведомления для значимых событий — смерть, набег, эпидемия,
 * выполненное задание. Рядовые записи (склад переполнен и т.п.) не
 * порождают уведомлений, чтобы не перегружать игрока. */
export function classifyNewJournalEntries(newTexts: string[]): Toast[] {
  const toasts: Toast[] = [];
  newTexts.forEach((text, i) => {
    const rule = RULES.find((r) => r.test(text));
    if (rule) {
      toasts.push({ id: `toast_${Date.now()}_${i}`, kind: rule.kind, icon: rule.icon, text });
    }
  });
  return toasts;
}
