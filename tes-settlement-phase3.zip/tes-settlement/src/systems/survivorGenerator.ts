import { Survivor, Race, Gender, Profession, Trait, createSkillsBase, createStateBase } from '../entities/survivor';

const MALE_NAMES = ['Бранд', 'Ульфрик', 'Стенгар', 'Рагнар', 'Хродгар', 'Свейн', 'Эрик', 'Гуннар'];
const FEMALE_NAMES = ['Астрид', 'Хильда', 'Гуннхильд', 'Сванхильд', 'Идгрод', 'Фрида', 'Рунхильд', 'Тира'];

const RACES: Race[] = ['nord', 'imperial', 'breton', 'redguard', 'dunmer', 'altmer', 'bosmer', 'orsimer', 'khajiit', 'argonian'];
const PROFESSIONS: Profession[] = ['hunter', 'gatherer', 'blacksmith', 'farmer', 'healer', 'guard', 'trader', 'builder', 'alchemist', 'scout', 'cook'];
const ALL_TRAITS: Trait[] = ['brave', 'cowardly', 'greedy', 'kind', 'cruel', 'calm', 'hotTempered', 'hardworking', 'lazy', 'loyal', 'independent'];

const ORIGINS = [
  'Беженец из разграбленной деревни под Хелгеном.',
  'Отбился от торгового каравана во время нападения бандитов.',
  'Бывший стражник, покинувший службу.',
  'Странник, искавший работу в этих краях.',
  'Пережил кораблекрушение у берегов Скайрима.',
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomSkillsForProfession(profession: Profession): Survivor['skills'] {
  const skills = createSkillsBase();
  const boost = (key: keyof Survivor['skills'], amount: number) => {
    skills[key] = Math.min(60, skills[key] + amount);
  };
  switch (profession) {
    case 'hunter': boost('hunting', randomInt(15, 30)); boost('archery', randomInt(10, 20)); break;
    case 'gatherer': boost('gathering', randomInt(15, 30)); break;
    case 'blacksmith': boost('smithing', randomInt(20, 35)); break;
    case 'farmer': boost('gathering', randomInt(10, 20)); break;
    case 'healer': boost('medicine', randomInt(20, 35)); break;
    case 'guard': boost('oneHanded', randomInt(15, 30)); boost('block', randomInt(10, 20)); break;
    case 'trader': boost('trading', randomInt(20, 35)); boost('speech', randomInt(10, 20)); break;
    case 'builder': boost('construction', randomInt(20, 35)); break;
    case 'alchemist': boost('alchemy', randomInt(20, 35)); break;
    case 'scout': boost('archery', randomInt(10, 20)); boost('gathering', randomInt(10, 15)); break;
    case 'cook': boost('trading', randomInt(5, 10)); break;
  }
  return skills;
}

let generatedCounter = 0;

/** Создаёт случайного жителя — используется как для стартового набора, так и для будущих
 * прибывших (события, экспедиции — Phase 3+). */
export function generateRandomSurvivor(joinedOnDay: number): Survivor {
  generatedCounter += 1;
  const gender: Gender = Math.random() < 0.5 ? 'male' : 'female';
  const name = gender === 'male' ? pick(MALE_NAMES) : pick(FEMALE_NAMES);
  const race = pick(RACES);
  const profession = pick(PROFESSIONS);
  const traits: Trait[] = [];
  const traitCount = randomInt(1, 2);
  while (traits.length < traitCount) {
    const t = pick(ALL_TRAITS);
    if (!traits.includes(t)) traits.push(t);
  }

  return {
    id: `survivor_gen_${Date.now()}_${generatedCounter}`,
    name,
    age: randomInt(18, 52),
    race,
    gender,
    origin: pick(ORIGINS),
    profession,
    skills: randomSkillsForProfession(profession),
    state: createStateBase(),
    traits,
    currentTask: 'idle',
    relationships: [],
    history: [`Присоединился к поселению на ${joinedOnDay} день.`],
    inventory: [],
    isAlive: true,
    joinedOnDay,
  };
}
