import { Survivor, Race, Gender, Profession, Trait, createSkillsBase, createStateBase } from '../entities/survivor';

const RACES: Race[] = ['nord', 'imperial', 'breton', 'redguard', 'dunmer', 'altmer', 'bosmer', 'orsimer', 'khajiit', 'argonian'];
const PROFESSIONS: Profession[] = ['hunter', 'gatherer', 'blacksmith', 'farmer', 'healer', 'guard', 'trader', 'builder', 'alchemist', 'scout', 'cook'];
const ALL_TRAITS: Trait[] = ['brave', 'cowardly', 'greedy', 'kind', 'cruel', 'calm', 'hotTempered', 'hardworking', 'lazy', 'loyal', 'independent'];

// Имена по расам — раса персонажа теперь видна не только в статистике, но и в облике.
const NAMES_BY_RACE: Record<Race, { male: string[]; female: string[] }> = {
  nord: { male: ['Бранд', 'Ульфрик', 'Стенгар', 'Рагнар', 'Хродгар', 'Свейн'], female: ['Астрид', 'Хильда', 'Гуннхильд', 'Сванхильд', 'Фрида', 'Рунхильд'] },
  imperial: { male: ['Марк', 'Тит', 'Виторий', 'Гай', 'Кассий'], female: ['Юлия', 'Клавдия', 'Ливия', 'Валерия', 'Октавия'] },
  breton: { male: ['Гийом', 'Амьен', 'Реналд', 'Друан'], female: ['Мариэль', 'Изабо', 'Селина', 'Одетта'] },
  redguard: { male: ['Джамал', 'Хасир', 'Тарик', 'Азим'], female: ['Лайла', 'Сафия', 'Зейнаб', 'Амира'] },
  dunmer: { male: ['Врен', 'Далин', 'Ондрел', 'Сарети'], female: ['Дрель', 'Ллеверас', 'Ралвен', 'Меруне'] },
  altmer: { male: ['Эленвен', 'Эстормо', 'Валиндор', 'Ромлин'], female: ['Айренн', 'Ситис', 'Валерин', 'Нирис'] },
  bosmer: { male: ['Атиан', 'Гилрайт', 'Талмур', 'Ниррен'], female: ['Ниведа', 'Синдри', 'Файрель', 'Тавиэль'] },
  orsimer: { male: ['Голдак', 'Мограш', 'Ургаш', 'Бургол'], female: ['Байра', 'Шелма', 'Ургаша', 'Мура'] },
  khajiit: { male: ['Джо-хаб', 'Ат-Хазар', 'Дро-Марат', 'Ктар'], female: ['Ма-Кара', 'Хаджира', 'Зейра', 'Тахира'] },
  argonian: { male: ['Аск-Слепящий-Взгляд', 'Дрел-Ду', 'Соко-Тат', 'Шес-Кел'], female: ['Гар-Джист', 'Тарий-Уй', 'Найя-Ирис', 'Виа-Кел'] },
};

// Предыстории теперь привязаны к расе — раса значит не только ярлык, но и биографию.
const ORIGINS_BY_RACE: Partial<Record<Race, string[]>> = {
  nord: ['Беженец из разграбленной деревни под Хелгеном.', 'Отбился от торгового каравана во время нападения бандитов.'],
  imperial: ['Бывший имперский стражник, покинувший службу после ранения.', 'Чиновник из Сиродила, застрявший в Скайриме из-за войны.'],
  breton: ['Странствующий учёный из Хай-Рока, изучающий местные руины.', 'Бретонец, бывший слуга знатного дома Хай-Рока, ушедший от прежних хозяев.'],
  redguard: ['Наёмник из Хаммерфелла, потерявший отряд в стычке с бандитами.', 'Редгард, потомок хаммерфеллских мореходов, чей корабль разбился у берегов Скайрима.'],
  dunmer: ['Беженец из разорённого Морровинда, ищущий новый дом.', 'Пережил извержение Красной Горы и с тех пор скитается по северу.'],
  altmer: ['Изгнанник из альдмерского общества, не разделяющий взгляды Талмора.', 'Альтмер-учёный, увлечённый изучением северных культур.'],
  bosmer: ['Охотник из Валенвуда, забредший далеко на север в поисках дичи.', 'Бывший лесной разведчик из Валенвуда, ищущий заработок вдали от дома.'],
  orsimer: ['Изгнан из родного оплота (стронгхолда) за нарушение обычаев.', 'Кузнец-орк, странствующий в поисках достойной кузни.'],
  khajiit: ['Странствующий торговец-каджит, отбившийся от каравана.', 'Каджит-скиталец, ищущий место, где его ремесло будет цениться.'],
  argonian: ['Аргонианин из Чернотопья, покинувший болота ради лучшей доли.', 'Бывший портовый работник-аргонианин, решивший попытать счастья на суше вдали от родных топей.'],
};

const FALLBACK_ORIGINS = [
  'Странник, искавший работу в этих краях.',
  'Пережил кораблекрушение у берегов Скайрима.',
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomSkillsForProfession(profession: Profession): Survivor['skills'] {
  const skills = createSkillsBase();
  const boost = (key: keyof Survivor['skills'], amount: number) => {
    skills[key] = Math.min(60, skills[key] + amount);
  };
  switch (profession) {
    case 'hunter': boost('hunting', randomInt(15, 30)); boost('archery', randomInt(10, 20)); break;
    case 'gatherer': boost('gathering', randomInt(15, 30)); break;
    case 'blacksmith': boost('smithing', randomInt(20, 35)); break;
    case 'farmer': boost('gathering', randomInt(10, 20)); break;
    case 'healer': boost('medicine', randomInt(20, 35)); break;
    case 'guard': boost('oneHanded', randomInt(15, 30)); boost('block', randomInt(10, 20)); break;
    case 'trader': boost('trading', randomInt(20, 35)); boost('speech', randomInt(10, 20)); break;
    case 'builder': boost('construction', randomInt(20, 35)); break;
    case 'alchemist': boost('alchemy', randomInt(20, 35)); break;
    case 'scout': boost('archery', randomInt(10, 20)); boost('gathering', randomInt(10, 15)); break;
    case 'cook': boost('trading', randomInt(5, 10)); break;
  }
  return skills;
}

let generatedCounter = 0;

/** Создаёт случайного жителя — используется как для стартового набора, так и для будущих
 * прибывших (события, экспедиции). Раса влияет на имя и происхождение, а не только
 * фигурирует как отвлечённый ярлык в характеристиках. */
export function generateRandomSurvivor(joinedOnDay: number): Survivor {
  generatedCounter += 1;
  const gender: Gender = Math.random() < 0.5 ? 'male' : 'female';
  const race = pick(RACES);
  const namePool = NAMES_BY_RACE[race];
  const name = gender === 'male' ? pick(namePool.male) : pick(namePool.female);
  const profession = pick(PROFESSIONS);
  const traits: Trait[] = [];
  const traitCount = randomInt(1, 2);
  while (traits.length < traitCount) {
    const t = pick(ALL_TRAITS);
    if (!traits.includes(t)) traits.push(t);
  }

  const originPool = ORIGINS_BY_RACE[race] ?? FALLBACK_ORIGINS;

  return {
    id: `survivor_gen_${Date.now()}_${generatedCounter}`,
    name,
    age: randomInt(18, 52),
    race,
    gender,
    origin: pick(originPool),
    profession,
    skills: randomSkillsForProfession(profession),
    state: createStateBase(),
    traits,
    currentTask: 'idle',
    relationships: [],
    history: [`Присоединился к поселению на ${joinedOnDay} день.`],
    inventory: [],
    isAlive: true,
    joinedOnDay,
  };
}
