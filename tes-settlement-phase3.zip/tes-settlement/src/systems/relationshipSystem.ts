import { Survivor, RelationshipEntry } from '../entities/survivor';

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

export function getRelationshipValue(survivor: Survivor, targetId: string): number {
  return survivor.relationships.find((r) => r.targetId === targetId)?.value ?? 0;
}

function setRelationship(survivor: Survivor, targetId: string, delta: number, defaultType: RelationshipEntry['type']): Survivor {
  const existing = survivor.relationships.find((r) => r.targetId === targetId);
  if (existing) {
    return {
      ...survivor,
      relationships: survivor.relationships.map((r) =>
        r.targetId === targetId ? { ...r, value: clamp(r.value + delta, -100, 100) } : r,
      ),
    };
  }
  return {
    ...survivor,
    relationships: [...survivor.relationships, { targetId, type: defaultType, value: clamp(delta, -100, 100) }],
  };
}

/** Симметрично меняет отношения между двумя жителями (в обе стороны). */
export function adjustRelationship(
  survivors: Survivor[],
  aId: string,
  bId: string,
  delta: number,
  type: RelationshipEntry['type'] = 'friendship',
): Survivor[] {
  return survivors.map((s) => {
    if (s.id === aId) return setRelationship(s, bId, delta, type);
    if (s.id === bId) return setRelationship(s, aId, delta, type);
    return s;
  });
}

/** Небольшое сближение жителей, работающих сообща над одной задачей —
 * совместный труд укрепляет дружбу (раздел 20 ТЗ: отношения формируются
 * повседневной жизнью поселения и влияют на события). */
export function applyHourlyBonding(survivors: Survivor[]): Survivor[] {
  const groups = new Map<string, Survivor[]>();
  survivors.forEach((s) => {
    if (!s.isAlive || s.currentTask === 'idle' || s.currentTask === 'resting') return;
    const key = s.currentTask;
    groups.set(key, [...(groups.get(key) ?? []), s]);
  });

  let result = survivors;
  groups.forEach((group) => {
    if (group.length < 2) return;
    for (let i = 0; i < group.length - 1; i += 1) {
      result = adjustRelationship(result, group[i].id, group[i + 1].id, 0.15, 'friendship');
    }
  });
  return result;
}

export interface GriefResult {
  survivors: Survivor[];
  journalEntries: string[];
}

/** Когда житель погибает, его близкие (высокое значение отношений) переживают
 * утрату — падает мораль (пример из раздела 20 ТЗ: "если погиб близкий друг
 * персонажа — падает мораль, может появиться уникальное событие"). */
export function applyGriefForDeaths(
  survivors: Survivor[],
  deceasedIds: string[],
  deceasedNames: Map<string, string>,
): GriefResult {
  if (deceasedIds.length === 0) return { survivors, journalEntries: [] };

  const journalEntries: string[] = [];
  const result = survivors.map((s) => {
    if (!s.isAlive || deceasedIds.includes(s.id)) return s;

    let moraleDelta = 0;
    deceasedIds.forEach((deadId) => {
      const closeness = getRelationshipValue(s, deadId);
      if (closeness > 60) {
        moraleDelta -= 6;
        journalEntries.push(`${s.name} тяжело переживает гибель ${deceasedNames.get(deadId) ?? 'близкого человека'}.`);
      } else if (closeness > 25) {
        moraleDelta -= 3;
        journalEntries.push(`${s.name} опечален(а) известием о гибели ${deceasedNames.get(deadId) ?? 'знакомого'}.`);
      }
    });

    if (moraleDelta === 0) return s;
    return { ...s, state: { ...s.state, morale: clamp(s.state.morale + moraleDelta, 0, 100) } };
  });

  return { survivors: result, journalEntries };
}
