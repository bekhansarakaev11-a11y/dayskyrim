import { GameState } from '../core/gameEngine';
import { Survivor, CurrentTask } from '../entities/survivor';
import { Building, BuildingType, ResourceCost } from '../entities/building';
import { BUILDING_TEMPLATES } from '../data/buildings';
import { getHousingCapacity } from './economySystem';

/** Задачи, доступные игроку для ручного назначения. */
export const ASSIGNABLE_TASKS: CurrentTask[] = [
  'hunting', 'gathering', 'woodcutting', 'mining', 'smithing',
  'guarding', 'cooking', 'healing', 'resting', 'idle',
];

export const TASK_LABELS: Record<CurrentTask, string> = {
  idle: 'Без дела',
  cooking: 'Готовка',
  hunting: 'Охота',
  gathering: 'Сбор',
  woodcutting: 'Заготовка леса',
  mining: 'Добыча руды',
  smithing: 'Кузнечное дело',
  building: 'Строительство',
  repairing: 'Ремонт',
  healing: 'Врачевание и алхимия',
  guarding: 'Охрана',
  trading: 'Торговля',
  exploring: 'Разведка',
  expedition: 'Экспедиция',
  resting: 'Отдых',
};

export function assignTask(state: GameState, survivorId: string, task: CurrentTask): GameState {
  const survivors = state.survivors.map((s) => {
    if (s.id !== survivorId || !s.isAlive) return s;
    return { ...s, currentTask: task };
  });
  return { ...state, survivors };
}

function clamp(value: number, min = 0, max = 100): number {
  return Math.min(max, Math.max(min, value));
}

/** Множитель эффективности работы от здоровья: истощённый житель работает
 * заметно хуже, но не падает до нуля (от 0.4x до 1x). */
function healthFactor(health: number): number {
  return 0.4 + 0.6 * clamp(health, 0, 100) / 100;
}

/** Множитель эффективности от усталости: до 50 усталости штрафа нет,
 * дальше эффективность линейно падает (до 0.4x при полном истощении). */
function fatigueFactor(fatigue: number): number {
  if (fatigue <= 50) return 1;
  return clamp(1 - ((fatigue - 50) / 50) * 0.6, 0.4, 1);
}

function buildingLevel(buildings: Building[], type: BuildingType): number {
  return buildings.find((b) => b.type === type && b.isBuilt)?.level ?? 0;
}

/** Бонус от подходящего здания: +15% производства за уровень. */
function buildingBonus(buildings: Building[], type: BuildingType): number {
  return 1 + buildingLevel(buildings, type) * 0.15;
}

interface WorkResult {
  resources: GameState['resources'];
  buildings: Building[];
  survivors: Survivor[];
  journalAdditions: string[];
  foodConsumptionMultiplier: number;
}

/** Применяет эффект назначенных задач за один игровой час: производство ресурсов,
 * строительство/улучшение зданий, эффекты готовки, охраны и лечения.
 * Усталость от самой работы применяется здесь; голод/потребление еды/здоровье —
 * в economySystem + survivorStateSystem. */
export function applyHourlyWork(state: GameState, isNight: boolean, isWinter = false): WorkResult {
  const resources = { ...state.resources };
  let buildings = state.buildings.map((b) => ({ ...b }));
  const journalAdditions: string[] = [];
  let moraleBonusAll = 0;
  // Готовка не должна списывать еду поверх обычного потребления поселением
  // (economySystem.consumeFoodForSettlement уже кормит всех из общего запаса) —
  // вместо этого хорошая готовка делает еду "сытнее", снижая итоговую потребность.
  let foodConsumptionMultiplier = 1;

  const cookingAssigned = state.survivors.filter((s) => s.isAlive && s.currentTask === 'cooking');
  const cookingActive = cookingAssigned.length > 0 && resources.food >= 1 && resources.fuel >= 0.3;
  if (cookingActive) {
    const kitchenBonus = buildingBonus(buildings, 'kitchen');
    // Зимой топливо на готовку уходит быстрее — печи топятся сильнее в холода.
    const winterFuelMultiplier = isWinter ? 1.4 : 1;
    resources.fuel = Math.max(0, resources.fuel - 0.3 * cookingAssigned.length * winterFuelMultiplier);
    moraleBonusAll += 0.3 * kitchenBonus;
    // -10% потребности в еде за повара, ещё -5% за уровень кухни (максимум -35%).
    const reduction = Math.min(0.35, 0.1 * cookingAssigned.length + 0.05 * buildingLevel(buildings, 'kitchen'));
    foodConsumptionMultiplier = 1 - reduction;
  }

  // --- Строительство: каждое здание со своими назначенными строителями (раздел 10.4 —
  // игрок сам выбирает, что строить, а не жёсткая очередь приоритета). ---
  const freedBuilderIds: string[] = [];
  buildings = buildings.map((b) => {
    if (b.isBuilt && b.level >= b.maxLevel) return b; // уже на максимуме — строить нечего
    const assignedBuilders = state.survivors.filter(
      (s) => s.isAlive && s.currentTask === 'building' && b.assignedSurvivorIds.includes(s.id),
    );
    if (assignedBuilders.length === 0) return b;

    const toolsBonus = buildingBonus(state.buildings, 'workshop');
    const totalConstructionSkill = assignedBuilders.reduce(
      (sum, s) => sum + s.skills.construction * healthFactor(s.state.health) * fatigueFactor(s.state.fatigue),
      0,
    );
    const progressGain = (4 * assignedBuilders.length + totalConstructionSkill / 5) * toolsBonus;

    const template = BUILDING_TEMPLATES[b.type];
    const cost: Required<Pick<ResourceCost, 'wood' | 'stone' | 'iron' | 'gold'>> = {
      wood: template.cost.wood ?? 0,
      stone: template.cost.stone ?? 0,
      iron: template.cost.iron ?? 0,
      gold: template.cost.gold ?? 0,
    };
    const costMultiplier = b.isBuilt ? b.level : 1; // улучшение дороже с уровнем
    const keys: Array<'wood' | 'stone' | 'iron' | 'gold'> = ['wood', 'stone', 'iron', 'gold'];
    const affordable = keys.every((key) => {
      const val = cost[key] * costMultiplier;
      return val === 0 || resources[key] >= (val * progressGain) / 100;
    });

    if (!affordable) return b;

    keys.forEach((key) => {
      const val = cost[key] * costMultiplier;
      if (val > 0) resources[key] = Math.max(0, resources[key] - (val * progressGain) / 100);
    });

    const newProgress = b.constructionProgress + progressGain;
    if (newProgress >= 100) {
      freedBuilderIds.push(...assignedBuilders.map((s) => s.id));
      if (!b.isBuilt) {
        journalAdditions.push(`Построено новое здание: ${b.name}.`);
        return { ...b, isBuilt: true, level: 1, constructionProgress: 0, assignedSurvivorIds: [] };
      }
      journalAdditions.push(`${b.name} улучшена до уровня ${b.level + 1}.`);
      return { ...b, level: b.level + 1, constructionProgress: 0, assignedSurvivorIds: [] };
    }
    return { ...b, constructionProgress: newProgress };
  });

  // --- Охрана ---
  const guardsCount = state.survivors.filter((s) => s.isAlive && s.currentTask === 'guarding').length;
  if (guardsCount > 0) moraleBonusAll += 0.15 * guardsCount;

  // --- Святилище: пассивное благословение Девяти Божеств поднимает мораль поселения ---
  const shrineLevel = buildingLevel(buildings, 'shrine');
  if (shrineLevel > 0) moraleBonusAll += 0.2 * shrineLevel;

  // --- Перенаселённость: если живых жителей больше, чем позволяет "housing", —
  // тесное поселение давит на мораль (реальный эффект здания "Жильё"). ---
  const aliveNow = state.survivors.filter((s) => s.isAlive).length;
  const housingCapacity = getHousingCapacity(buildings);
  if (aliveNow > housingCapacity) {
    moraleBonusAll -= 0.2 * (aliveNow - housingCapacity);
  }

  // --- Лечение/алхимия: производит зелья (если есть лаборатория) и подлечивает больных/раненых ---
  const healersAlive = state.survivors.filter((s) => s.isAlive && s.currentTask === 'healing');
  let survivorsAfterHealing = state.survivors;
  if (healersAlive.length > 0) {
    const labBonus = buildingBonus(buildings, 'alchemyLab');
    const labLevel = buildingLevel(buildings, 'alchemyLab');
    healersAlive.forEach((healer) => {
      const eff = healthFactor(healer.state.health) * fatigueFactor(healer.state.fatigue);
      if (labLevel > 0 && resources.ingredients >= 0.5) {
        const produced = (0.2 + healer.skills.medicine / 25) * eff * labBonus;
        resources.ingredients = Math.max(0, resources.ingredients - 0.5);
        resources.medicine += produced;
      }
    });
    // Лекарь тратит немного целебных зелий, чтобы подлечить самого больного/раненого жителя.
    // Лечебница ("infirmary") реально усиливает эффект лечения — не только лаборатория.
    const infirmaryBonus = buildingBonus(buildings, 'infirmary');
    const patient = [...survivorsAfterHealing]
      .filter((s) => s.isAlive && (s.state.isSick || s.state.isInjured || s.state.health < 50))
      .sort((a, b) => a.state.health - b.state.health)[0];
    if (patient && resources.medicine >= 1) {
      resources.medicine -= 1;
      survivorsAfterHealing = survivorsAfterHealing.map((s) => {
        if (s.id !== patient.id) return s;
        return {
          ...s,
          state: { ...s.state, health: clamp(s.state.health + 8 * infirmaryBonus), isSick: false, isInjured: false },
        };
      });
    }
  }

  // Ферма — пассивный источник еды, работает независимо от назначенных задач,
  // как только построена (соответствует её описанию "постоянный источник еды").
  const farmLevel = buildingLevel(buildings, 'farm');
  if (farmLevel > 0) {
    resources.food += 0.6 * farmLevel;
  }

  const huntingBonus = buildingBonus(buildings, 'huntingPost');
  const forgeLevel = buildingLevel(buildings, 'forge');

  const survivors: Survivor[] = survivorsAfterHealing.map((s) => {
    if (!s.isAlive) return s;
    const eff = healthFactor(s.state.health) * fatigueFactor(s.state.fatigue);
    let fatigueDelta = 1; // idle по умолчанию

    switch (s.currentTask) {
      case 'hunting': {
        const gain = (0.9 + s.skills.hunting / 16) * eff * huntingBonus;
        resources.food += gain;
        fatigueDelta = isNight ? 5 : 3;
        break;
      }
      case 'gathering': {
        const gain = (0.3 + s.skills.gathering / 20) * eff;
        resources.ingredients += gain;
        // Собирательство — второй полноценный источник еды (ягоды, коренья, дичь помельче),
        // не только побочный эффект: масштабируется навыком, как и охота.
        resources.food += (0.5 + s.skills.gathering / 30) * eff;
        fatigueDelta = isNight ? 4 : 2;
        break;
      }
      case 'woodcutting': {
        const gain = (0.5 + s.skills.gathering / 18) * eff;
        resources.wood += gain;
        fatigueDelta = isNight ? 5 : 3;
        break;
      }
      case 'mining': {
        const toolsBonus = buildingBonus(buildings, 'workshop');
        const gain = (0.3 + s.skills.gathering / 25) * eff * toolsBonus;
        resources.ore += gain;
        resources.stone += gain * 0.5; // попутная добыча камня из тех же выработок
        fatigueDelta = isNight ? 5 : 3;
        break;
      }
      case 'smithing': {
        if (forgeLevel > 0 && resources.ore >= 1) {
          const forgeBonus = buildingBonus(buildings, 'forge');
          const converted = Math.min(resources.ore, (0.4 + s.skills.smithing / 20) * eff * forgeBonus);
          resources.ore -= converted;
          resources.iron += converted * 0.8; // часть руды теряется при переплавке
        }
        fatigueDelta = isNight ? 4 : 3;
        break;
      }
      case 'building':
        fatigueDelta = isNight ? 5 : 3;
        break;
      case 'guarding':
        fatigueDelta = isNight ? 4 : 2;
        break;
      case 'cooking':
        fatigueDelta = isNight ? 4 : 2;
        break;
      case 'healing':
        fatigueDelta = isNight ? 3 : 2;
        break;
      case 'resting':
        fatigueDelta = isNight ? -18 : -14;
        break;
      case 'idle':
      default:
        fatigueDelta = isNight ? 2 : 1;
        break;
    }

    let morale = s.state.morale + (s.currentTask === 'resting' ? 1 : 0) + moraleBonusAll;
    morale = clamp(morale);

    return {
      ...s,
      currentTask: freedBuilderIds.includes(s.id) ? ('idle' as const) : s.currentTask,
      state: {
        ...s.state,
        fatigue: clamp(s.state.fatigue + fatigueDelta),
        morale,
      },
    };
  });

  return { resources, buildings, survivors, journalAdditions, foodConsumptionMultiplier };
}
