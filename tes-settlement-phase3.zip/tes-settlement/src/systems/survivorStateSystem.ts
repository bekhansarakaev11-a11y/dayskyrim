import { Survivor } from '../entities/survivor';

function clamp(value: number, min = 0, max = 100): number {
  return Math.min(max, Math.max(min, value));
}

export interface StateTickResult {
  survivors: Survivor[];
  deaths: string[]; // имена погибших этот час — для журнала
  deathIds: string[]; // ID погибших этот час — для системы отношений/горя
  newlySick: string[]; // имена заболевших этот час — для журнала
}

/** Применяет почасовое изменение голода/здоровья/морали.
 * `fed` — хватило ли общесе́ленческой еды на всех этот час (economySystem.consumeFoodForSettlement).
 * `shortageStreak` — сколько часов подряд еды не хватает (влияет на риск болезни).
 * `diseaseRiskMultiplier` — снижается лечебницей (infirmary): реже болеют при её наличии.
 * Вызывается ПОСЛЕ workSystem.applyHourlyWork (та уже применила усталость от задач). */
export function applyHourlySurvivorState(
  survivors: Survivor[],
  isNight: boolean,
  fed: boolean,
  shortageStreak: number,
  diseaseRiskMultiplier = 1,
): StateTickResult {
  const deaths: string[] = [];
  const deathIds: string[] = [];
  const newlySick: string[] = [];

  const updated = survivors.map((s) => {
    if (!s.isAlive) return s;

    let { health, hunger, fatigue, morale, fear } = s.state;
    let isSick = s.state.isSick;

    // Голод теперь определяется реальным потреблением еды поселения, а не абстрактным таймером.
    if (fed) {
      hunger = clamp(hunger + (isNight ? 6 : 8));
    } else {
      hunger = clamp(hunger - (isNight ? 3 : 4));
    }

    if (hunger <= 0) {
      health = clamp(health - 3);
      fear = clamp(fear + 1);
    }
    if (fatigue >= 95) {
      health = clamp(health - 1);
    }

    // Длительный голод (несколько часов подряд без еды) может вызвать болезнь.
    if (!isSick && shortageStreak >= 6 && hunger <= 10) {
      const sicknessChance = Math.min(0.35, 0.03 * (shortageStreak - 5)) * diseaseRiskMultiplier;
      if (Math.random() < sicknessChance) {
        isSick = true;
        newlySick.push(s.name);
      }
    }
    if (isSick) {
      health = clamp(health - 0.5);
      morale -= 0.3;
    }

    // Восстановление здоровья в благоприятных условиях (и постепенное выздоровление).
    if (hunger > 60 && fatigue < 40) {
      health = clamp(health + (isSick ? 0.1 : 0.3));
      if (isSick && Math.random() < 0.05) isSick = false; // естественное выздоровление
    }

    const baseline = 55;
    morale += (baseline - morale) * 0.05;
    if (hunger < 20) morale -= 1;
    if (fatigue > 80) morale -= 1;
    morale = clamp(morale);
    fear = clamp(fear - 0.2);

    const isAlive = health > 0;
    if (!isAlive) {
      deaths.push(s.name);
      deathIds.push(s.id);
    }

    return {
      ...s,
      isAlive,
      state: { ...s.state, health, hunger, fatigue, morale, fear, isSick },
      currentTask: isAlive ? s.currentTask : ('idle' as const),
    };
  });

  return { survivors: updated, deaths, deathIds, newlySick };
}
