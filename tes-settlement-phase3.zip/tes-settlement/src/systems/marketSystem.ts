import { GameState, TradableResource, BASE_MARKET_PRICES, CaravanState } from '../core/gameEngine';

const MIN_PRICE_FACTOR = 0.35;
const MAX_PRICE_FACTOR = 3;
const PRICE_STEP = 0.015; // изменение цены за единицу купленного/проданного товара
const PRICE_DRIFT_PER_DAY = 0.08; // на сколько цена возвращается к базовой за сутки

export interface TradeResult {
  state: GameState;
  success: boolean;
  message: string;
}

function currentPriceMultiplier(state: GameState): { buy: number; sell: number } {
  if (state.caravan?.active) {
    return { buy: 1 - state.caravan.priceBonus * 0.5, sell: 1 + state.caravan.priceBonus };
  }
  return { buy: 1, sell: 1 };
}

/** Покупка ресурса поселением у рынка/каравана: тратит золото, добавляет ресурс,
 * цена немного растёт (спрос). Ограничена вместимостью склада — вызывающий код
 * (App/UI) должен передавать уже проверенное количество, но на всякий случай
 * результат всё равно клампится системой economySystem при следующем тике. */
export function buyResource(state: GameState, resource: TradableResource, amount: number): TradeResult {
  if (amount <= 0) return { state, success: false, message: 'Некорректное количество.' };
  const price = state.marketPrices[resource];
  const { buy } = currentPriceMultiplier(state);
  const effectivePrice = price * buy;
  const cost = effectivePrice * amount;

  if (state.resources.gold < cost) {
    return { state, success: false, message: 'Недостаточно золота.' };
  }

  const newPrice = Math.min(BASE_MARKET_PRICES[resource] * MAX_PRICE_FACTOR, price * (1 + PRICE_STEP * amount));

  const nextState: GameState = {
    ...state,
    resources: {
      ...state.resources,
      gold: state.resources.gold - cost,
      [resource]: state.resources[resource] + amount,
    },
    marketPrices: { ...state.marketPrices, [resource]: newPrice },
  };

  return { state: nextState, success: true, message: `Куплено ${amount} за ${cost.toFixed(1)} золота.` };
}

/** Продажа ресурса поселением: убирает ресурс, добавляет золото, цена немного падает (предложение). */
export function sellResource(state: GameState, resource: TradableResource, amount: number): TradeResult {
  if (amount <= 0) return { state, success: false, message: 'Некорректное количество.' };
  if (state.resources[resource] < amount) {
    return { state, success: false, message: 'Недостаточно ресурса для продажи.' };
  }

  const price = state.marketPrices[resource];
  const { sell } = currentPriceMultiplier(state);
  const effectivePrice = price * sell;
  const revenue = effectivePrice * amount;

  const newPrice = Math.max(BASE_MARKET_PRICES[resource] * MIN_PRICE_FACTOR, price * (1 - PRICE_STEP * amount));

  const nextState: GameState = {
    ...state,
    resources: {
      ...state.resources,
      gold: state.resources.gold + revenue,
      [resource]: state.resources[resource] - amount,
    },
    marketPrices: { ...state.marketPrices, [resource]: newPrice },
  };

  return { state: nextState, success: true, message: `Продано ${amount} за ${revenue.toFixed(1)} золота.` };
}

/** Цены медленно возвращаются к базовым значениям — вызывается раз в сутки. */
export function driftPricesTowardBase(state: GameState): GameState {
  const nextPrices = { ...state.marketPrices };
  (Object.keys(nextPrices) as TradableResource[]).forEach((key) => {
    const base = BASE_MARKET_PRICES[key];
    const current = nextPrices[key];
    nextPrices[key] = current + (base - current) * PRICE_DRIFT_PER_DAY;
  });
  return { ...state, marketPrices: nextPrices };
}

const CARAVAN_INTERVAL_DAYS = 4;
const CARAVAN_DURATION_HOURS = 6;

/** Проверяет и, при наступлении срока, запускает прибытие торгового каравана
 * (вызывается при переходе на новый день). Караван даёт лучшие цены на
 * ограниченное время — простая, но реально работающая механика. */
export function maybeTriggerCaravan(state: GameState): { state: GameState; journalEntry: string | null } {
  // Отправляем предыдущий караван, если время вышло.
  if (state.caravan?.active) {
    const nowAbsoluteHour = state.day * 24 + state.hour;
    if (nowAbsoluteHour >= state.caravan.expiresAtHour) {
      return { state: { ...state, caravan: { ...state.caravan, active: false } }, journalEntry: 'Торговый караван покинул поселение.' };
    }
    return { state, journalEntry: null };
  }

  if (state.day % CARAVAN_INTERVAL_DAYS === 0 && state.caravan?.arrivedOnDay !== state.day) {
    const caravan: CaravanState = {
      active: true,
      arrivedOnDay: state.day,
      expiresAtHour: state.day * 24 + state.hour + CARAVAN_DURATION_HOURS,
      priceBonus: 0.2,
    };
    return { state: { ...state, caravan }, journalEntry: 'В поселение прибыл торговый караван — выгодные цены на несколько часов.' };
  }

  return { state, journalEntry: null };
}
