import { Building } from '../entities/building';
import { ResourceCost } from '../entities/building';

/** Вместимость склада по уровню здания "warehouse". Без склада (level 0)
 * действует базовый лимит — герои хранят немного припасов прямо в лагере. */
export const WAREHOUSE_CAPACITY_BY_LEVEL: Record<number, number> = {
  0: 60,
  1: 100,
  2: 250,
  3: 500,
};

const FOOD_PER_SURVIVOR_PER_HOUR = 0.45;

export function getStorageCapacity(buildings: Building[]): number {
  const warehouse = buildings.find((b) => b.type === 'warehouse');
  const level = warehouse?.level ?? 0;
  return WAREHOUSE_CAPACITY_BY_LEVEL[level] ?? WAREHOUSE_CAPACITY_BY_LEVEL[3];
}

/** Вместимость поселения по уровню "housing" — соответствует описанию здания
 * ("+2 к вместимости поселения" за уровень). Без жилья база — 6 человек. */
export const HOUSING_CAPACITY_BY_LEVEL: Record<number, number> = {
  0: 6,
  1: 8,
  2: 10,
  3: 12,
};

export function getHousingCapacity(buildings: Building[]): number {
  const housing = buildings.find((b) => b.type === 'housing');
  const level = housing?.level ?? 0;
  return HOUSING_CAPACITY_BY_LEVEL[level] ?? HOUSING_CAPACITY_BY_LEVEL[3];
}

export interface ClampResult {
  resources: Required<ResourceCost>;
  overflow: Partial<Record<keyof Required<ResourceCost>, number>>;
}

/** Урезает ресурсы до вместимости склада; золото хранением не ограничено. */
export function clampResourcesToCapacity(resources: Required<ResourceCost>, buildings: Building[]): ClampResult {
  const capacity = getStorageCapacity(buildings);
  const overflow: Partial<Record<keyof Required<ResourceCost>, number>> = {};
  const clamped = { ...resources };

  (Object.keys(clamped) as Array<keyof Required<ResourceCost>>).forEach((key) => {
    if (key === 'gold') return;
    if (clamped[key] > capacity) {
      overflow[key] = clamped[key] - capacity;
      clamped[key] = capacity;
    }
  });

  return { resources: clamped, overflow };
}

export interface FoodConsumptionResult {
  resources: Required<ResourceCost>;
  fed: boolean; // хватило ли еды в этот час на всех
  fedFraction: number; // 0..1 — какая доля потребности была покрыта
}

/** Списывает еду поселения за один час на всех живых жителей. Если еды не хватает,
 * списывается всё, что есть, а fed=false запускает каскад голода в survivorStateSystem.
 * `consumptionMultiplier` (0..1) снижает потребность — хорошая готовка эффективнее кормит. */
export function consumeFoodForSettlement(
  resources: Required<ResourceCost>,
  aliveSurvivorsCount: number,
  consumptionMultiplier = 1,
): FoodConsumptionResult {
  const needed = aliveSurvivorsCount * FOOD_PER_SURVIVOR_PER_HOUR * consumptionMultiplier;
  if (needed <= 0) return { resources, fed: true, fedFraction: 1 };

  const available = resources.food;
  if (available >= needed) {
    return { resources: { ...resources, food: available - needed }, fed: true, fedFraction: 1 };
  }
  const fedFraction = needed > 0 ? available / needed : 1;
  return { resources: { ...resources, food: 0 }, fed: false, fedFraction };
}

export function computeResourceDelta(
  before: Required<ResourceCost>,
  after: Required<ResourceCost>,
): Partial<Record<keyof Required<ResourceCost>, number>> {
  const delta: Partial<Record<keyof Required<ResourceCost>, number>> = {};
  (Object.keys(after) as Array<keyof Required<ResourceCost>>).forEach((key) => {
    const diff = after[key] - before[key];
    if (Math.abs(diff) > 0.0001) delta[key] = diff;
  });
  return delta;
}
