import { GameState } from '../core/gameEngine';
import { GameEvent, EventOutcome } from '../entities/event';
import { GAME_EVENTS } from '../data/events';
import { adjustRelationship } from './relationshipSystem';

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

const DAILY_EVENT_CHANCE = 0.3;

const NEGATIVE_CATEGORIES = new Set(['raid', 'illness', 'theft', 'conflict', 'shortage']);

/** Раз в сутки, если нет уже ожидающего решения события, с некоторой
 * вероятностью выбирает случайное событие из пула (взвешенно, с учётом
 * минимального дня кампании и сценарного множителя для негативных категорий).
 * События с выбором приостанавливают ход времени до решения игрока; остальные
 * применяются сразу. */
export function maybeTriggerEvent(state: GameState): { state: GameState; journalEntry: string | null } {
  if (state.pendingEvent) return { state, journalEntry: null };
  if (Math.random() >= DAILY_EVENT_CHANCE) return { state, journalEntry: null };

  const pool = GAME_EVENTS.filter((e) => (e.minDay ?? 1) <= state.day);
  if (pool.length === 0) return { state, journalEntry: null };

  const weights = pool.map((e) => (NEGATIVE_CATEGORIES.has(e.category) ? e.weight * state.negativeEventChanceMultiplier : e.weight));
  const totalWeight = weights.reduce((sum, w) => sum + w, 0);
  let roll = Math.random() * totalWeight;
  let chosen: GameEvent = pool[0];
  for (let i = 0; i < pool.length; i += 1) {
    roll -= weights[i];
    if (roll <= 0) {
      chosen = pool[i];
      break;
    }
  }

  if (chosen.choices && chosen.choices.length > 0) {
    return { state: { ...state, pendingEvent: chosen }, journalEntry: `Событие: ${chosen.title}.` };
  }

  const result = applyOutcome(state, chosen.outcome!);
  return { state: result, journalEntry: `${chosen.title}: ${chosen.outcome!.journalText}` };
}

export function applyOutcome(state: GameState, outcome: EventOutcome): GameState {
  const resources = { ...state.resources };
  if (outcome.resourceChanges) {
    (Object.entries(outcome.resourceChanges) as Array<[keyof typeof resources, number]>).forEach(([key, delta]) => {
      resources[key] = Math.max(0, resources[key] + delta);
    });
  }

  let survivors = state.survivors;
  const aliveSurvivors = survivors.filter((s) => s.isAlive);

  if (outcome.moraleAllDelta) {
    const delta = outcome.moraleAllDelta;
    survivors = survivors.map((s) =>
      s.isAlive ? { ...s, state: { ...s.state, morale: clamp(s.state.morale + delta, 0, 100) } } : s,
    );
  }

  if (outcome.randomSurvivorHealthDelta && aliveSurvivors.length > 0) {
    const target = aliveSurvivors[Math.floor(Math.random() * aliveSurvivors.length)];
    const delta = outcome.randomSurvivorHealthDelta;
    survivors = survivors.map((s) =>
      s.id === target.id ? { ...s, state: { ...s.state, health: clamp(s.state.health + delta, 1, 100) } } : s,
    );
  }

  if (outcome.randomSurvivorMoraleDelta && aliveSurvivors.length > 0) {
    const target = aliveSurvivors[Math.floor(Math.random() * aliveSurvivors.length)];
    const delta = outcome.randomSurvivorMoraleDelta;
    survivors = survivors.map((s) =>
      s.id === target.id ? { ...s, state: { ...s.state, morale: clamp(s.state.morale + delta, 0, 100) } } : s,
    );
  }

  if ((outcome.relationshipBoost || outcome.relationshipStrain) && aliveSurvivors.length >= 2) {
    const shuffled = [...aliveSurvivors].sort(() => Math.random() - 0.5);
    const [a, b] = shuffled;
    survivors = adjustRelationship(survivors, a.id, b.id, outcome.relationshipBoost ? 8 : -8);
  }

  let factions = state.factions;
  if (outcome.factionReputationDelta) {
    const { factionId, amount } = outcome.factionReputationDelta;
    factions = factions.map((f) => (f.id === factionId ? { ...f, reputation: clamp(f.reputation + amount, -100, 100) } : f));
  }

  return { ...state, resources, survivors, factions };
}

/** Применяет выбранный игроком вариант ожидающего события и снимает блокировку времени. */
export function resolveEventChoice(state: GameState, choiceId: string): { state: GameState; journalEntry: string | null } {
  const event = state.pendingEvent;
  if (!event || !event.choices) return { state, journalEntry: null };

  const choice = event.choices.find((c) => c.id === choiceId);
  if (!choice) return { state, journalEntry: null };

  const applied = applyOutcome({ ...state, pendingEvent: null }, choice.outcome);
  return { state: applied, journalEntry: `${event.title} — ${choice.label}: ${choice.outcome.journalText}` };
}
