import { useEffect, useState } from 'react';
import { MainMenu } from './ui/screens/MainMenu';
import { SettlementScreen } from './ui/screens/SettlementScreen';
import { MapScreen } from './ui/screens/MapScreen';
import { FactionsScreen } from './ui/screens/FactionsScreen';
import { BuildingsScreen } from './ui/screens/BuildingsScreen';
import { BuilderAssignModal } from './ui/modals/BuilderAssignModal';
import { EndingScreen } from './ui/screens/EndingScreen';
import { SurvivorDetailModal } from './ui/modals/SurvivorDetailModal';
import { MarketModal } from './ui/modals/MarketModal';
import { ExpeditionModal } from './ui/modals/ExpeditionModal';
import { FactionQuestModal } from './ui/modals/FactionQuestModal';
import { EventChoiceModal } from './ui/modals/EventChoiceModal';
import { OnboardingModal } from './ui/modals/OnboardingModal';
import { ToastStack } from './ui/components/ToastStack';
import { GameState, TradableResource, ScenarioId } from './core/gameEngine';
import { createNewGame } from './game/newGame';
import { advanceHour, advanceToNextDay } from './core/timeSystem';
import { assignTask } from './systems/workSystem';
import { buyResource, sellResource } from './systems/marketSystem';
import { startExpedition } from './systems/expeditionSystem';
import { startFactionQuest } from './systems/factionSystem';
import { assignBuilderToBuilding } from './systems/buildingSystem';
import { resolveEventChoice } from './systems/eventSystem';
import { classifyNewJournalEntries, Toast } from './systems/notificationSystem';
import { ExpeditionGoal } from './entities/expedition';
import { FactionId } from './entities/faction';
import { CurrentTask } from './entities/survivor';
import { loadGame, saveGame, isOnboardingCompleted, markOnboardingCompleted } from './storage/saveSystem';
import { telegram } from './telegram/telegramWebApp';
import { useGameClock, ClockSpeed } from './ui/hooks/useGameClock';

type Screen = 'loading' | 'menu' | 'settlement' | 'map' | 'factions' | 'buildings';

export default function App() {
  const [screen, setScreen] = useState<Screen>('loading');
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [hasSave, setHasSave] = useState(false);
  const [selectedSurvivorId, setSelectedSurvivorId] = useState<string | null>(null);
  const [isMarketOpen, setIsMarketOpen] = useState(false);
  const [expeditionLocationId, setExpeditionLocationId] = useState<string | null>(null);
  const [selectedFactionId, setSelectedFactionId] = useState<FactionId | null>(null);
  const [selectedBuildingId, setSelectedBuildingId] = useState<string | null>(null);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [isClockPaused, setIsClockPaused] = useState(true); // пауза по умолчанию при входе
  const [clockSpeed, setClockSpeed] = useState<ClockSpeed>(1);

  useEffect(() => {
    telegram.init();
    loadGame().then((saved) => {
      if (saved) setHasSave(true);
      setScreen('menu');
    });
  }, []);

  function pushToastsFromDiff(prev: GameState, next: GameState) {
    if (next.journal.length <= prev.journal.length) return;
    const newTexts = next.journal.slice(prev.journal.length).map((j) => j.text);
    const newToasts = classifyNewJournalEntries(newTexts);
    if (newToasts.length > 0) setToasts((t) => [...t, ...newToasts]);
  }

  function commitState(next: GameState, prev?: GameState) {
    if (prev) pushToastsFromDiff(prev, next);
    setGameState(next);
    void saveGame(next);
  }

  async function handleNewGame(scenarioId: ScenarioId) {
    const state = createNewGame(scenarioId);
    setGameState(state);
    void saveGame(state);
    setHasSave(true);
    setIsClockPaused(true);
    const onboardingDone = await isOnboardingCompleted();
    if (!onboardingDone) {
      setShowOnboarding(true);
    }
    setScreen('settlement');
  }

  async function handleContinue() {
    const saved = await loadGame();
    if (saved) {
      setGameState(saved);
      setIsClockPaused(true);
      setScreen('settlement');
    }
  }

  function handleFinishOnboarding() {
    setShowOnboarding(false);
    void markOnboardingCompleted();
  }

  function handleAdvanceHour() {
    if (!gameState) return;
    const next = advanceHour(gameState);
    commitState(next, gameState);
    telegram.haptic('light');
  }

  function handleAdvanceDay() {
    if (!gameState) return;
    const next = advanceToNextDay(gameState);
    commitState(next, gameState);
    telegram.haptic('medium');
  }

  function handleAssignTask(survivorId: string, task: CurrentTask) {
    if (!gameState) return;
    const next = assignTask(gameState, survivorId, task);
    setGameState(next);
    void saveGame(next);
    telegram.haptic('light');
  }

  function handleBuy(resource: TradableResource, amount: number) {
    if (!gameState) return;
    const result = buyResource(gameState, resource, amount);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'light' : 'medium');
  }

  function handleSell(resource: TradableResource, amount: number) {
    if (!gameState) return;
    const result = sellResource(gameState, resource, amount);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'light' : 'medium');
  }

  function handleSave() {
    if (!gameState) return;
    void saveGame(gameState);
    telegram.hapticNotify('success');
  }

  function handleLaunchExpedition(locationId: string, survivorIds: string[], goal: ExpeditionGoal) {
    if (!gameState) return;
    const result = startExpedition(gameState, locationId, survivorIds, goal);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'medium' : 'light');
    if (result.success) setExpeditionLocationId(null);
  }

  function handleStartQuest(questId: string, survivorId: string) {
    if (!gameState) return;
    const result = startFactionQuest(gameState, questId, survivorId);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'medium' : 'light');
    if (result.success) setSelectedFactionId(null);
  }

  function handleAssignBuilder(survivorId: string) {
    if (!gameState || !selectedBuildingId) return;
    const result = assignBuilderToBuilding(gameState, survivorId, selectedBuildingId);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'medium' : 'light');
    if (result.success) setSelectedBuildingId(null);
  }

  function handleChooseEvent(choiceId: string) {
    if (!gameState) return;
    const result = resolveEventChoice(gameState, choiceId);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic('medium');
  }

  function handleDismissToast(id: string) {
    setToasts((t) => t.filter((x) => x.id !== id));
  }

  // Автотик времени. Блокируется при паузе, окончании игры, ожидающем событии
  // и при онбординге (чтобы не сгорали часы, пока игрок читает подсказки).
  useGameClock({
    isPaused: isClockPaused,
    speed: clockSpeed,
    blocked: !gameState || gameState.isGameOver || !!gameState.pendingEvent || showOnboarding,
    onTick: handleAdvanceHour,
  });

  // Событие с выбором должно автоматически ставить автоход на паузу.
  useEffect(() => {
    if (gameState?.pendingEvent && !isClockPaused) {
      setIsClockPaused(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameState?.pendingEvent]);

  if (screen === 'loading') {
    return <div className="screen screen--loading">Загрузка...</div>;
  }

  if (screen === 'menu' || !gameState) {
    return <MainMenu hasSave={hasSave} onNewGame={handleNewGame} onContinue={handleContinue} />;
  }

  if (gameState.isGameOver) {
    return <EndingScreen state={gameState} onReturnToMenu={() => setScreen('menu')} />;
  }

  const selectedSurvivor = selectedSurvivorId
    ? gameState.survivors.find((s) => s.id === selectedSurvivorId && s.isAlive) ?? null
    : null;

  return (
    <>
      <ToastStack toasts={toasts} onDismiss={handleDismissToast} />

      {screen === 'map' ? (
        <MapScreen
          state={gameState}
          onSelectLocation={setExpeditionLocationId}
          onClose={() => setScreen('settlement')}
        />
      ) : screen === 'factions' ? (
        <FactionsScreen
          state={gameState}
          onSelectFaction={setSelectedFactionId}
          onClose={() => setScreen('settlement')}
        />
      ) : screen === 'buildings' ? (
        <BuildingsScreen
          state={gameState}
          onSelectBuilding={setSelectedBuildingId}
          onClose={() => setScreen('settlement')}
        />
      ) : (
        <SettlementScreen
          state={gameState}
          onAdvanceHour={handleAdvanceHour}
          onAdvanceDay={handleAdvanceDay}
          onSelectSurvivor={setSelectedSurvivorId}
          onQuickAssignTask={handleAssignTask}
          onOpenMarket={() => setIsMarketOpen(true)}
          onOpenMap={() => setScreen('map')}
          onOpenFactions={() => setScreen('factions')}
          onOpenBuildings={() => setScreen('buildings')}
          onSave={handleSave}
          onExitToMenu={() => setScreen('menu')}
          isClockPaused={isClockPaused}
          clockSpeed={clockSpeed}
          onToggleClockPause={() => setIsClockPaused((p) => !p)}
          onSetClockSpeed={setClockSpeed}
        />
      )}
      {selectedSurvivor && (
        <SurvivorDetailModal
          survivor={selectedSurvivor}
          allSurvivors={gameState.survivors}
          onAssignTask={handleAssignTask}
          onClose={() => setSelectedSurvivorId(null)}
        />
      )}
      {isMarketOpen && (
        <MarketModal
          state={gameState}
          onBuy={handleBuy}
          onSell={handleSell}
          onClose={() => setIsMarketOpen(false)}
        />
      )}
      {expeditionLocationId && (
        <ExpeditionModal
          state={gameState}
          locationId={expeditionLocationId}
          onLaunch={handleLaunchExpedition}
          onClose={() => setExpeditionLocationId(null)}
        />
      )}
      {selectedFactionId && (
        <FactionQuestModal
          state={gameState}
          factionId={selectedFactionId}
          onStartQuest={handleStartQuest}
          onClose={() => setSelectedFactionId(null)}
        />
      )}
      {selectedBuildingId && gameState.buildings.find((b) => b.id === selectedBuildingId) && (
        <BuilderAssignModal
          state={gameState}
          building={gameState.buildings.find((b) => b.id === selectedBuildingId)!}
          onAssign={handleAssignBuilder}
          onClose={() => setSelectedBuildingId(null)}
        />
      )}
      {gameState.pendingEvent && (
        <EventChoiceModal event={gameState.pendingEvent} onChoose={handleChooseEvent} />
      )}
      {showOnboarding && <OnboardingModal onFinish={handleFinishOnboarding} />}
    </>
  );
}
