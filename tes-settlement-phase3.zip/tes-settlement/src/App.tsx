import { useEffect, useState } from 'react';
import { MainMenu } from './ui/screens/MainMenu';
import { SettlementScreen } from './ui/screens/SettlementScreen';
import { SurvivorDetailModal } from './ui/modals/SurvivorDetailModal';
import { MarketModal } from './ui/modals/MarketModal';
import { GameState, TradableResource } from './core/gameEngine';
import { createNewGame } from './game/newGame';
import { advanceHour, advanceToNextDay } from './core/timeSystem';
import { assignTask } from './systems/workSystem';
import { buyResource, sellResource } from './systems/marketSystem';
import { CurrentTask } from './entities/survivor';
import { loadGame, saveGame } from './storage/saveSystem';
import { telegram } from './telegram/telegramWebApp';

type Screen = 'loading' | 'menu' | 'settlement';

export default function App() {
  const [screen, setScreen] = useState<Screen>('loading');
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [hasSave, setHasSave] = useState(false);
  const [selectedSurvivorId, setSelectedSurvivorId] = useState<string | null>(null);
  const [isMarketOpen, setIsMarketOpen] = useState(false);

  useEffect(() => {
    telegram.init();
    loadGame().then((saved) => {
      if (saved) setHasSave(true);
      setScreen('menu');
    });
  }, []);

  function handleNewGame() {
    const state = createNewGame();
    setGameState(state);
    void saveGame(state);
    setHasSave(true);
    setScreen('settlement');
  }

  async function handleContinue() {
    const saved = await loadGame();
    if (saved) {
      setGameState(saved);
      setScreen('settlement');
    }
  }

  function handleAdvanceHour() {
    if (!gameState) return;
    const next = advanceHour(gameState);
    setGameState(next);
    void saveGame(next);
    telegram.haptic('light');
  }

  function handleAdvanceDay() {
    if (!gameState) return;
    const next = advanceToNextDay(gameState);
    setGameState(next);
    void saveGame(next);
    telegram.haptic('medium');
  }

  function handleAssignTask(survivorId: string, task: CurrentTask) {
    if (!gameState) return;
    const next = assignTask(gameState, survivorId, task);
    setGameState(next);
    void saveGame(next);
    telegram.haptic('light');
  }

  function handleBuy(resource: TradableResource, amount: number) {
    if (!gameState) return;
    const result = buyResource(gameState, resource, amount);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'light' : 'medium');
  }

  function handleSell(resource: TradableResource, amount: number) {
    if (!gameState) return;
    const result = sellResource(gameState, resource, amount);
    setGameState(result.state);
    void saveGame(result.state);
    telegram.haptic(result.success ? 'light' : 'medium');
  }

  function handleSave() {
    if (!gameState) return;
    void saveGame(gameState);
    telegram.hapticNotify('success');
  }

  if (screen === 'loading') {
    return <div className="screen screen--loading">Загрузка...</div>;
  }

  if (screen === 'menu' || !gameState) {
    return <MainMenu hasSave={hasSave} onNewGame={handleNewGame} onContinue={handleContinue} />;
  }

  const selectedSurvivor = selectedSurvivorId
    ? gameState.survivors.find((s) => s.id === selectedSurvivorId && s.isAlive) ?? null
    : null;

  return (
    <>
      <SettlementScreen
        state={gameState}
        onAdvanceHour={handleAdvanceHour}
        onAdvanceDay={handleAdvanceDay}
        onSelectSurvivor={setSelectedSurvivorId}
        onOpenMarket={() => setIsMarketOpen(true)}
        onSave={handleSave}
        onExitToMenu={() => setScreen('menu')}
      />
      {selectedSurvivor && (
        <SurvivorDetailModal
          survivor={selectedSurvivor}
          onAssignTask={handleAssignTask}
          onClose={() => setSelectedSurvivorId(null)}
        />
      )}
      {isMarketOpen && (
        <MarketModal
          state={gameState}
          onBuy={handleBuy}
          onSell={handleSell}
          onClose={() => setIsMarketOpen(false)}
        />
      )}
    </>
  );
}
