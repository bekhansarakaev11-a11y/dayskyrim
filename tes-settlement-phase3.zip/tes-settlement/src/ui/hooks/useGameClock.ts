import { useEffect, useRef } from 'react';

export type ClockSpeed = 1 | 2 | 3;

const INTERVAL_MS_BY_SPEED: Record<ClockSpeed, number> = {
  1: 4000,
  2: 2000,
  3: 900,
};

interface UseGameClockOptions {
  isPaused: boolean;
  speed: ClockSpeed;
  /** Тик не должен выполняться, если true (напр. isGameOver или ожидающее событие). */
  blocked: boolean;
  onTick: () => void;
}

/** Автоматический тик игрового времени. Не содержит игровой логики — только
 * планирует вызовы onTick() (обычно advanceHour) через равные интервалы,
 * зависящие от выбранной скорости. Пауза и блокировка (ожидающее событие,
 * конец игры) останавливают тик без сброса состояния таймера. */
export function useGameClock({ isPaused, speed, blocked, onTick }: UseGameClockOptions): void {
  const onTickRef = useRef(onTick);
  onTickRef.current = onTick;

  useEffect(() => {
    if (isPaused || blocked) return undefined;

    const intervalMs = INTERVAL_MS_BY_SPEED[speed];
    const id = window.setInterval(() => {
      onTickRef.current();
    }, intervalMs);

    return () => window.clearInterval(id);
  }, [isPaused, blocked, speed]);
}
