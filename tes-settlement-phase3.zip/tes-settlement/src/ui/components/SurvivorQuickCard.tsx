import { useRef, useState } from 'react';
import { Survivor, CurrentTask } from '../../entities/survivor';
import { TASK_LABELS } from '../../systems/workSystem';

interface SurvivorQuickCardProps {
  survivor: Survivor;
  onOpenDetails: (id: string) => void;
  onQuickAssign: (id: string, task: CurrentTask) => void;
}

const QUICK_TASKS: CurrentTask[] = ['hunting', 'gathering', 'cooking', 'guarding', 'resting'];
const LONG_PRESS_MS = 500;

export function SurvivorQuickCard({ survivor, onOpenDetails, onQuickAssign }: SurvivorQuickCardProps) {
  const [quickMenuOpen, setQuickMenuOpen] = useState(false);
  const timerRef = useRef<number | null>(null);
  const longPressFiredRef = useRef(false);

  function startPress() {
    longPressFiredRef.current = false;
    timerRef.current = window.setTimeout(() => {
      longPressFiredRef.current = true;
      setQuickMenuOpen(true);
    }, LONG_PRESS_MS);
  }

  function endPress() {
    if (timerRef.current) window.clearTimeout(timerRef.current);
  }

  function handleClick() {
    if (longPressFiredRef.current) {
      longPressFiredRef.current = false;
      return; // долгий тап уже открыл быстрое меню — обычный клик игнорируем
    }
    onOpenDetails(survivor.id);
  }

  if (quickMenuOpen) {
    return (
      <div className="survivor-card survivor-card--quickmenu">
        <div className="survivor-card__name">{survivor.name}</div>
        <div className="quick-task-menu">
          {QUICK_TASKS.map((task) => (
            <button
              key={task}
              className="quick-task-btn"
              onClick={() => {
                onQuickAssign(survivor.id, task);
                setQuickMenuOpen(false);
              }}
            >
              {TASK_LABELS[task]}
            </button>
          ))}
          <button className="quick-task-btn quick-task-btn--cancel" onClick={() => setQuickMenuOpen(false)}>
            Отмена
          </button>
        </div>
      </div>
    );
  }

  return (
    <button
      className="survivor-card"
      onClick={handleClick}
      onPointerDown={startPress}
      onPointerUp={endPress}
      onPointerLeave={endPress}
    >
      <div className="survivor-card__name">
        {survivor.name}
        {survivor.state.isSick && <span className="survivor-card__badge" title="Болен">🤒</span>}
      </div>
      <div className="survivor-card__meta">{survivor.profession} · {survivor.age} лет</div>
      <div className="survivor-card__bars">
        <div className="bar bar--health" style={{ width: `${Math.round(survivor.state.health)}%` }} title="Здоровье" />
      </div>
      <div className="survivor-card__task">{TASK_LABELS[survivor.currentTask]}</div>
    </button>
  );
}
