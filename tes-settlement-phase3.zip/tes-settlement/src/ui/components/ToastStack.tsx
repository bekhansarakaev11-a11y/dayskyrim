import { useEffect } from 'react';
import { Toast } from '../../systems/notificationSystem';

interface ToastStackProps {
  toasts: Toast[];
  onDismiss: (id: string) => void;
}

export function ToastStack({ toasts, onDismiss }: ToastStackProps) {
  return (
    <div className="toast-stack">
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { toast: Toast; onDismiss: (id: string) => void }) {
  useEffect(() => {
    const id = window.setTimeout(() => onDismiss(toast.id), 3500);
    return () => window.clearTimeout(id);
  }, [toast.id, onDismiss]);

  return (
    <div className={`toast toast--${toast.kind}`} onClick={() => onDismiss(toast.id)}>
      <span className="toast__icon">{toast.icon}</span>
      <span className="toast__text">{toast.text}</span>
    </div>
  );
}
