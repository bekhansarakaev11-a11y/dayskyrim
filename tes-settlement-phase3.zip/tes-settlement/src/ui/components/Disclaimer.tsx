export function Disclaimer() {
  return (
    <p className="disclaimer">
      The Elder Scrolls и связанные с ним элементы вселенной являются интеллектуальной
      собственностью Bethesda Softworks LLC и её правообладателей. Данный проект — неофициальная
      фанатская игра, созданная исключительно в некоммерческих/фанатских целях, и не связана с
      Bethesda Softworks LLC.
    </p>
  );
}
