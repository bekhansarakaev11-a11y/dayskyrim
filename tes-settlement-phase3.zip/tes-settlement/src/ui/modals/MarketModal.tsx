import { GameState, TradableResource } from '../../core/gameEngine';

interface MarketModalProps {
  state: GameState;
  onBuy: (resource: TradableResource, amount: number) => void;
  onSell: (resource: TradableResource, amount: number) => void;
  onClose: () => void;
}

const TRADABLE: TradableResource[] = ['food', 'water', 'wood', 'stone', 'ore', 'iron', 'ingredients', 'medicine', 'fuel'];

const LABELS: Record<TradableResource, string> = {
  food: '🍖 Еда', water: '💧 Вода', wood: '🪵 Древесина', stone: '🪨 Камень',
  ore: '⛏ Руда', iron: '⚒ Железо', ingredients: '🧪 Ингредиенты', medicine: '💊 Лекарства', fuel: '🔥 Топливо',
};

const TRADE_AMOUNT = 5;

export function MarketModal({ state, onBuy, onSell, onClose }: MarketModalProps) {
  const productionEntries = Object.entries(state.lastHourResourceDelta).filter(([, v]) => v !== undefined && Math.abs(v) >= 0.05);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <header className="modal-card__header">
          <div>
            <h2>Рынок и экономика</h2>
            <p className="modal-card__subtitle">Золото: {Math.floor(state.resources.gold)}</p>
          </div>
          <button className="btn btn--icon" onClick={onClose} aria-label="Закрыть">✕</button>
        </header>

        {state.caravan?.active && (
          <p className="modal-card__origin">🐎 Торговый караван в поселении: продажа +20%, покупка дешевле.</p>
        )}

        <section className="modal-card__section">
          <h3>Торговля</h3>
          <div className="market-list">
            {TRADABLE.map((res) => (
              <div key={res} className="market-row">
                <div className="market-row__name">{LABELS[res]}</div>
                <div className="market-row__stock">{Math.floor(state.resources[res])} шт.</div>
                <div className="market-row__price">{state.marketPrices[res].toFixed(1)} зол/шт</div>
                <div className="market-row__actions">
                  <button className="task-btn" onClick={() => onBuy(res, TRADE_AMOUNT)}>Купить {TRADE_AMOUNT}</button>
                  <button className="task-btn" onClick={() => onSell(res, TRADE_AMOUNT)}>Продать {TRADE_AMOUNT}</button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="modal-card__section">
          <h3>Экономика за последний час</h3>
          {productionEntries.length === 0 ? (
            <p className="modal-card__origin">Пока нет данных — пропустите час, чтобы увидеть динамику.</p>
          ) : (
            <ul className="skill-list">
              {productionEntries.map(([key, value]) => (
                <li key={key}>
                  <span>{LABELS[key as TradableResource] ?? key}</span>
                  <span style={{ color: (value ?? 0) >= 0 ? '#7ac68f' : '#c67a7a' }}>
                    {(value ?? 0) >= 0 ? '+' : ''}{(value ?? 0).toFixed(2)}/ч
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
