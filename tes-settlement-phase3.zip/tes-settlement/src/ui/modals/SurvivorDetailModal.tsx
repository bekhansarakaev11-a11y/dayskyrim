import { Survivor, CurrentTask } from '../../entities/survivor';
import { ASSIGNABLE_TASKS, TASK_LABELS } from '../../systems/workSystem';

interface SurvivorDetailModalProps {
  survivor: Survivor;
  onAssignTask: (survivorId: string, task: CurrentTask) => void;
  onClose: () => void;
}

const SKILL_LABELS: Record<string, string> = {
  oneHanded: 'Одноручное', twoHanded: 'Двуручное', archery: 'Стрельба', block: 'Блок',
  smithing: 'Кузнечное дело', alchemy: 'Алхимия', hunting: 'Охота', gathering: 'Сбор',
  construction: 'Строительство', trading: 'Торговля', speech: 'Красноречие', medicine: 'Медицина',
};

const TRAIT_LABELS: Record<string, string> = {
  brave: 'смелый(ая)', cowardly: 'трусливый(ая)', greedy: 'жадный(ая)', kind: 'добрый(ая)',
  cruel: 'жестокий(ая)', calm: 'спокойный(ая)', hotTempered: 'вспыльчивый(ая)',
  hardworking: 'трудолюбивый(ая)', lazy: 'ленивый(ая)', loyal: 'верный(ая)', independent: 'независимый(ая)',
};

const RACE_LABELS: Record<string, string> = {
  nord: 'норд', imperial: 'империец', breton: 'бретонец', redguard: 'редгард', dunmer: 'данмер',
  altmer: 'альтмер', bosmer: 'босмер', orsimer: 'орсимер', khajiit: 'каджит', argonian: 'аргонианин',
};

function StatBar({ label, value, colorClass }: { label: string; value: number; colorClass: string }) {
  return (
    <div className="stat-bar">
      <div className="stat-bar__label">
        <span>{label}</span>
        <span>{Math.round(value)}</span>
      </div>
      <div className="stat-bar__track">
        <div className={`stat-bar__fill ${colorClass}`} style={{ width: `${Math.round(value)}%` }} />
      </div>
    </div>
  );
}

export function SurvivorDetailModal({ survivor, onAssignTask, onClose }: SurvivorDetailModalProps) {
  const topSkills = Object.entries(survivor.skills)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <header className="modal-card__header">
          <div>
            <h2>{survivor.name}</h2>
            <p className="modal-card__subtitle">
              {RACE_LABELS[survivor.race]} · {survivor.gender === 'male' ? 'муж.' : 'жен.'} · {survivor.age} лет
            </p>
          </div>
          <button className="btn btn--icon" onClick={onClose} aria-label="Закрыть">✕</button>
        </header>

        <p className="modal-card__origin">{survivor.origin}</p>

        <div className="modal-card__stats">
          <StatBar label="Здоровье" value={survivor.state.health} colorClass="stat-bar__fill--health" />
          <StatBar label="Голод" value={survivor.state.hunger} colorClass="stat-bar__fill--hunger" />
          <StatBar label="Усталость" value={survivor.state.fatigue} colorClass="stat-bar__fill--fatigue" />
          <StatBar label="Мораль" value={survivor.state.morale} colorClass="stat-bar__fill--morale" />
        </div>

        <section className="modal-card__section">
          <h3>Черты характера</h3>
          <div className="trait-tags">
            {survivor.traits.map((t) => (
              <span key={t} className="trait-tag">{TRAIT_LABELS[t] ?? t}</span>
            ))}
          </div>
        </section>

        <section className="modal-card__section">
          <h3>Основные навыки</h3>
          <ul className="skill-list">
            {topSkills.map(([key, value]) => (
              <li key={key}>
                <span>{SKILL_LABELS[key] ?? key}</span>
                <span>{value}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="modal-card__section">
          <h3>Задача</h3>
          <div className="task-buttons">
            {ASSIGNABLE_TASKS.map((task) => (
              <button
                key={task}
                className={`task-btn ${survivor.currentTask === task ? 'task-btn--active' : ''}`}
                onClick={() => onAssignTask(survivor.id, task)}
              >
                {TASK_LABELS[task]}
              </button>
            ))}
          </div>
        </section>

        {survivor.history.length > 0 && (
          <section className="modal-card__section">
            <h3>История</h3>
            <ul className="history-list">
              {survivor.history.map((h, i) => (
                <li key={i}>{h}</li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </div>
  );
}
