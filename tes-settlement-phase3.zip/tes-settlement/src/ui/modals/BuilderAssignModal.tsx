import { GameState } from '../../core/gameEngine';
import { Building } from '../../entities/building';
import { getMissingResources } from '../../systems/buildingSystem';

interface BuilderAssignModalProps {
  state: GameState;
  building: Building;
  onAssign: (survivorId: string) => void;
  onClose: () => void;
}

const RESOURCE_LABELS: Record<string, string> = { wood: 'Древесина', stone: 'Камень', iron: 'Железо', gold: 'Септимы' };

export function BuilderAssignModal({ state, building, onAssign, onClose }: BuilderAssignModalProps) {
  const missing = getMissingResources(building, state.resources);
  const hasMissing = Object.keys(missing).length > 0;
  const eligible = state.survivors.filter(
    (s) => s.isAlive && s.currentTask !== 'expedition' && s.currentTask !== 'trading',
  );

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <header className="modal-card__header">
          <div>
            <h2>{building.name}</h2>
            <p className="modal-card__subtitle">{building.effectDescription}</p>
          </div>
          <button className="btn btn--icon" onClick={onClose} aria-label="Закрыть">✕</button>
        </header>

        {hasMissing ? (
          <div className="building-missing-block">
            <p className="modal-card__origin">Не хватает ресурсов для этой стройки:</p>
            <ul className="skill-list">
              {(Object.entries(missing) as Array<[string, number]>).map(([key, amount]) => (
                <li key={key}>
                  <span style={{ color: '#c67a7a' }}>{RESOURCE_LABELS[key] ?? key}</span>
                  <span style={{ color: '#c67a7a' }}>не хватает {Math.ceil(amount)}</span>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <section className="modal-card__section">
            <h3>Кто будет строить?</h3>
            {eligible.length === 0 ? (
              <p className="modal-card__origin">Нет доступных жителей.</p>
            ) : (
              <div className="expedition-roster">
                {eligible.map((s) => (
                  <button key={s.id} className="expedition-roster__item" onClick={() => onAssign(s.id)}>
                    <span>{s.name}{s.currentTask === 'building' ? ' (уже строит другое)' : ''}</span>
                    <span className="expedition-roster__meta">Строительство {s.skills.construction}</span>
                  </button>
                ))}
              </div>
            )}
          </section>
        )}
      </div>
    </div>
  );
}
