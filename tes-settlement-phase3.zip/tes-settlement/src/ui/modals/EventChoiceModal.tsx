import { GameEvent } from '../../entities/event';

interface EventChoiceModalProps {
  event: GameEvent;
  onChoose: (choiceId: string) => void;
}

/** В отличие от остальных модалок — без кнопки "закрыть": время приостановлено,
 * пока игрок не примет решение (моральный выбор должен что-то значить). */
export function EventChoiceModal({ event, onChoose }: EventChoiceModalProps) {
  return (
    <div className="modal-overlay">
      <div className="modal-card">
        <header className="modal-card__header">
          <div>
            <h2>{event.title}</h2>
          </div>
        </header>

        <p className="modal-card__origin">{event.description}</p>

        <section className="modal-card__section">
          <div className="task-buttons task-buttons--stacked">
            {event.choices?.map((choice) => (
              <button key={choice.id} className="task-btn task-btn--choice" onClick={() => onChoose(choice.id)}>
                {choice.label}
              </button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
