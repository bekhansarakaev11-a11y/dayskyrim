import { useState } from 'react';
import { GameState } from '../../core/gameEngine';
import { FactionId } from '../../entities/faction';
import { getAvailableQuests } from '../../systems/factionSystem';

interface FactionQuestModalProps {
  state: GameState;
  factionId: FactionId;
  onStartQuest: (questId: string, survivorId: string) => void;
  onClose: () => void;
}

export function FactionQuestModal({ state, factionId, onStartQuest, onClose }: FactionQuestModalProps) {
  const faction = state.factions.find((f) => f.id === factionId);
  const [selectedQuestId, setSelectedQuestId] = useState<string | null>(null);

  if (!faction) return null;

  const quests = getAvailableQuests(state, factionId);
  const eligibleSurvivors = state.survivors.filter(
    (s) => s.isAlive && s.currentTask !== 'expedition' && s.currentTask !== 'trading',
  );

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <header className="modal-card__header">
          <div>
            <h2>{faction.name}</h2>
            <p className="modal-card__subtitle">Репутация: {faction.reputation} · Доверие: {faction.trust}</p>
          </div>
          <button className="btn btn--icon" onClick={onClose} aria-label="Закрыть">✕</button>
        </header>

        <section className="modal-card__section">
          <h3>Доступные задания</h3>
          {quests.length === 0 ? (
            <p className="modal-card__origin">
              Сейчас нет доступных заданий — возможно, все выполнены или нужна более высокая репутация.
            </p>
          ) : (
            <div className="quest-list">
              {quests.map((q) => (
                <button
                  key={q.id}
                  className={`quest-card ${selectedQuestId === q.id ? 'quest-card--selected' : ''}`}
                  onClick={() => setSelectedQuestId(q.id)}
                >
                  <div className="quest-card__title">{q.title}</div>
                  <div className="quest-card__desc">{q.description}</div>
                  <div className="quest-card__meta">~{q.durationHours}ч · +{q.reputationReward} репутации</div>
                </button>
              ))}
            </div>
          )}
        </section>

        {selectedQuestId && (
          <section className="modal-card__section">
            <h3>Отправить жителя</h3>
            {eligibleSurvivors.length === 0 ? (
              <p className="modal-card__origin">Нет свободных жителей.</p>
            ) : (
              <div className="expedition-roster">
                {eligibleSurvivors.map((s) => (
                  <button
                    key={s.id}
                    className="expedition-roster__item"
                    onClick={() => onStartQuest(selectedQuestId, s.id)}
                  >
                    <span>{s.name}</span>
                    <span className="expedition-roster__meta">{s.profession} · Красноречие {s.skills.speech}</span>
                  </button>
                ))}
              </div>
            )}
          </section>
        )}
      </div>
    </div>
  );
}
