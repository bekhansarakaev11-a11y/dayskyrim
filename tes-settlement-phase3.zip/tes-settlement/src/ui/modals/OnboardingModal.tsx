import { useState } from 'react';

interface OnboardingModalProps {
  onFinish: () => void;
}

const STEPS = [
  {
    title: 'Ресурсы поселения',
    text: 'Еда, вода, древесина, руда и другие ресурсы отображаются вверху экрана. Критичные — еда, вода, топливо — всегда на виду; остальные скрыты в разворачиваемом блоке.',
  },
  {
    title: 'Назначение задач',
    text: 'Нажмите на карточку жителя, чтобы открыть его профиль и назначить задачу: охота, сбор, строительство, охрана, готовка, лечение или отдых.',
  },
  {
    title: 'Строительство',
    text: 'Назначьте кого-то на задачу «Строительство» — поселение само начнёт возводить следующее по приоритету здание. Прогресс постройки можно увидеть в разделе «Поселение и здания».',
  },
  {
    title: 'Игровое время',
    text: 'Время можно двигать вручную («Пропустить час» / «Завершить день») или включить автоматический ход времени регулятором в шапке экрана. Пауза остановит его в любой момент.',
  },
];

export function OnboardingModal({ onFinish }: OnboardingModalProps) {
  const [step, setStep] = useState(0);
  const current = STEPS[step];
  const isLast = step === STEPS.length - 1;

  return (
    <div className="modal-overlay">
      <div className="modal-card onboarding-card">
        <div className="onboarding-card__progress">
          {STEPS.map((_, i) => (
            <span key={i} className={`onboarding-dot ${i === step ? 'onboarding-dot--active' : ''}`} />
          ))}
        </div>
        <h2>{current.title}</h2>
        <p className="modal-card__origin">{current.text}</p>
        <div className="task-buttons" style={{ marginTop: 16 }}>
          {step > 0 && (
            <button className="task-btn" onClick={() => setStep((s) => s - 1)}>Назад</button>
          )}
          <button
            className="task-btn task-btn--active"
            onClick={() => (isLast ? onFinish() : setStep((s) => s + 1))}
          >
            {isLast ? 'Начать игру' : 'Далее'}
          </button>
        </div>
      </div>
    </div>
  );
}
