import { useState } from 'react';
import { GameState } from '../../core/gameEngine';
import { ExpeditionGoal } from '../../entities/expedition';

interface ExpeditionModalProps {
  state: GameState;
  locationId: string;
  onLaunch: (locationId: string, survivorIds: string[], goal: ExpeditionGoal) => void;
  onClose: () => void;
}

const GOAL_LABELS: Record<ExpeditionGoal, string> = {
  explore: 'Разведать',
  loot: 'Искать добычу',
  huntThreat: 'Зачистить угрозу',
};

export function ExpeditionModal({ state, locationId, onLaunch, onClose }: ExpeditionModalProps) {
  const location = state.locations.find((l) => l.id === locationId);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [goal, setGoal] = useState<ExpeditionGoal>('explore');

  if (!location) return null;

  const eligible = state.survivors.filter((s) => s.isAlive && s.currentTask !== 'expedition' && s.state.health > 20);

  function toggle(id: string) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={(e) => e.stopPropagation()}>
        <header className="modal-card__header">
          <div>
            <h2>{location.isDiscovered ? location.name : 'Неизвестная территория'}</h2>
            <p className="modal-card__subtitle">Опасность: {location.dangerLevel}/10</p>
          </div>
          <button className="btn btn--icon" onClick={onClose} aria-label="Закрыть">✕</button>
        </header>

        <p className="modal-card__origin">{location.isDiscovered ? location.description : 'Разведайте, чтобы узнать больше.'}</p>

        <section className="modal-card__section">
          <h3>Цель похода</h3>
          <div className="task-buttons">
            {(Object.keys(GOAL_LABELS) as ExpeditionGoal[]).map((g) => (
              <button
                key={g}
                className={`task-btn ${goal === g ? 'task-btn--active' : ''}`}
                onClick={() => setGoal(g)}
              >
                {GOAL_LABELS[g]}
              </button>
            ))}
          </div>
        </section>

        <section className="modal-card__section">
          <h3>Отряд ({selectedIds.length} выбрано)</h3>
          {eligible.length === 0 ? (
            <p className="modal-card__origin">Нет свободных здоровых жителей для похода.</p>
          ) : (
            <div className="expedition-roster">
              {eligible.map((s) => (
                <button
                  key={s.id}
                  className={`expedition-roster__item ${selectedIds.includes(s.id) ? 'expedition-roster__item--selected' : ''}`}
                  onClick={() => toggle(s.id)}
                >
                  <span>{s.name}</span>
                  <span className="expedition-roster__meta">{s.profession} · ❤ {Math.round(s.state.health)}</span>
                </button>
              ))}
            </div>
          )}
        </section>

        <button
          className="btn btn--primary"
          style={{ width: '100%', marginTop: 12 }}
          disabled={selectedIds.length === 0}
          onClick={() => onLaunch(locationId, selectedIds, goal)}
        >
          Отправить экспедицию
        </button>
      </div>
    </div>
  );
}
