import { GameState } from '../../core/gameEngine';
import { Building } from '../../entities/building';
import { getMissingResources, getRecommendedBuildingType } from '../../systems/buildingSystem';
import { UI_TEXTURES } from '../assets';

interface BuildingsScreenProps {
  state: GameState;
  onSelectBuilding: (buildingId: string) => void;
  onClose: () => void;
}

const RESOURCE_LABELS: Record<string, string> = { wood: 'Древесина', stone: 'Камень', iron: 'Железо', gold: 'Септимы' };

function statusLabel(b: Building, isRecommended: boolean): string {
  if (b.isBuilt) return `Уровень ${b.level}${b.level < b.maxLevel ? ` / ${b.maxLevel}` : ' (макс.)'}`;
  if (isRecommended) return 'Рекомендуем построить';
  return 'Не построено';
}

export function BuildingsScreen({ state, onSelectBuilding, onClose }: BuildingsScreenProps) {
  const recommendedType = getRecommendedBuildingType(state);
  const buildersNow = state.survivors.filter((s) => s.isAlive && s.currentTask === 'building').length;

  const sorted = [...state.buildings].sort((a, b) => {
    if (a.isBuilt !== b.isBuilt) return a.isBuilt ? -1 : 1;
    return a.type === recommendedType ? -1 : b.type === recommendedType ? 1 : 0;
  });

  return (
    <div className="screen buildings-screen">
      <header className="settlement-header">
        <button className="btn btn--icon" onClick={onClose} aria-label="Назад">←</button>
        <div className="settlement-header__day">Поселение и здания</div>
        <div style={{ width: 40 }} />
      </header>

      <p className="modal-card__origin" style={{ margin: '8px 0' }}>
        Строителей сейчас работает: {buildersNow}. Нажмите на здание, чтобы назначить строителя —
        строить можно в любом порядке, если хватает ресурсов и свободных жителей.
      </p>

      <div className="buildings-list">
        {sorted.map((b) => {
          const isRecommended = !b.isBuilt && b.type === recommendedType;
          const isMaxed = b.isBuilt && b.level >= b.maxLevel;
          const missing = isMaxed ? {} : getMissingResources(b, state.resources);
          const hasMissing = Object.keys(missing).length > 0;
          const activeBuilders = state.survivors.filter((s) => s.isAlive && b.assignedSurvivorIds.includes(s.id) && s.currentTask === 'building');

          return (
            <button
              key={b.id}
              className="building-card building-card--tappable"
              onClick={() => !isMaxed && onSelectBuilding(b.id)}
              disabled={isMaxed}
            >
              <div className="building-card__header">
                <span className="building-card__name">
                  {b.name}
                  {isRecommended && <img className="recommended-badge" src={UI_TEXTURES.badge} alt="Рекомендуем" title="Рекомендуем построить" />}
                </span>
                <span className="building-card__status">{statusLabel(b, isRecommended)}</span>
              </div>
              <p className="building-card__effect">{b.effectDescription}</p>
              {activeBuilders.length > 0 && (
                <p className="building-card__builders">Строит: {activeBuilders.map((s) => s.name).join(', ')}</p>
              )}
              {hasMissing && (
                <p className="building-card__missing">
                  Не хватает: {(Object.entries(missing) as Array<[string, number]>).map(([k, v]) => `${RESOURCE_LABELS[k] ?? k} (−${Math.ceil(v)})`).join(', ')}
                </p>
              )}
              {(!b.isBuilt || b.level < b.maxLevel) && (
                <div className="stat-bar stat-bar--construction">
                  <div className="stat-bar__track">
                    <div
                      className="stat-bar__fill"
                      style={{ width: `${Math.min(100, Math.round(b.constructionProgress))}%` }}
                    />
                  </div>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
