import { GameState } from '../../core/gameEngine';
import { Building } from '../../entities/building';
import { BUILD_PRIORITY } from '../../data/buildings';

interface BuildingsScreenProps {
  state: GameState;
  onAssignBuilder: (survivorId: string) => void;
  onClose: () => void;
}

function statusLabel(b: Building, isNextInQueue: boolean): string {
  if (b.isBuilt) return `Уровень ${b.level}${b.level < b.maxLevel ? ` / ${b.maxLevel}` : ' (макс.)'}`;
  if (isNextInQueue) return 'Следующее в очереди на постройку';
  return 'Не построено';
}

export function BuildingsScreen({ state, onAssignBuilder, onClose }: BuildingsScreenProps) {
  const nextToBuildType = BUILD_PRIORITY.find((type) => !state.buildings.find((b) => b.type === type)?.isBuilt);
  const freeSurvivors = state.survivors.filter(
    (s) => s.isAlive && s.currentTask !== 'expedition' && s.currentTask !== 'trading' && s.currentTask !== 'building',
  );
  const buildersNow = state.survivors.filter((s) => s.isAlive && s.currentTask === 'building').length;

  const sorted = [...state.buildings].sort((a, b) => {
    if (a.isBuilt !== b.isBuilt) return a.isBuilt ? -1 : 1;
    return a.type === nextToBuildType ? -1 : b.type === nextToBuildType ? 1 : 0;
  });

  return (
    <div className="screen buildings-screen">
      <header className="settlement-header">
        <button className="btn btn--icon" onClick={onClose} aria-label="Назад">←</button>
        <div className="settlement-header__day">Поселение и здания</div>
        <div style={{ width: 40 }} />
      </header>

      <p className="modal-card__origin" style={{ margin: '8px 0' }}>
        Строителей сейчас работает: {buildersNow}. Назначьте свободного жителя на задачу «Строительство»,
        чтобы возводить и улучшать здания по очереди приоритета.
      </p>

      {freeSurvivors.length > 0 && (
        <div className="expedition-roster" style={{ marginBottom: 12 }}>
          {freeSurvivors.map((s) => (
            <button key={s.id} className="expedition-roster__item" onClick={() => onAssignBuilder(s.id)}>
              <span>{s.name}</span>
              <span className="expedition-roster__meta">Строительство {s.skills.construction}</span>
            </button>
          ))}
        </div>
      )}

      <div className="buildings-list">
        {sorted.map((b) => {
          const isNext = !b.isBuilt && b.type === nextToBuildType;
          return (
            <div key={b.id} className="building-card">
              <div className="building-card__header">
                <span className="building-card__name">{b.name}</span>
                <span className="building-card__status">{statusLabel(b, isNext)}</span>
              </div>
              <p className="building-card__effect">{b.effectDescription}</p>
              {(!b.isBuilt || b.level < b.maxLevel) && (
                <div className="stat-bar">
                  <div className="stat-bar__track">
                    <div
                      className="stat-bar__fill stat-bar__fill--morale"
                      style={{ width: `${Math.min(100, Math.round(b.constructionProgress))}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
