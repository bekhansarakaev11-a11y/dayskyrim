import { useState } from 'react';
import { GameState } from '../../core/gameEngine';
import { getTimeOfDay, TIME_OF_DAY_LABELS, getSeasonMonth } from '../../core/timeSystem';
import { CurrentTask } from '../../entities/survivor';
import { getStorageCapacity, getHousingCapacity, getNextMealHour } from '../../systems/economySystem';
import { SurvivorQuickCard } from '../components/SurvivorQuickCard';
import { ClockSpeed } from '../hooks/useGameClock';
import { RESOURCE_ICONS, NAV_ICONS, CLOCK_ICONS } from '../assets';

interface SettlementScreenProps {
  state: GameState;
  onAdvanceHour: () => void;
  onAdvanceDay: () => void;
  onSelectSurvivor: (id: string) => void;
  onQuickAssignTask: (id: string, task: CurrentTask) => void;
  onOpenMarket: () => void;
  onOpenMap: () => void;
  onOpenFactions: () => void;
  onOpenBuildings: () => void;
  onSave: () => void;
  onExitToMenu: () => void;
  isClockPaused: boolean;
  clockSpeed: ClockSpeed;
  onToggleClockPause: () => void;
  onSetClockSpeed: (speed: ClockSpeed) => void;
}

const RESOURCE_NAMES: Record<string, string> = {
  food: 'Еда', water: 'Вода', wood: 'Древесина', stone: 'Камень',
  ore: 'Руда', iron: 'Железо', ingredients: 'Ингредиенты', medicine: 'Зелья',
  gold: 'Септимы', fuel: 'Топливо',
};

const CRITICAL_RESOURCES = ['food', 'water', 'fuel'];

function ResourcePill({ resKey, value, capacity, delta, nextMealHour }: { resKey: string; value: number; capacity: number; delta?: number; nextMealHour?: number }) {
  const isCapped = resKey !== 'gold';
  return (
    <div className="resource-pill" title={RESOURCE_NAMES[resKey] ?? resKey}>
      <img className="resource-pill__icon" src={RESOURCE_ICONS[resKey]} alt="" aria-hidden="true" />
      <span className="resource-pill__label">{RESOURCE_NAMES[resKey] ?? resKey}</span>
      <span className="resource-pill__value">{Math.floor(value)}{isCapped ? ` / ${capacity}` : ''}</span>
      {resKey === 'food' ? (
        nextMealHour !== undefined && (
          <span className="resource-pill__delta">до приёма пищи: {String(nextMealHour).padStart(2, '0')}:00</span>
        )
      ) : (
        delta !== undefined && Math.abs(delta) >= 0.05 && (
          <span className={`resource-pill__delta ${delta >= 0 ? 'resource-pill__delta--up' : 'resource-pill__delta--down'}`}>
            {delta >= 0 ? '+' : ''}{delta.toFixed(1)}/ч
          </span>
        )
      )}
    </div>
  );
}

function NavButton({ icon, label, badge, onClick }: { icon: string; label: string; badge?: string; onClick: () => void }) {
  return (
    <button className="btn btn--secondary nav-btn" onClick={onClick}>
      <img className="nav-btn__icon" src={icon} alt="" aria-hidden="true" />
      <span>{label}{badge ? ` ${badge}` : ''}</span>
    </button>
  );
}

export function SettlementScreen({
  state, onAdvanceHour, onAdvanceDay, onSelectSurvivor, onQuickAssignTask,
  onOpenMarket, onOpenMap, onOpenFactions, onOpenBuildings, onSave, onExitToMenu,
  isClockPaused, clockSpeed, onToggleClockPause, onSetClockSpeed,
}: SettlementScreenProps) {
  const [showAllResources, setShowAllResources] = useState(false);

  const aliveSurvivors = state.survivors.filter((s) => s.isAlive);
  const deadCount = state.survivors.length - aliveSurvivors.length;
  const recentJournal = [...state.journal].slice(-8).reverse();
  const timeOfDay = getTimeOfDay(state.hour);
  const season = getSeasonMonth(state.day);
  const hourLabel = `${String(state.hour).padStart(2, '0')}:00`;
  const capacity = getStorageCapacity(state.buildings);
  const housingCapacity = getHousingCapacity(state.buildings);
  const isOvercrowded = aliveSurvivors.length > housingCapacity;

  const busyCount = aliveSurvivors.filter((s) => s.currentTask !== 'idle' && s.currentTask !== 'resting').length;
  const idleCount = aliveSurvivors.filter((s) => s.currentTask === 'idle').length;
  const sickCount = aliveSurvivors.filter((s) => s.state.isSick).length;

  const resourceEntries = Object.entries(state.resources) as Array<[string, number]>;
  const criticalEntries = resourceEntries.filter(([key]) => CRITICAL_RESOURCES.includes(key));
  const otherEntries = resourceEntries.filter(([key]) => !CRITICAL_RESOURCES.includes(key));

  const timeBlocked = state.isGameOver || !!state.pendingEvent;

  return (
    <div className={`screen settlement-screen time-${timeOfDay}`}>
      <header className="settlement-header">
        <button className="btn btn--icon" onClick={onExitToMenu} aria-label="В меню">←</button>
        <div className="settlement-header__time">
          <div className="settlement-header__day">День {state.day} / {state.maxDays}</div>
          <div className="settlement-header__season">{season.name}{season.isWinter ? ' ❄' : ''}</div>
          <div className="settlement-header__clock">{TIME_OF_DAY_LABELS[timeOfDay]} · {hourLabel}</div>
        </div>
        <button className="btn btn--icon" onClick={onSave} aria-label="Сохранить">💾</button>
      </header>

      <div className="clock-controls">
        <button className="clock-pause-btn" onClick={onToggleClockPause} disabled={timeBlocked} aria-label={isClockPaused ? 'Продолжить' : 'Пауза'}>
          <img src={isClockPaused ? CLOCK_ICONS.play : CLOCK_ICONS.pause} alt="" aria-hidden="true" />
        </button>
        <div className="clock-controls__speed">
          {([1, 2, 3] as ClockSpeed[]).map((sp) => (
            <button
              key={sp}
              className={`clock-speed-btn ${clockSpeed === sp ? 'clock-speed-btn--active' : ''}`}
              onClick={() => onSetClockSpeed(sp)}
            >
              ×{sp}
            </button>
          ))}
        </div>
        {!isClockPaused && !timeBlocked && <span style={{ fontSize: 11, color: 'var(--color-frost)' }}>автоход</span>}
      </div>

      {state.caravan?.active && (
        <div className="caravan-banner" onClick={onOpenMarket}>
          🐎 В поселении торговый караван — выгодные цены! Нажмите, чтобы торговать.
        </div>
      )}

      <section className="resources-bar resources-bar--critical">
        {criticalEntries.map(([key, value]) => (
          <ResourcePill key={key} resKey={key} value={value} capacity={capacity} delta={state.lastHourResourceDelta[key as keyof typeof state.lastHourResourceDelta]} nextMealHour={key === 'food' ? getNextMealHour(state.hour) : undefined} />
        ))}
      </section>
      <button className="resources-toggle" onClick={() => setShowAllResources((v) => !v)}>
        {showAllResources ? '▲ Скрыть остальные ресурсы' : '▼ Все ресурсы'}
      </button>
      {showAllResources && (
        <section className="resources-bar">
          {otherEntries.map(([key, value]) => (
            <ResourcePill key={key} resKey={key} value={value} capacity={capacity} delta={state.lastHourResourceDelta[key as keyof typeof state.lastHourResourceDelta]} nextMealHour={key === 'food' ? getNextMealHour(state.hour) : undefined} />
          ))}
        </section>
      )}

      <div className="nav-grid">
        <NavButton icon={NAV_ICONS.buildings} label="Поселение и здания" onClick={onOpenBuildings} />
        <NavButton icon={NAV_ICONS.market} label="Рынок и экономика" onClick={onOpenMarket} />
        <NavButton
          icon={NAV_ICONS.map}
          label="Карта"
          badge={state.expeditions.length > 0 ? `(в пути: ${state.expeditions.length})` : undefined}
          onClick={onOpenMap}
        />
        <NavButton
          icon={NAV_ICONS.factions}
          label="Фракции"
          badge={state.activeFactionQuests.length > 0 ? `(в процессе: ${state.activeFactionQuests.length})` : undefined}
          onClick={onOpenFactions}
        />
      </div>

      <section className="survivors-section">
        <h2>
          Жители ({aliveSurvivors.length} / {housingCapacity}{deadCount > 0 ? `, погибло: ${deadCount}` : ''})
          {isOvercrowded && <span className="overcrowded-badge" title="Не хватает жилья — падает мораль"> ⚠ Перенаселение</span>}
        </h2>
        <div className="tasks-overview">
          <span className="tasks-overview__item">⚒ Заняты: {busyCount}</span>
          <span className="tasks-overview__item">💤 Простаивают: {idleCount}</span>
          <span className="tasks-overview__item">🤒 Больны: {sickCount}</span>
        </div>
        <div className="survivors-list">
          {aliveSurvivors.map((s) => (
            <SurvivorQuickCard key={s.id} survivor={s} onOpenDetails={onSelectSurvivor} onQuickAssign={onQuickAssignTask} />
          ))}
        </div>
      </section>

      <section className="journal-section">
        <h2>Хроника</h2>
        <ul className="journal-list">
          {recentJournal.map((entry, i) => (
            <li key={i}>День {entry.day} — {entry.text}</li>
          ))}
        </ul>
      </section>

      <footer className="settlement-footer settlement-footer--split">
        <button className="btn btn--secondary" onClick={onAdvanceHour} disabled={timeBlocked}>
          Пропустить час
        </button>
        <button className="btn btn--primary" onClick={onAdvanceDay} disabled={timeBlocked}>
          Завершить день
        </button>
      </footer>
    </div>
  );
}
