import { GameState } from '../../core/gameEngine';
import { getTimeOfDay, TIME_OF_DAY_LABELS } from '../../core/timeSystem';
import { TASK_LABELS } from '../../systems/workSystem';
import { getStorageCapacity } from '../../systems/economySystem';

interface SettlementScreenProps {
  state: GameState;
  onAdvanceHour: () => void;
  onAdvanceDay: () => void;
  onSelectSurvivor: (id: string) => void;
  onOpenMarket: () => void;
  onSave: () => void;
  onExitToMenu: () => void;
}

const RESOURCE_LABELS: Record<string, string> = {
  food: '🍖 Еда', water: '💧 Вода', wood: '🪵 Древесина', stone: '🪨 Камень',
  ore: '⛏ Руда', iron: '⚒ Железо', ingredients: '🧪 Ингредиенты', medicine: '💊 Лекарства',
  gold: '💰 Золото', fuel: '🔥 Топливо',
};

export function SettlementScreen({
  state, onAdvanceHour, onAdvanceDay, onSelectSurvivor, onOpenMarket, onSave, onExitToMenu,
}: SettlementScreenProps) {
  const aliveSurvivors = state.survivors.filter((s) => s.isAlive);
  const deadCount = state.survivors.length - aliveSurvivors.length;
  const recentJournal = [...state.journal].slice(-8).reverse();
  const timeOfDay = getTimeOfDay(state.hour);
  const hourLabel = `${String(state.hour).padStart(2, '0')}:00`;
  const capacity = getStorageCapacity(state.buildings);

  return (
    <div className={`screen settlement-screen time-${timeOfDay}`}>
      <header className="settlement-header">
        <button className="btn btn--icon" onClick={onExitToMenu} aria-label="В меню">←</button>
        <div className="settlement-header__time">
          <div className="settlement-header__day">День {state.day} / {state.maxDays}</div>
          <div className="settlement-header__clock">{TIME_OF_DAY_LABELS[timeOfDay]} · {hourLabel}</div>
        </div>
        <button className="btn btn--icon" onClick={onSave} aria-label="Сохранить">💾</button>
      </header>

      {state.caravan?.active && (
        <div className="caravan-banner" onClick={onOpenMarket}>
          🐎 В поселении торговый караван — выгодные цены! Нажмите, чтобы торговать.
        </div>
      )}

      <section className="resources-bar">
        {(Object.entries(state.resources) as Array<[string, number]>).map(([key, value]) => {
          const delta = state.lastHourResourceDelta[key as keyof typeof state.lastHourResourceDelta];
          const isCapped = key !== 'gold';
          return (
            <div key={key} className="resource-pill" title={RESOURCE_LABELS[key] ?? key}>
              <span className="resource-pill__label">{RESOURCE_LABELS[key] ?? key}</span>
              <span className="resource-pill__value">
                {Math.floor(value)}{isCapped ? ` / ${capacity}` : ''}
              </span>
              {delta !== undefined && Math.abs(delta) >= 0.05 && (
                <span className={`resource-pill__delta ${delta >= 0 ? 'resource-pill__delta--up' : 'resource-pill__delta--down'}`}>
                  {delta >= 0 ? '+' : ''}{delta.toFixed(1)}/ч
                </span>
              )}
            </div>
          );
        })}
      </section>

      <button className="btn btn--secondary market-btn" onClick={onOpenMarket}>Рынок и экономика</button>

      <section className="survivors-section">
        <h2>Жители ({aliveSurvivors.length}{deadCount > 0 ? `, погибло: ${deadCount}` : ''})</h2>
        <div className="survivors-list">
          {aliveSurvivors.map((s) => (
            <button key={s.id} className="survivor-card" onClick={() => onSelectSurvivor(s.id)}>
              <div className="survivor-card__name">
                {s.name}
                {s.state.isSick && <span className="survivor-card__badge" title="Болен">🤒</span>}
              </div>
              <div className="survivor-card__meta">{s.profession} · {s.age} лет</div>
              <div className="survivor-card__bars">
                <div className="bar bar--health" style={{ width: `${Math.round(s.state.health)}%` }} title="Здоровье" />
              </div>
              <div className="survivor-card__task">{TASK_LABELS[s.currentTask]}</div>
            </button>
          ))}
        </div>
      </section>

      <section className="journal-section">
        <h2>Хроника</h2>
        <ul className="journal-list">
          {recentJournal.map((entry, i) => (
            <li key={i}>День {entry.day} — {entry.text}</li>
          ))}
        </ul>
      </section>

      <footer className="settlement-footer settlement-footer--split">
        <button className="btn btn--secondary" onClick={onAdvanceHour} disabled={state.isGameOver}>
          Пропустить час
        </button>
        <button className="btn btn--primary" onClick={onAdvanceDay} disabled={state.isGameOver}>
          Завершить день
        </button>
      </footer>
    </div>
  );
}
