import { GameState } from '../../core/gameEngine';
import { Faction, FactionId } from '../../entities/faction';

interface FactionsScreenProps {
  state: GameState;
  onSelectFaction: (factionId: FactionId) => void;
  onClose: () => void;
}

function reputationLabel(rep: number): string {
  if (rep >= 50) return 'Союзники';
  if (rep >= 15) return 'Уважают';
  if (rep >= -14) return 'Нейтрально';
  if (rep >= -49) return 'Недовольны';
  return 'Враждебны';
}

export function FactionsScreen({ state, onSelectFaction, onClose }: FactionsScreenProps) {
  const discovered = state.factions.filter((f) => f.isDiscovered);
  const activeQuestsByFaction = new Map<string, number>();
  state.activeFactionQuests.forEach((q) => {
    activeQuestsByFaction.set(q.factionId, (activeQuestsByFaction.get(q.factionId) ?? 0) + 1);
  });

  return (
    <div className="screen factions-screen">
      <header className="settlement-header">
        <button className="btn btn--icon" onClick={onClose} aria-label="Назад">←</button>
        <div className="settlement-header__day">Фракции</div>
        <div style={{ width: 40 }} />
      </header>

      <div className="factions-list">
        {discovered.map((f: Faction) => (
          <button key={f.id} className="faction-card" onClick={() => onSelectFaction(f.id)}>
            <div className="faction-card__header">
              <span className="faction-card__name">{f.name}</span>
              <span className="faction-card__rep-label">{reputationLabel(f.reputation)}</span>
            </div>
            <div className="stat-bar">
              <div className="stat-bar__label">
                <span>Репутация</span>
                <span>{f.reputation}</span>
              </div>
              <div className="stat-bar__track">
                <div
                  className="stat-bar__fill stat-bar__fill--morale"
                  style={{ width: `${((f.reputation + 100) / 200) * 100}%` }}
                />
              </div>
            </div>
            {(activeQuestsByFaction.get(f.id) ?? 0) > 0 && (
              <div className="faction-card__active">В процессе: {activeQuestsByFaction.get(f.id)}</div>
            )}
          </button>
        ))}
        {discovered.length === 0 && <p className="modal-card__origin">Фракции ещё не обнаружены.</p>}
      </div>
    </div>
  );
}
