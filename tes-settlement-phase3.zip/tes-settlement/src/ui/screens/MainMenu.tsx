import { Disclaimer } from '../components/Disclaimer';

interface MainMenuProps {
  hasSave: boolean;
  onNewGame: () => void;
  onContinue: () => void;
}

export function MainMenu({ hasSave, onNewGame, onContinue }: MainMenuProps) {
  return (
    <div className="screen main-menu">
      <div className="main-menu__content">
        <h1 className="main-menu__title">Последний очаг Скайрима</h1>
        <p className="main-menu__subtitle">The Elder Scrolls: Settlement Simulator</p>

        <div className="main-menu__buttons">
          {hasSave && (
            <button className="btn btn--primary" onClick={onContinue}>
              Продолжить
            </button>
          )}
          <button className="btn btn--secondary" onClick={onNewGame}>
            {hasSave ? 'Начать заново' : 'Новая игра'}
          </button>
        </div>
      </div>

      <Disclaimer />
    </div>
  );
}
