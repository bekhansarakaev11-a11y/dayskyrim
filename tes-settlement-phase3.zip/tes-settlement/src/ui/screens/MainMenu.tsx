import { useState } from 'react';
import { Disclaimer } from '../components/Disclaimer';
import { ScenarioId } from '../../core/gameEngine';
import { SCENARIOS } from '../../data/scenarios';

interface MainMenuProps {
  hasSave: boolean;
  onNewGame: (scenarioId: ScenarioId) => void;
  onContinue: () => void;
}

export function MainMenu({ hasSave, onNewGame, onContinue }: MainMenuProps) {
  const [showScenarioPicker, setShowScenarioPicker] = useState(false);

  if (showScenarioPicker) {
    return (
      <div className="screen main-menu main-menu--scenarios">
        <div className="main-menu__content">
          <h1 className="main-menu__title" style={{ fontSize: 20 }}>Выберите сценарий</h1>
          <div className="scenario-list">
            {(Object.values(SCENARIOS)).map((sc) => (
              <button key={sc.id} className="scenario-card" onClick={() => onNewGame(sc.id)}>
                <div className="scenario-card__title">{sc.title}</div>
                <div className="scenario-card__desc">{sc.description}</div>
              </button>
            ))}
          </div>
          <button className="btn btn--secondary" style={{ width: '100%', marginTop: 12 }} onClick={() => setShowScenarioPicker(false)}>
            Назад
          </button>
        </div>
        <Disclaimer />
      </div>
    );
  }

  return (
    <div className="screen main-menu">
      <div className="main-menu__content">
        <h1 className="main-menu__title">Последний очаг Скайрима</h1>
        <p className="main-menu__subtitle">The Elder Scrolls: Settlement Simulator</p>

        <div className="main-menu__buttons">
          {hasSave && (
            <button className="btn btn--primary" onClick={onContinue}>
              Продолжить
            </button>
          )}
          <button className="btn btn--secondary" onClick={() => setShowScenarioPicker(true)}>
            {hasSave ? 'Начать заново' : 'Новая игра'}
          </button>
        </div>
      </div>

      <Disclaimer />
    </div>
  );
}
