import { GameState } from '../../core/gameEngine';
import { MapLocation, LocationType } from '../../entities/location';

interface MapScreenProps {
  state: GameState;
  onSelectLocation: (locationId: string) => void;
  onClose: () => void;
}

const LOCATION_ICONS: Record<LocationType, string> = {
  settlement: '🏕️', city: '🏰', forest: '🌲', mine: '⛏️', farm: '🌾',
  ruinedHut: '🛖', banditCamp: '⚔️', nordicRuins: '🗿', cave: '🕳️',
  tradingPost: '🛒', unknown: '❓',
};

export function MapScreen({ state, onSelectLocation, onClose }: MapScreenProps) {
  const travelingIds = new Set(
    state.expeditions.filter((e) => e.status === 'traveling').map((e) => e.locationId),
  );

  return (
    <div className="screen map-screen">
      <header className="settlement-header">
        <button className="btn btn--icon" onClick={onClose} aria-label="Назад">←</button>
        <div className="settlement-header__day">Карта региона</div>
        <div style={{ width: 40 }} />
      </header>

      <div className="map-canvas">
        {state.locations.map((loc: MapLocation) => {
          const isTraveling = travelingIds.has(loc.id);
          const isSettlement = loc.type === 'settlement';
          return (
            <button
              key={loc.id}
              className={`map-pin ${loc.isDiscovered ? '' : 'map-pin--fog'} ${isTraveling ? 'map-pin--traveling' : ''}`}
              style={{ left: `${loc.x}%`, top: `${loc.y}%` }}
              onClick={() => !isSettlement && onSelectLocation(loc.id)}
              disabled={isSettlement}
            >
              <span className="map-pin__icon">{loc.isDiscovered ? LOCATION_ICONS[loc.type] : '❓'}</span>
              <span className="map-pin__label">{loc.isDiscovered ? loc.name : 'Неизвестно'}</span>
              {isTraveling && <span className="map-pin__badge">В пути</span>}
            </button>
          );
        })}
      </div>

      {state.expeditions.length > 0 && (
        <section className="expeditions-section">
          <h2>Активные экспедиции</h2>
          <ul className="journal-list">
            {state.expeditions.map((e) => {
              const loc = state.locations.find((l) => l.id === e.locationId);
              const hoursLeft = Math.max(0, e.returnsAtAbsoluteHour - (state.day * 24 + state.hour));
              return (
                <li key={e.id}>
                  Отряд ({e.survivorIds.length}) движется к «{loc?.name ?? '?'}» — вернутся через ~{hoursLeft}ч.
                </li>
              );
            })}
          </ul>
        </section>
      )}
    </div>
  );
}
