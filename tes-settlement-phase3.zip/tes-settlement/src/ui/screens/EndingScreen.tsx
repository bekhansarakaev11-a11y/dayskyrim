import { GameState } from '../../core/gameEngine';
import { ENDING_DEFINITIONS } from '../../data/endings';
import { computeEndingStats } from '../../systems/endingSystem';
import { Disclaimer } from '../components/Disclaimer';

interface EndingScreenProps {
  state: GameState;
  onReturnToMenu: () => void;
}

export function EndingScreen({ state, onReturnToMenu }: EndingScreenProps) {
  const ending = state.endingId ? ENDING_DEFINITIONS[state.endingId] : null;
  const stats = computeEndingStats(state);

  return (
    <div className="screen ending-screen">
      <div className="ending-screen__content">
        <h1 className="ending-screen__title">{ending?.title ?? 'Кампания завершена'}</h1>

        <div className="ending-screen__text">
          {(ending?.paragraphs ?? ['История Последнего очага подошла к концу.']).map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>

        <div className="ending-stats">
          <div className="ending-stats__row"><span>Дней прожито</span><span>{stats.daysSurvived - 1}</span></div>
          <div className="ending-stats__row"><span>Выживших жителей</span><span>{stats.survivorsAlive} / {stats.survivorsTotal}</span></div>
          <div className="ending-stats__row"><span>Погибло</span><span>{stats.deathsCount}</span></div>
          <div className="ending-stats__row"><span>Средняя репутация с фракциями</span><span>{Math.round(stats.averageFactionReputation)}</span></div>
          <div className="ending-stats__row"><span>Завершено заданий фракций</span><span>{stats.completedQuests}</span></div>
          <div className="ending-stats__row"><span>Суммарный уровень построек</span><span>{stats.buildingLevelsTotal}</span></div>
          <div className="ending-stats__row"><span>Септимов накоплено</span><span>{Math.floor(stats.gold)}</span></div>
        </div>

        <button className="btn btn--primary" style={{ width: '100%', marginTop: 16 }} onClick={onReturnToMenu}>
          Вернуться в меню
        </button>
      </div>

      <Disclaimer />
    </div>
  );
}
