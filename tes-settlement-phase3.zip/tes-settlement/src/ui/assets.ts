// Пути к кастомным иконкам и UI-текстурам (заменяют эмодзи-заглушки).
// Файлы лежат в public/, поэтому пути указываются от корня — Vite сам
// подставит правильный base при сборке (см. index.html/vite.config.ts).

export const RESOURCE_ICONS: Record<string, string> = {
  food: '/icons/resource-food.webp',
  water: '/icons/resource-water.webp',
  wood: '/icons/resource-wood.webp',
  stone: '/icons/resource-stone.webp',
  ore: '/icons/resource-ore.webp',
  iron: '/icons/resource-iron.webp',
  ingredients: '/icons/resource-ingredients.webp',
  medicine: '/icons/resource-medicine.webp',
  gold: '/icons/resource-gold.webp',
  fuel: '/icons/resource-fuel.webp',
};

export const NAV_ICONS = {
  buildings: '/icons/nav-buildings.webp',
  market: '/icons/nav-market.webp',
  map: '/icons/nav-map.webp',
  factions: '/icons/nav-factions.webp',
};

export const CLOCK_ICONS = {
  pause: '/icons/clock-pause.webp',
  play: '/icons/clock-play.webp',
};

export const UI_TEXTURES = {
  panel: '/ui/panel.webp',
  btnNormal: '/ui/btn-normal.webp',
  btnActive: '/ui/btn-active.webp',
  barTrack: '/ui/bar-track.webp',
  barFill: '/ui/bar-fill.webp',
  divider: '/ui/divider.webp',
  modalFrame: '/ui/modal-frame.webp',
  badge: '/ui/badge.webp',
  headerStrip: '/ui/header-strip.webp',
};
