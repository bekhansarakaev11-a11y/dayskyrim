import { GameState, CURRENT_SAVE_VERSION, createInitialMarketPrices } from '../core/gameEngine';
import { BUILDING_TEMPLATES } from '../data/buildings';
import { idbSet, idbGet, idbDelete } from './indexedDB';

const SAVE_KEY = 'main_save';

/** Приводит сохранение более старой версии (Phase 1/2, где не было часов,
 * экономики или части зданий) к текущей форме GameState, чтобы не терять
 * прогресс игрока при обновлении игры. */
function migrateSave(raw: GameState): GameState {
  const migrated: GameState = { ...raw };

  if (typeof migrated.hour !== 'number') {
    migrated.hour = 7;
  }

  // Phase 3: недостающие ресурсы/поля экономики.
  if (typeof (migrated.resources as any).ore !== 'number') {
    migrated.resources = { ...migrated.resources, ore: 0 };
  }
  if (!migrated.marketPrices) {
    migrated.marketPrices = createInitialMarketPrices();
  }
  if (migrated.caravan === undefined) {
    migrated.caravan = null;
  }
  if (typeof migrated.foodShortageStreak !== 'number') {
    migrated.foodShortageStreak = 0;
  }
  if (!migrated.lastHourResourceDelta) {
    migrated.lastHourResourceDelta = {};
  }

  // Phase 6: экспедиции.
  if (!migrated.expeditions) {
    migrated.expeditions = [];
  }

  // Phase 7: задания фракций.
  if (!migrated.activeFactionQuests) {
    migrated.activeFactionQuests = [];
  }

  // Phase 8: события и отношения.
  if (migrated.pendingEvent === undefined) {
    migrated.pendingEvent = null;
  }

  // Phase 9: сценарии старта и связанные множители баланса.
  if (!migrated.scenarioId) {
    migrated.scenarioId = 'peaceful_times';
  }
  if (typeof migrated.raidChanceMultiplier !== 'number') {
    migrated.raidChanceMultiplier = 1;
  }
  if (typeof migrated.negativeEventChanceMultiplier !== 'number') {
    migrated.negativeEventChanceMultiplier = 1;
  }
  if (typeof migrated.lastMealFed !== 'boolean') {
    migrated.lastMealFed = true;
  }

  // Phase 3: в старых сохранениях buildings содержал только 2 здания —
  // достраиваем недостающие типы как "ещё не построенные", чтобы система
  // работ могла их возвести.
  const existingTypes = new Set(migrated.buildings.map((b) => b.type));
  const missing = (Object.keys(BUILDING_TEMPLATES) as Array<keyof typeof BUILDING_TEMPLATES>)
    .filter((type) => !existingTypes.has(type))
    .map((type) => {
      const t = BUILDING_TEMPLATES[type];
      return {
        id: `building_${type}`, type, name: t.name, level: 0, maxLevel: t.maxLevel,
        cost: t.cost, buildTimeHours: t.buildTimeHours, isBuilt: false, isUnderConstruction: false,
        constructionProgress: 0, assignedSurvivorIds: [], effectDescription: t.effectDescription,
      };
    });
  if (missing.length > 0) {
    migrated.buildings = [...migrated.buildings, ...missing];
  }

  // Block 10.4: раньше все "строители" пула работали над одной глобальной целью
  // (без привязки к конкретному зданию через assignedSurvivorIds). Теперь стройка
  // привязана к конкретному зданию — жителей, которые "строили" по старой системе
  // (currentTask='building', но нигде не значатся в assignedSurvivorIds), возвращаем
  // к "без дела", чтобы игрок назначил их заново через новый интерфейс выбора здания.
  const assignedBuilderIds = new Set(migrated.buildings.flatMap((b) => b.assignedSurvivorIds));
  migrated.survivors = migrated.survivors.map((s) =>
    s.currentTask === 'building' && !assignedBuilderIds.has(s.id) ? { ...s, currentTask: 'idle' } : s,
  );

  migrated.version = CURRENT_SAVE_VERSION;
  return migrated;
}

export async function saveGame(state: GameState): Promise<void> {
  const toSave: GameState = { ...state, version: CURRENT_SAVE_VERSION, lastSavedAt: Date.now() };
  await idbSet(SAVE_KEY, toSave);
}

export async function loadGame(): Promise<GameState | undefined> {
  const raw = await idbGet<GameState>(SAVE_KEY);
  if (!raw) return undefined;
  return migrateSave(raw);
}

export async function deleteSave(): Promise<void> {
  await idbDelete(SAVE_KEY);
}

export function exportSave(state: GameState): string {
  return btoa(unescape(encodeURIComponent(JSON.stringify(state))));
}

export function importSave(payload: string): GameState {
  const json = decodeURIComponent(escape(atob(payload)));
  return migrateSave(JSON.parse(json) as GameState);
}

const ONBOARDING_KEY = 'onboarding_completed';

/** Онбординг — свойство устройства/браузера, а не конкретной партии,
 * поэтому хранится отдельным флагом, а не внутри GameState. */
export async function isOnboardingCompleted(): Promise<boolean> {
  const value = await idbGet<boolean>(ONBOARDING_KEY);
  return value === true;
}

export async function markOnboardingCompleted(): Promise<void> {
  await idbSet(ONBOARDING_KEY, true);
}
