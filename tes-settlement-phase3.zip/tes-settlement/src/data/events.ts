import { GameEvent } from '../entities/event';

export const GAME_EVENTS: GameEvent[] = [
  // --- Странники (wanderer) ---
  {
    id: 'wanderer_gift',
    category: 'wanderer',
    title: 'Странник у ворот',
    description: 'Уставший путник просит немного еды в обмен на новости с дороги.',
    weight: 5,
    outcome: {
      journalText: 'Странник поделился новостями и ушёл своей дорогой.',
      resourceChanges: { food: -3 },
      moraleAllDelta: 1,
    },
  },
  {
    id: 'wanderer_shelter_choice',
    category: 'moral',
    title: 'Просьба о ночлеге',
    description: 'Раненый путник просит приютить его на ночь. Еды и так немного.',
    weight: 4,
    minDay: 2,
    choices: [
      {
        id: 'accept',
        label: 'Приютить',
        outcome: {
          journalText: 'Путника приютили. Он отблагодарил поселение перед уходом.',
          resourceChanges: { food: -5, gold: 8 },
          moraleAllDelta: 2,
        },
      },
      {
        id: 'refuse',
        label: 'Отказать',
        outcome: {
          journalText: 'Путнику отказали в ночлеге — он ушёл, бросив тяжёлый взгляд.',
          moraleAllDelta: -2,
        },
      },
    ],
  },
  {
    id: 'wanderer_trader_visit',
    category: 'trade',
    title: 'Странствующий торговец',
    description: 'Одиночный торговец предлагает мелкую сделку — редкие ингредиенты за септимы.',
    weight: 4,
    outcome: {
      journalText: 'Торговец обменял редкие ингредиенты на небольшую плату.',
      resourceChanges: { gold: -10, ingredients: 6 },
    },
  },

  // --- Открытия (discovery) ---
  {
    id: 'discovery_cache',
    category: 'discovery',
    title: 'Тайник у старой дороги',
    description: 'Житель, гулявший неподалёку, наткнулся на спрятанный тайник с припасами.',
    weight: 4,
    outcome: {
      journalText: 'В тайнике нашлись немного септимов и дерева.',
      resourceChanges: { gold: 12, wood: 5 },
    },
  },
  {
    id: 'discovery_spring',
    category: 'discovery',
    title: 'Чистый источник',
    description: 'Неподалёку от лагеря обнаружен родник с чистой водой.',
    weight: 3,
    outcome: {
      journalText: 'Родник даёт запас чистой воды поселению.',
      resourceChanges: { water: 15 },
      moraleAllDelta: 1,
    },
  },
  {
    id: 'discovery_herbs',
    category: 'discovery',
    title: 'Заросли целебных трав',
    description: 'Кто-то из жителей нашёл поляну, заросшую полезными травами.',
    weight: 4,
    outcome: {
      journalText: 'Собран небольшой запас лечебных трав.',
      resourceChanges: { ingredients: 8 },
    },
  },

  // --- Болезни (illness) ---
  {
    id: 'illness_cold',
    category: 'illness',
    title: 'Простуда',
    description: 'Сырая погода дала о себе знать — один из жителей слёг с простудой.',
    weight: 5,
    minDay: 3,
    outcome: {
      journalText: 'Один из жителей заболел, но лечение уже начато.',
      randomSurvivorHealthDelta: -8,
      moraleAllDelta: -1,
    },
  },
  {
    id: 'illness_spread_choice',
    category: 'moral',
    title: 'Угроза заразы',
    description: 'Житель заболел чем-то похожим на заразную хворь. Изолировать его — значит лишить поселение рабочих рук.',
    weight: 3,
    minDay: 5,
    choices: [
      {
        id: 'isolate',
        label: 'Изолировать больного',
        outcome: {
          journalText: 'Больного изолировали — распространение болезни остановлено, но работа встала.',
          moraleAllDelta: -1,
          resourceChanges: { food: -2 },
        },
      },
      {
        id: 'ignore',
        label: 'Не изолировать',
        outcome: {
          journalText: 'Больного не стали изолировать — риск на всё поселение вырос.',
          randomSurvivorHealthDelta: -10,
          moraleAllDelta: -2,
        },
      },
    ],
  },

  // --- Дикая природа (wildlife) ---
  {
    id: 'wildlife_wolves_nearby',
    category: 'wildlife',
    title: 'Вой волков поблизости',
    description: 'Ночью у самой ограды слышен волчий вой — жители встревожены.',
    weight: 5,
    outcome: {
      journalText: 'Волки покружили у лагеря и ушли, не решившись напасть.',
      moraleAllDelta: -1,
    },
  },
  {
    id: 'wildlife_livestock_scare',
    category: 'wildlife',
    title: 'Испуг у фермы',
    description: 'Дикий зверь потревожил хозяйство — часть припасов рассыпана в панике.',
    weight: 3,
    outcome: {
      journalText: 'Зверя отпугнули, но часть еды пришла в негодность.',
      resourceChanges: { food: -4 },
    },
  },

  // --- Кража / конфликты (theft, conflict) ---
  {
    id: 'theft_supplies',
    category: 'theft',
    title: 'Пропажа припасов',
    description: 'Утром обнаружена недостача — кто-то или что-то унесло часть склада.',
    weight: 3,
    minDay: 4,
    outcome: {
      journalText: 'Часть припасов пропала за ночь.',
      resourceChanges: { food: -6, gold: -5 },
      moraleAllDelta: -1,
    },
  },
  {
    id: 'conflict_dispute',
    category: 'conflict',
    title: 'Ссора у костра',
    description: 'Двое жителей поспорили из-за распределения работы — обстановка накалилась.',
    weight: 5,
    outcome: {
      journalText: 'Ссора у костра испортила отношения между спорщиками.',
      relationshipStrain: true,
      moraleAllDelta: -1,
    },
  },
  {
    id: 'conflict_theft_accusation_choice',
    category: 'moral',
    title: 'Обвинение в краже',
    description: 'Один житель обвиняет другого в пропаже вещей. Доказательств нет, только слова.',
    weight: 3,
    minDay: 6,
    choices: [
      {
        id: 'believe',
        label: 'Поверить обвинению',
        outcome: {
          journalText: 'Обвинение принято на веру — обвинённый затаил обиду.',
          relationshipStrain: true,
        },
      },
      {
        id: 'dismiss',
        label: 'Не придавать значения',
        outcome: {
          journalText: 'Спор решили не раздувать — страсти улеглись сами собой.',
          moraleAllDelta: 1,
        },
      },
    ],
  },
  {
    id: 'conflict_reconciliation',
    category: 'conflict',
    title: 'Примирение',
    description: 'После долгой размолвки двое жителей наконец поговорили начистоту.',
    weight: 4,
    minDay: 5,
    outcome: {
      journalText: 'Давний конфликт исчерпан — отношения потеплели.',
      relationshipBoost: true,
      moraleAllDelta: 1,
    },
  },

  // --- Нехватка (shortage) ---
  {
    id: 'shortage_poor_harvest',
    category: 'shortage',
    title: 'Скудный урожай',
    description: 'Погода не благоволила — урожай оказался куда скромнее ожидаемого.',
    weight: 3,
    minDay: 4,
    outcome: {
      journalText: 'Урожай в этом сезоне скромный.',
      resourceChanges: { food: -8 },
    },
  },
  {
    id: 'shortage_tool_wear',
    category: 'shortage',
    title: 'Изношенные инструменты',
    description: 'Инструменты поселения приходят в негодность быстрее обычного.',
    weight: 3,
    minDay: 5,
    outcome: {
      journalText: 'Часть инструментов пришла в негодность — нужен ремонт.',
      resourceChanges: { iron: -3, wood: -3 },
    },
  },

  // --- Магия (magic) ---
  {
    id: 'magic_strange_lights',
    category: 'magic',
    title: 'Странные огни над лесом',
    description: 'Ночью над лесом мерцали непонятные огни — жители гадают, что это было.',
    weight: 2,
    minDay: 4,
    outcome: {
      journalText: 'Огни исчезли к утру, оставив лишь слухи и тревогу.',
      moraleAllDelta: -1,
    },
  },
  {
    id: 'magic_minor_blessing',
    category: 'magic',
    title: 'Благословение источника',
    description: 'Местный родник, по слухам, обладает целебной силой — жители решили им воспользоваться.',
    weight: 2,
    minDay: 6,
    outcome: {
      journalText: 'Вода из источника заметно взбодрила жителей.',
      moraleAllDelta: 3,
      randomSurvivorHealthDelta: 10,
    },
  },
  {
    id: 'magic_artifact_hum',
    category: 'magic',
    title: 'Гудящий камень',
    description: 'В земле найден странный камень, слабо гудящий на ощупь.',
    weight: 2,
    minDay: 8,
    outcome: {
      journalText: 'Камень забрали в поселение — возможно, он ещё пригодится.',
      resourceChanges: { gold: 10 },
    },
  },

  // --- Редкие события (rare) ---
  {
    id: 'rare_meteor',
    category: 'rare',
    title: 'Падающая звезда',
    description: 'Ночью через небо пролетел яркий метеор — редкое и красивое зрелище.',
    weight: 1,
    minDay: 5,
    outcome: {
      journalText: 'Падение звезды подняло дух всего поселения.',
      moraleAllDelta: 4,
    },
  },
  {
    id: 'rare_old_map',
    category: 'rare',
    title: 'Старая карта',
    description: 'Среди вещей найдена потрёпанная карта с пометками — возможно, к чему-то ценному.',
    weight: 1,
    minDay: 7,
    outcome: {
      journalText: 'Карта убрана на хранение — пригодится для будущих походов.',
      resourceChanges: { gold: 15 },
    },
  },
  {
    id: 'rare_veteran_arrival',
    category: 'rare',
    title: 'Ветеран войны',
    description: 'К поселению подошёл ветеран прошлых войн — он ищет, где применить свои навыки.',
    weight: 1,
    minDay: 10,
    outcome: {
      journalText: 'Ветеран задержался в поселении и поделился воинским опытом с жителями.',
      moraleAllDelta: 2,
    },
  },

  // --- Фракционный флейвор (faction) ---
  {
    id: 'faction_patrol_passes',
    category: 'faction',
    title: 'Патруль неподалёку',
    description: 'Мимо поселения прошёл вооружённый патруль — жители на всякий случай насторожились.',
    weight: 3,
    minDay: 3,
    outcome: {
      journalText: 'Патруль прошёл мимо, не заходя в поселение.',
    },
  },
  {
    id: 'faction_rumor',
    category: 'faction',
    title: 'Слухи о войне',
    description: 'Путники приносят противоречивые слухи о положении дел между Империей и повстанцами.',
    weight: 3,
    minDay: 3,
    outcome: {
      journalText: 'Слухи о войне взбудоражили поселение.',
      moraleAllDelta: -1,
    },
  },
  {
    id: 'faction_gift_choice',
    category: 'moral',
    title: 'Подношение от неизвестных',
    description: 'К воротам подброшен мешок с припасами и запиской без подписи. Взять — или проверить, нет ли подвоха?',
    weight: 2,
    minDay: 6,
    choices: [
      {
        id: 'take',
        label: 'Взять мешок',
        outcome: {
          journalText: 'Мешок оказался настоящим подарком — в нём были припасы.',
          resourceChanges: { food: 10, gold: 5 },
        },
      },
      {
        id: 'ignore_gift',
        label: 'Не трогать, на всякий случай',
        outcome: {
          journalText: 'Мешок решили не трогать — осторожность превыше всего.',
          moraleAllDelta: -1,
        },
      },
    ],
  },

  // --- Ещё нападения/угрозы, отличные от системы набегов (raid) ---
  {
    id: 'raid_scare_off',
    category: 'raid',
    title: 'Разведчики бандитов',
    description: 'У края леса замечены двое незнакомцев, похожих на разведчиков бандитской шайки.',
    weight: 3,
    minDay: 3,
    outcome: {
      journalText: 'Разведчиков заметили и прогнали — они не решились подходить ближе.',
      moraleAllDelta: -1,
    },
  },
  {
    id: 'raid_aftermath_help',
    category: 'raid',
    title: 'Помощь после набега',
    description: 'После недавних тревожных слухов о набегах соседи предлагают взаимопомощь.',
    weight: 2,
    minDay: 8,
    outcome: {
      journalText: 'Соседское поселение поделилось небольшим запасом на случай беды.',
      resourceChanges: { food: 6, medicine: 3 },
      moraleAllDelta: 1,
    },
  },

  // --- Ещё немного разнообразия для достижения объёма 30+ ---
  {
    id: 'wanderer_storyteller',
    category: 'wanderer',
    title: 'Бродячий сказитель',
    description: 'Странствующий сказитель заглянул на огонёк и предложил скоротать вечер историями.',
    weight: 3,
    outcome: {
      journalText: 'Вечер историй поднял всем настроение.',
      moraleAllDelta: 2,
    },
  },
  {
    id: 'discovery_lost_tool',
    category: 'discovery',
    title: 'Потерянный инструмент',
    description: 'В траве найден добротный инструмент, оброненный кем-то из прежних путников.',
    weight: 3,
    outcome: {
      journalText: 'Находка пригодится в хозяйстве.',
      resourceChanges: { iron: 4 },
    },
  },
  {
    id: 'illness_food_poisoning',
    category: 'illness',
    title: 'Несвежая еда',
    description: 'Часть припасов оказалась несвежей — у нескольких жителей расстройство желудка.',
    weight: 3,
    minDay: 4,
    outcome: {
      journalText: 'Несвежая еда сказалась на самочувствии, но обошлось без серьёзных последствий.',
      randomSurvivorHealthDelta: -5,
      resourceChanges: { food: -3 },
    },
  },
  {
    id: 'wildlife_deer_herd',
    category: 'wildlife',
    title: 'Стадо оленей',
    description: 'Неподалёку от лагеря замечено стадо оленей — хорошая возможность для охоты.',
    weight: 3,
    outcome: {
      journalText: 'Удачная охота на стадо оленей пополнила запасы.',
      resourceChanges: { food: 10 },
    },
  },
  {
    id: 'theft_between_residents_choice',
    category: 'moral',
    title: 'Голодный проступок',
    description: 'Замечено, что один из жителей тайком брал еду сверх положенного — от отчаяния или жадности?',
    weight: 2,
    minDay: 7,
    choices: [
      {
        id: 'forgive',
        label: 'Простить',
        outcome: {
          journalText: 'Проступок простили — жители оценили милосердие.',
          moraleAllDelta: 2,
        },
      },
      {
        id: 'punish',
        label: 'Наказать',
        outcome: {
          journalText: 'За проступок последовало наказание — часть жителей это не одобрила.',
          relationshipStrain: true,
          moraleAllDelta: -1,
        },
      },
    ],
  },
  {
    id: 'trade_good_deal',
    category: 'trade',
    title: 'Выгодная партия',
    description: 'Проезжий скупщик предлагает неплохую цену за излишки на складе.',
    weight: 3,
    minDay: 3,
    outcome: {
      journalText: 'Сделка с проезжим скупщиком оказалась выгодной.',
      resourceChanges: { wood: -8, gold: 14 },
    },
  },
  {
    id: 'conflict_leadership_dispute',
    category: 'conflict',
    title: 'Спор о решениях',
    description: 'Часть жителей ставит под сомнение принятые в поселении решения.',
    weight: 2,
    minDay: 6,
    outcome: {
      journalText: 'Недовольство улеглось после короткого разговора.',
      moraleAllDelta: -1,
    },
  },
  {
    id: 'magic_shooting_stars',
    category: 'magic',
    title: 'Звездопад',
    description: 'Небо этой ночью усыпано падающими звёздами — редкое и волшебное зрелище.',
    weight: 1,
    minDay: 9,
    outcome: {
      journalText: 'Звездопад стал поводом для радости у всего поселения.',
      moraleAllDelta: 3,
    },
  },
  {
    id: 'rare_reunion',
    category: 'rare',
    title: 'Неожиданная встреча',
    description: 'Один из жителей случайно встретил старого знакомого среди путников.',
    weight: 1,
    minDay: 8,
    outcome: {
      journalText: 'Тёплая встреча со старым знакомым подняла настроение.',
      relationshipBoost: true,
      moraleAllDelta: 1,
    },
  },

  // --- Вера: Девять Божеств (раздел 6.3) ---
  {
    id: 'faith_wandering_priest',
    category: 'faith',
    title: 'Странствующий жрец',
    description: 'Жрец одного из Девяти Божеств просит немного припасов и предлагает взамен благословение поселению.',
    weight: 2,
    minDay: 3,
    choices: [
      {
        id: 'donate',
        label: 'Пожертвовать припасы',
        outcome: {
          journalText: 'Жрец благословил поселение именем Девяти — на душе у жителей стало спокойнее.',
          resourceChanges: { food: -4, gold: -5 },
          moraleAllDelta: 4,
        },
      },
      {
        id: 'refuse_priest',
        label: 'Отказать — припасы нужнее',
        outcome: {
          journalText: 'Жрец пожал плечами и пошёл своей дорогой — припасы остались при поселении.',
        },
      },
    ],
  },
  {
    id: 'faith_shrine_omen',
    category: 'faith',
    title: 'Знамение у святилища',
    description: 'Один из жителей клянётся, что видел знак одного из Девяти Божеств прошлой ночью.',
    weight: 1,
    minDay: 6,
    outcome: {
      journalText: 'Разговоры о знамении разошлись по поселению — многие восприняли это как добрый знак.',
      moraleAllDelta: 2,
    },
  },
];
