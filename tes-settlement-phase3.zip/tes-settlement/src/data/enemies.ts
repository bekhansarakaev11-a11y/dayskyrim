import { EnemyType } from '../entities/enemy';
import { LocationType } from '../entities/location';

/** Какие угрозы могут встретиться в локации данного типа (первая версия — раздел 11 ТЗ). */
export const LOCATION_ENEMIES: Partial<Record<LocationType, EnemyType[]>> = {
  forest: ['wolf'],
  mine: ['bandit'],
  cave: ['wolf', 'bear'],
  banditCamp: ['bandit'],
  nordicRuins: ['draugr'],
  ruinedHut: ['bandit'],
  unknown: ['wolf', 'bandit'],
};

/** Крайне редкий шанс встретить дракона — не привязан к конкретной локации,
 * это должно быть большим, редким событием (раздел 11 ТЗ). */
export const DRAGON_ENCOUNTER_CHANCE = 0.01;
