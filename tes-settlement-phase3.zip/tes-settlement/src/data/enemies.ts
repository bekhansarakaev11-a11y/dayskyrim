import { EnemyType } from '../entities/enemy';
import { LocationType } from '../entities/location';

/** Какие угрозы могут встретиться в локации данного типа (первая версия — раздел 11 ТЗ,
 * расширено разделом 6.5: ледяной тролль, скивер, вампир-одиночка). */
export const LOCATION_ENEMIES: Partial<Record<LocationType, EnemyType[]>> = {
  forest: ['wolf', 'skeever'],
  mine: ['bandit', 'skeever'],
  cave: ['wolf', 'bear', 'iceTroll', 'vampire'],
  banditCamp: ['bandit'],
  nordicRuins: ['draugr', 'iceTroll', 'vampire'],
  ruinedHut: ['bandit', 'skeever'],
  unknown: ['wolf', 'bandit', 'skeever'],
};

/** Крайне редкий шанс встретить дракона — не привязан к конкретной локации,
 * это должно быть большим, редким событием (раздел 11 ТЗ). */
export const DRAGON_ENCOUNTER_CHANCE = 0.01;
