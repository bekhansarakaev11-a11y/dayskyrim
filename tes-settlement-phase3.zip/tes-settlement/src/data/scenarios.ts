import { ScenarioId } from '../core/gameEngine';

export interface ScenarioDefinition {
  id: ScenarioId;
  title: string;
  description: string;
  resourceMultiplier: number; // множитель стартовых ресурсов
  skillBonus: number; // плюс к каждому рабочему навыку именных жителей
  combatSkillBonus: number; // плюс отдельно к боевым навыкам (для "Изгнанников")
  raidChanceMultiplier: number;
  negativeEventChanceMultiplier: number;
  factionReputationModifier: number; // сдвиг стартовой репутации со всеми фракциями
}

export const SCENARIOS: Record<ScenarioId, ScenarioDefinition> = {
  harsh_winter: {
    id: 'harsh_winter',
    title: 'Суровая зима',
    description: 'Меньше припасов и выше риск набегов — но люди в этом лагере закалены нуждой.',
    resourceMultiplier: 0.6,
    skillBonus: 6,
    combatSkillBonus: 0,
    raidChanceMultiplier: 1.6,
    negativeEventChanceMultiplier: 1.3,
    factionReputationModifier: 0,
  },
  peaceful_times: {
    id: 'peaceful_times',
    title: 'Мирное время',
    description: 'Стандартный баланс сил — спокойнее, но и без особых поблажек.',
    resourceMultiplier: 1,
    skillBonus: 0,
    combatSkillBonus: 0,
    raidChanceMultiplier: 0.7,
    negativeEventChanceMultiplier: 0.7,
    factionReputationModifier: 0,
  },
  exiles: {
    id: 'exiles',
    title: 'Изгнанники',
    description: 'Фракции смотрят на вас с подозрением — зато люди умеют держать оружие в руках.',
    resourceMultiplier: 1,
    skillBonus: 0,
    combatSkillBonus: 10,
    raidChanceMultiplier: 1,
    negativeEventChanceMultiplier: 1,
    factionReputationModifier: -20,
  },
};
