import { Faction, FactionId } from '../entities/faction';

export function createStartingFactions(): Faction[] {
  const names: Record<FactionId, string> = {
    imperialLegion: 'Имперский легион',
    stormcloaks: 'Братья Бури',
    darkBrotherhood: 'Тёмное Братство',
    collegeOfWinterhold: 'Коллегия Винтерхолда',
    thievesGuild: 'Гильдия воров',
    companions: 'Соратники',
    caravanTraders: 'Караванщики',
  };

  const hostility: Partial<Record<FactionId, FactionId[]>> = {
    imperialLegion: ['stormcloaks'],
    stormcloaks: ['imperialLegion'],
  };

  return (Object.keys(names) as FactionId[]).map((id) => ({
    id,
    name: names[id],
    reputation: 0,
    trust: id === 'darkBrotherhood' ? 0 : 10,
    isDiscovered: id !== 'darkBrotherhood', // Тёмное Братство скрыто в начале
    isHostileWith: hostility[id] ?? [],
    completedQuestIds: [],
    availableQuestIds: [],
  }));
}
