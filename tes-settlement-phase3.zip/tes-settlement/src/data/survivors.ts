import { Survivor, createSkillsBase, createStateBase } from '../entities/survivor';

// Стартовый состав "Последнего очага" — 6 жителей.
// Навыки заданы вручную под профессию каждого персонажа.
export function createStartingSurvivors(): Survivor[] {
  const base = (): Survivor => ({
    id: '', name: '', age: 0, race: 'nord', gender: 'male', origin: '',
    profession: 'gatherer', skills: createSkillsBase(), state: createStateBase(),
    traits: [], currentTask: 'idle', relationships: [], history: [], inventory: [],
    isAlive: true, joinedOnDay: 0,
  });

  const eilin: Survivor = {
    ...base(), id: 'survivor_eilin', name: 'Эйлин', age: 27, race: 'nord', gender: 'female',
    origin: 'Уроженка Фолкрита, потеряла дом при набеге бандитов.', profession: 'hunter',
    traits: ['brave', 'independent'], history: ['Основательница лагеря вместе с Торвальдом.'],
  };
  eilin.skills.hunting = 35; eilin.skills.archery = 30;

  const torvald: Survivor = {
    ...base(), id: 'survivor_torvald', name: 'Торвальд', age: 34, race: 'nord', gender: 'male',
    origin: 'Бывший наёмник Имперского легиона.', profession: 'guard',
    traits: ['loyal', 'hotTempered'], history: ['Служил в Легионе восемь лет.'],
  };
  torvald.skills.oneHanded = 30; torvald.skills.block = 25;

  const halvar: Survivor = {
    ...base(), id: 'survivor_halvar', name: 'Хальвар', age: 45, race: 'nord', gender: 'male',
    origin: 'Странствующий кузнец из Уайтрана.', profession: 'blacksmith',
    traits: ['hardworking', 'calm'], history: ['Пришёл в лагерь на второй день, ищет тихое место для кузни.'],
  };
  halvar.skills.smithing = 40;

  const freya: Survivor = {
    ...base(), id: 'survivor_freya', name: 'Фрейя', age: 22, race: 'breton', gender: 'female',
    origin: 'Ученица алхимика, бежавшая из разграбленной коллегии.', profession: 'alchemist',
    traits: ['kind', 'independent'], history: ['Несёт с собой потрёпанный травник.'],
  };
  freya.skills.alchemy = 32; freya.skills.medicine = 20;

  const bjorn: Survivor = {
    ...base(), id: 'survivor_bjorn', name: 'Бьорн', age: 19, race: 'nord', gender: 'male',
    origin: 'Младший сын фермера, впервые вдали от дома.', profession: 'farmer',
    traits: ['lazy', 'kind'], history: ['Ещё не привык к тяжёлой работе, но старается.'],
  };
  bjorn.skills.gathering = 20; bjorn.skills.construction = 15;

  const sigrid: Survivor = {
    ...base(), id: 'survivor_sigrid', name: 'Сигрид', age: 51, race: 'nord', gender: 'female',
    origin: 'Повитуха и знахарка из разрушенной деревни.', profession: 'healer',
    traits: ['calm', 'loyal'], history: ['Старейшая в поселении, все её уважают.'],
  };
  sigrid.skills.medicine = 38; sigrid.skills.speech = 25;

  // Стартовые отношения: Эйлин и Торвальд вместе основали лагерь — крепкая
  // дружба и взаимное уважение. Сигрид как старейшую уважают все.
  eilin.relationships = [
    { targetId: torvald.id, type: 'friendship', value: 55 },
    { targetId: sigrid.id, type: 'respect', value: 30 },
  ];
  torvald.relationships = [
    { targetId: eilin.id, type: 'friendship', value: 55 },
    { targetId: sigrid.id, type: 'respect', value: 25 },
  ];
  sigrid.relationships = [
    { targetId: eilin.id, type: 'respect', value: 30 },
    { targetId: torvald.id, type: 'respect', value: 25 },
    { targetId: bjorn.id, type: 'respect', value: 20 },
  ];
  bjorn.relationships = [{ targetId: sigrid.id, type: 'respect', value: 20 }];

  return [eilin, torvald, halvar, freya, bjorn, sigrid];
}
