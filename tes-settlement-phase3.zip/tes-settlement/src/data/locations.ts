import { MapLocation } from '../entities/location';

export function createStartingLocations(): MapLocation[] {
  const list: MapLocation[] = [
    { id: 'loc_settlement', type: 'settlement', name: 'Последний очаг', x: 50, y: 55, isDiscovered: true, dangerLevel: 0, description: 'Ваше поселение.' },
    { id: 'loc_falkreath', type: 'city', name: 'Фолкрит', x: 62, y: 60, isDiscovered: true, dangerLevel: 1, description: 'Ближайший город, рынок и стражники.' },
    { id: 'loc_forest', type: 'forest', name: 'Тёмный лес', x: 40, y: 45, isDiscovered: true, dangerLevel: 2, description: 'Хвойный лес, богат дичью и древесиной.' },
    { id: 'loc_mine', type: 'mine', name: 'Старая шахта', x: 30, y: 65, isDiscovered: false, dangerLevel: 4, description: 'Заброшенная железная шахта.' },
    { id: 'loc_farm', type: 'farm', name: 'Покинутая ферма', x: 55, y: 40, isDiscovered: false, dangerLevel: 1, description: 'Плодородная земля, оставленная хозяевами.' },
    { id: 'loc_hut', type: 'ruinedHut', name: 'Заброшенная хижина', x: 25, y: 35, isDiscovered: false, dangerLevel: 2, description: 'Возможно, там есть припасы.' },
    { id: 'loc_bandit_camp', type: 'banditCamp', name: 'Лагерь бандитов', x: 20, y: 55, isDiscovered: false, dangerLevel: 6, description: 'Опасное логово разбойников.' },
    { id: 'loc_nordic_ruins', type: 'nordicRuins', name: 'Курган Ветрогорье', x: 70, y: 30, isDiscovered: false, dangerLevel: 7, description: 'Древние нордские руины, полные драугров.' },
    { id: 'loc_cave', type: 'cave', name: 'Пещера Ледяных Клыков', x: 15, y: 40, isDiscovered: false, dangerLevel: 5, description: 'Логово хищников.' },
    { id: 'loc_trading_post', type: 'tradingPost', name: 'Перекрёсток караванов', x: 75, y: 50, isDiscovered: false, dangerLevel: 1, description: 'Место встречи торговых караванов.' },
    { id: 'loc_unknown_1', type: 'unknown', name: 'Неизведанные земли (север)', x: 45, y: 15, isDiscovered: false, dangerLevel: 3, description: '???' },
    { id: 'loc_unknown_2', type: 'unknown', name: 'Неизведанные земли (запад)', x: 10, y: 60, isDiscovered: false, dangerLevel: 3, description: '???' },
  ];
  return list;
}
