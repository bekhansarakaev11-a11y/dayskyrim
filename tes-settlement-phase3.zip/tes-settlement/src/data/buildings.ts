import { Building, BuildingType } from '../entities/building';

interface BuildingTemplate {
  type: BuildingType;
  name: string;
  cost: Building['cost'];
  buildTimeHours: number;
  maxLevel: number;
  effectDescription: string;
}

export const BUILDING_TEMPLATES: Record<BuildingType, BuildingTemplate> = {
  housing: { type: 'housing', name: 'Жильё', cost: { wood: 15, stone: 5 }, buildTimeHours: 8, maxLevel: 3, effectDescription: '+2 к вместимости поселения' },
  warehouse: { type: 'warehouse', name: 'Склад', cost: { wood: 20 }, buildTimeHours: 6, maxLevel: 3, effectDescription: 'Увеличивает лимит хранения ресурсов' },
  kitchen: { type: 'kitchen', name: 'Кухня', cost: { wood: 10, stone: 5 }, buildTimeHours: 5, maxLevel: 2, effectDescription: 'Позволяет готовить еду, снижая порчу' },
  forge: { type: 'forge', name: 'Кузница', cost: { wood: 10, stone: 15, iron: 5 }, buildTimeHours: 10, maxLevel: 3, effectDescription: 'Переплавляет руду в железо для построек и снаряжения' },
  farm: { type: 'farm', name: 'Ферма', cost: { wood: 15 }, buildTimeHours: 8, maxLevel: 3, effectDescription: 'Постоянный источник еды' },
  huntingPost: { type: 'huntingPost', name: 'Охотничий пост', cost: { wood: 12 }, buildTimeHours: 5, maxLevel: 2, effectDescription: '+эффективность охоты' },
  infirmary: { type: 'infirmary', name: 'Лечебница', cost: { wood: 12, stone: 8, ingredients: 5 }, buildTimeHours: 9, maxLevel: 2, effectDescription: 'Ускоряет исцеление зельями и снижает риск болезней' },
  alchemyLab: { type: 'alchemyLab', name: 'Алхимическая лаборатория', cost: { wood: 10, ingredients: 10 }, buildTimeHours: 7, maxLevel: 2, effectDescription: 'Производство целебных зелий' },
  workshop: { type: 'workshop', name: 'Мастерская', cost: { wood: 18, iron: 5 }, buildTimeHours: 8, maxLevel: 2, effectDescription: 'Ремонт и производство инструментов' },
  watchtower: { type: 'watchtower', name: 'Сторожевая башня', cost: { wood: 20, stone: 10 }, buildTimeHours: 10, maxLevel: 2, effectDescription: 'Снижает риск нападений' },
  palisade: { type: 'palisade', name: 'Частокол', cost: { wood: 25 }, buildTimeHours: 12, maxLevel: 3, effectDescription: 'Базовая защита поселения' },
  stable: { type: 'stable', name: 'Конюшня', cost: { wood: 15, stone: 5 }, buildTimeHours: 8, maxLevel: 2, effectDescription: 'Ускоряет экспедиции и торговлю' },
  shrine: { type: 'shrine', name: 'Святилище Девяти', cost: { stone: 10, gold: 10 }, buildTimeHours: 6, maxLevel: 3, effectDescription: 'Пассивно поднимает мораль жителей — благословение Девяти Божеств' },
};

export function createStartingBuildings(): Building[] {
  // В начале у игрока уже есть скромное жильё и склад.
  // Остальные здания существуют в состоянии как "ещё не построены" —
  // именно эти записи позволяют системе работ (workSystem) реально
  // возводить их, когда житель назначен на задачу "Строительство".
  const make = (type: BuildingType, built: boolean): Building => {
    const t = BUILDING_TEMPLATES[type];
    return {
      id: `building_${type}`, type, name: t.name, level: built ? 1 : 0, maxLevel: t.maxLevel,
      cost: t.cost, buildTimeHours: t.buildTimeHours, isBuilt: built, isUnderConstruction: false,
      constructionProgress: 0, assignedSurvivorIds: [], effectDescription: t.effectDescription,
    };
  };
  return [
    make('housing', true),
    make('warehouse', true),
    make('kitchen', false),
    make('huntingPost', false),
    make('forge', false),
    make('workshop', false),
    make('alchemyLab', false),
    make('infirmary', false),
    make('farm', false),
    make('watchtower', false),
    make('palisade', false),
    make('stable', false),
    make('shrine', false),
  ];
}

/** Порядок, в котором система работ автоматически выбирает следующее здание
 * для постройки с нуля (до перехода к улучшению уровней уже построенных). */
export const BUILD_PRIORITY: BuildingType[] = [
  'kitchen', 'huntingPost', 'forge', 'workshop', 'alchemyLab',
  'infirmary', 'farm', 'watchtower', 'palisade', 'stable', 'shrine',
];
