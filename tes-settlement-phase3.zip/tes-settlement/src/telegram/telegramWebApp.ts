// Безопасная обёртка над Telegram WebApp API.
// Работает и вне Telegram (например, в обычном браузере при разработке) —
// в этом случае просто деградирует до no-op заглушек.

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

interface TelegramWebAppAPI {
  ready: () => void;
  expand: () => void;
  enableClosingConfirmation: () => void;
  disableVerticalSwipes?: () => void;
  colorScheme: 'light' | 'dark';
  viewportHeight: number;
  viewportStableHeight: number;
  platform: string;
  version: string;
  initData: string;
  initDataUnsafe: {
    user?: TelegramUser;
    start_param?: string;
    auth_date?: number;
    hash?: string;
  };
  BackButton: {
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
  MainButton: {
    show: () => void;
    hide: () => void;
    setText: (text: string) => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
  HapticFeedback?: {
    impactOccurred: (style: 'light' | 'medium' | 'heavy' | 'rigid' | 'soft') => void;
    notificationOccurred: (type: 'error' | 'success' | 'warning') => void;
  };
  openInvoice?: (url: string, callback?: (status: string) => void) => void;
}

declare global {
  interface Window {
    Telegram?: {
      WebApp: TelegramWebAppAPI;
    };
  }
}

class TelegramService {
  private api: TelegramWebAppAPI | null;

  constructor() {
    this.api = typeof window !== 'undefined' && window.Telegram?.WebApp ? window.Telegram.WebApp : null;
  }

  get isAvailable(): boolean {
    return this.api !== null;
  }

  init(): void {
    if (!this.api) return;
    this.api.ready();
    this.api.expand();
    try {
      this.api.enableClosingConfirmation();
    } catch {
      // старые версии клиента могут не поддерживать метод
    }
  }

  get user(): TelegramUser | null {
    return this.api?.initDataUnsafe.user ?? null;
  }

  get initData(): string {
    return this.api?.initData ?? '';
  }

  get colorScheme(): 'light' | 'dark' {
    return this.api?.colorScheme ?? 'dark';
  }

  haptic(style: 'light' | 'medium' | 'heavy' = 'light'): void {
    this.api?.HapticFeedback?.impactOccurred(style);
  }

  hapticNotify(type: 'error' | 'success' | 'warning'): void {
    this.api?.HapticFeedback?.notificationOccurred(type);
  }

  showBackButton(onClick: () => void): void {
    if (!this.api) return;
    this.api.BackButton.onClick(onClick);
    this.api.BackButton.show();
  }

  hideBackButton(onClick?: () => void): void {
    if (!this.api) return;
    if (onClick) this.api.BackButton.offClick(onClick);
    this.api.BackButton.hide();
  }
}

export const telegram = new TelegramService();
