import { GameState } from './gameEngine';
import { applyHourlyWork } from '../systems/workSystem';
import { applyHourlySurvivorState } from '../systems/survivorStateSystem';
import { consumeFoodForSettlement, clampResourcesToCapacity, computeResourceDelta } from '../systems/economySystem';
import { driftPricesTowardBase, maybeTriggerCaravan } from '../systems/marketSystem';

export const HOURS_PER_DAY = 24;

export function isNightHour(hour: number): boolean {
  return hour >= 22 || hour < 6;
}

export type TimeOfDay = 'night' | 'morning' | 'day' | 'evening';

export function getTimeOfDay(hour: number): TimeOfDay {
  if (hour >= 22 || hour < 6) return 'night';
  if (hour < 12) return 'morning';
  if (hour < 18) return 'day';
  return 'evening';
}

export const TIME_OF_DAY_LABELS: Record<TimeOfDay, string> = {
  night: 'Ночь',
  morning: 'Утро',
  day: 'День',
  evening: 'Вечер',
};

/** Продвигает игровое время на один час: производство → потребление еды → лимит
 * склада → голод/здоровье/мораль/болезни → рынок/караваны → хроника. */
export function advanceHour(state: GameState): GameState {
  if (state.isGameOver) return state;

  const night = isNightHour(state.hour);
  const resourcesBefore = state.resources;

  // 1) Работа: производство ресурсов, строительство, эффекты готовки/охраны/лечения.
  const work = applyHourlyWork(state, night);

  // 2) Потребление еды поселением.
  const aliveCount = work.survivors.filter((s) => s.isAlive).length;
  const consumption = consumeFoodForSettlement(work.resources, aliveCount, work.foodConsumptionMultiplier);

  // 3) Лимит склада — излишки производства теряются.
  const clampResult = clampResourcesToCapacity(consumption.resources, work.buildings);

  // 4) Голод/здоровье/мораль/болезни жителей.
  const nextShortageStreak = consumption.fed ? 0 : state.foodShortageStreak + 1;
  const stateTick = applyHourlySurvivorState(work.survivors, night, consumption.fed, nextShortageStreak);

  let nextHour = state.hour + 1;
  let nextDay = state.day;
  const journalAdditions = [...work.journalAdditions];

  if (nextShortageStreak === 1) {
    journalAdditions.push('В поселении не хватает еды! Жители начинают голодать.');
  }
  stateTick.newlySick.forEach((name) => journalAdditions.push(`${name} заболел(а) от голода.`));
  stateTick.deaths.forEach((name) => journalAdditions.push(`${name} погиб(ла).`));
  Object.entries(clampResult.overflow).forEach(([key, amount]) => {
    if (amount && amount > 3) journalAdditions.push(`Склад переполнен: потеряно ${amount.toFixed(1)} (${key}).`);
  });

  let nextState: GameState = {
    ...state,
    hour: nextHour,
    resources: clampResult.resources,
    buildings: work.buildings,
    survivors: stateTick.survivors,
    foodShortageStreak: nextShortageStreak,
  };

  if (nextHour >= HOURS_PER_DAY) {
    nextHour = 0;
    nextDay += 1;
    journalAdditions.push(`День ${nextDay} начался.`);
    nextState = { ...nextState, hour: nextHour, day: nextDay };
    nextState = driftPricesTowardBase(nextState);
    const caravanResult = maybeTriggerCaravan(nextState);
    nextState = caravanResult.state;
    if (caravanResult.journalEntry) journalAdditions.push(caravanResult.journalEntry);
  } else {
    // Караван мог истечь и в течение суток — проверяем каждый час.
    const caravanResult = maybeTriggerCaravan(nextState);
    nextState = caravanResult.state;
    if (caravanResult.journalEntry) journalAdditions.push(caravanResult.journalEntry);
  }

  nextState.lastHourResourceDelta = computeResourceDelta(resourcesBefore, nextState.resources);
  nextState.isGameOver = nextState.day > state.maxDays;
  nextState.journal = journalAdditions.length
    ? [...state.journal, ...journalAdditions.map((text) => ({ day: nextState.day, text }))]
    : state.journal;

  return nextState;
}

/** Продвигает время на N часов подряд (например, целые сутки для кнопки "Завершить день"). */
export function advanceHours(state: GameState, hours: number): GameState {
  let next = state;
  for (let i = 0; i < hours && !next.isGameOver; i += 1) {
    next = advanceHour(next);
  }
  return next;
}

/** Завершить текущие сутки одним действием — продвигает время до полуночи. */
export function advanceToNextDay(state: GameState): GameState {
  const hoursLeft = HOURS_PER_DAY - state.hour;
  return advanceHours(state, hoursLeft === 0 ? HOURS_PER_DAY : hoursLeft);
}
