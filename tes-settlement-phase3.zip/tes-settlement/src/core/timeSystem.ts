import { GameState } from './gameEngine';
import { applyHourlyWork } from '../systems/workSystem';
import { applyHourlySurvivorState } from '../systems/survivorStateSystem';
import { consumeFoodForSettlement, clampResourcesToCapacity, computeResourceDelta } from '../systems/economySystem';
import { driftPricesTowardBase, maybeTriggerCaravan } from '../systems/marketSystem';
import { resolveDueExpeditions } from '../systems/expeditionSystem';
import { maybeRaidSettlement } from '../systems/raidSystem';
import { resolveDueFactionQuests, maybeRevealDarkBrotherhood } from '../systems/factionSystem';
import { maybeTriggerEvent } from '../systems/eventSystem';
import { applyHourlyBonding, applyGriefForDeaths } from '../systems/relationshipSystem';
import { calculateEnding } from '../systems/endingSystem';

export const HOURS_PER_DAY = 24;

export function isNightHour(hour: number): boolean {
  return hour >= 22 || hour < 6;
}

export type TimeOfDay = 'night' | 'morning' | 'day' | 'evening';

export function getTimeOfDay(hour: number): TimeOfDay {
  if (hour >= 22 || hour < 6) return 'night';
  if (hour < 12) return 'morning';
  if (hour < 18) return 'day';
  return 'evening';
}

export const TIME_OF_DAY_LABELS: Record<TimeOfDay, string> = {
  night: 'Ночь',
  morning: 'Утро',
  day: 'День',
  evening: 'Вечер',
};

// Условный календарь кампании — цикл из 6 "месяцев" по 5 дней, повторяется
// для кампаний длиннее 30 дней. Названия оригинальные, в духе атмосферы
// Скайрима, без дословного копирования канонического календаря Тамриэля.
interface SeasonMonth {
  name: string;
  isWinter: boolean;
}

const CALENDAR_CYCLE_DAYS = 30;
const MONTHS: SeasonMonth[] = [
  { name: 'Волчье Утро', isWinter: false },
  { name: 'Начало Морозов', isWinter: true },
  { name: 'Сердце Стужи', isWinter: true },
  { name: 'Пробуждение Земли', isWinter: false },
  { name: 'Летний Зенит', isWinter: false },
  { name: 'Вечерняя Звезда', isWinter: false },
];

export function getSeasonMonth(day: number): SeasonMonth {
  const cyclePosition = (Math.max(1, day) - 1) % CALENDAR_CYCLE_DAYS;
  const monthIndex = Math.floor(cyclePosition / (CALENDAR_CYCLE_DAYS / MONTHS.length));
  return MONTHS[Math.min(monthIndex, MONTHS.length - 1)];
}

export function isWinterDay(day: number): boolean {
  return getSeasonMonth(day).isWinter;
}

/** Продвигает игровое время на один час: производство → потребление еды → лимит
 * склада → голод/здоровье/мораль/болезни → рынок/караваны → хроника. */
export function advanceHour(state: GameState): GameState {
  if (state.isGameOver) return state;
  // Событие с выбором приостанавливает течение времени до решения игрока.
  if (state.pendingEvent) return state;

  const night = isNightHour(state.hour);
  const winter = isWinterDay(state.day);
  const resourcesBefore = state.resources;

  // 1) Работа: производство ресурсов, строительство, эффекты готовки/охраны/лечения.
  const work = applyHourlyWork(state, night, winter);

  // 2) Потребление еды поселением. Зимой еды нужно больше (холода забирают силы).
  const aliveCount = work.survivors.filter((s) => s.isAlive).length;
  const winterFoodMultiplier = winter ? 1.3 : 1;
  const consumption = consumeFoodForSettlement(work.resources, aliveCount, work.foodConsumptionMultiplier * winterFoodMultiplier);

  // 3) Лимит склада — излишки производства теряются.
  const clampResult = clampResourcesToCapacity(consumption.resources, work.buildings);

  // 4) Голод/здоровье/мораль/болезни жителей. Лечебница ("infirmary") снижает риск болезней.
  const nextShortageStreak = consumption.fed ? 0 : state.foodShortageStreak + 1;
  const infirmaryLevel = work.buildings.find((b) => b.type === 'infirmary' && b.isBuilt)?.level ?? 0;
  const diseaseRiskMultiplier = Math.max(0.25, 1 - infirmaryLevel * 0.25);
  const stateTick = applyHourlySurvivorState(work.survivors, night, consumption.fed, nextShortageStreak, diseaseRiskMultiplier);

  let nextHour = state.hour + 1;
  let nextDay = state.day;
  const journalAdditions = [...work.journalAdditions];

  // 5) Экспедиции: разрешаем те, что успели вернуться к этому часу.
  const expeditionsResult = resolveDueExpeditions({
    ...state,
    resources: clampResult.resources,
    buildings: work.buildings,
    survivors: stateTick.survivors,
  });
  journalAdditions.push(...expeditionsResult.journalAdditions);

  // 6) Задания фракций: разрешаем те, что успели вернуться к этому часу.
  const questsResult = resolveDueFactionQuests(expeditionsResult.state);
  journalAdditions.push(...questsResult.journalAdditions);

  // 7) Отношения: совместная работа сближает жителей; гибель бьёт по близким.
  const deceasedNames = new Map<string, string>();
  state.survivors.forEach((s) => deceasedNames.set(s.id, s.name));
  const allDeathIds = [...stateTick.deathIds, ...expeditionsResult.deathIds];
  const bondedSurvivors = applyHourlyBonding(questsResult.state.survivors);
  const griefResult = applyGriefForDeaths(bondedSurvivors, allDeathIds, deceasedNames);
  journalAdditions.push(...griefResult.journalEntries);

  if (nextShortageStreak === 1) {
    journalAdditions.push('В поселении не хватает еды! Жители начинают голодать.');
  }
  stateTick.newlySick.forEach((name) => journalAdditions.push(`${name} заболел(а) от голода.`));
  stateTick.deaths.forEach((name) => journalAdditions.push(`${name} погиб(ла).`));
  Object.entries(clampResult.overflow).forEach(([key, amount]) => {
    if (amount && amount > 3) journalAdditions.push(`Склад переполнен: потеряно ${amount.toFixed(1)} (${key}).`);
  });

  let nextState: GameState = {
    ...state,
    hour: nextHour,
    resources: questsResult.state.resources,
    buildings: questsResult.state.buildings,
    survivors: griefResult.survivors,
    locations: questsResult.state.locations,
    expeditions: questsResult.state.expeditions,
    factions: questsResult.state.factions,
    activeFactionQuests: questsResult.state.activeFactionQuests,
    foodShortageStreak: nextShortageStreak,
  };

  if (nextHour >= HOURS_PER_DAY) {
    nextHour = 0;
    nextDay += 1;
    journalAdditions.push(`День ${nextDay} начался.`);
    nextState = { ...nextState, hour: nextHour, day: nextDay };
    nextState = driftPricesTowardBase(nextState);
    const caravanResult = maybeTriggerCaravan(nextState);
    nextState = caravanResult.state;
    if (caravanResult.journalEntry) journalAdditions.push(caravanResult.journalEntry);

    const raidResult = maybeRaidSettlement(nextState);
    nextState = raidResult.state;
    journalAdditions.push(...raidResult.journalEntries);

    const brotherhoodResult = maybeRevealDarkBrotherhood(nextState);
    nextState = brotherhoodResult.state;
    if (brotherhoodResult.journalEntry) journalAdditions.push(brotherhoodResult.journalEntry);

    const eventResult = maybeTriggerEvent(nextState, winter ? 1.25 : 1);
    nextState = eventResult.state;
    if (eventResult.journalEntry) journalAdditions.push(eventResult.journalEntry);
  } else {
    // Караван мог истечь и в течение суток — проверяем каждый час.
    const caravanResult = maybeTriggerCaravan(nextState);
    nextState = caravanResult.state;
    if (caravanResult.journalEntry) journalAdditions.push(caravanResult.journalEntry);
  }

  nextState.lastHourResourceDelta = computeResourceDelta(resourcesBefore, nextState.resources);
  nextState.isGameOver = nextState.day > state.maxDays;
  if (nextState.isGameOver && !nextState.endingId) {
    nextState.endingId = calculateEnding(nextState);
  }
  nextState.journal = journalAdditions.length
    ? [...state.journal, ...journalAdditions.map((text) => ({ day: nextState.day, text }))]
    : state.journal;

  return nextState;
}

/** Продвигает время на N часов подряд (например, целые сутки для кнопки "Завершить день"). */
export function advanceHours(state: GameState, hours: number): GameState {
  let next = state;
  for (let i = 0; i < hours && !next.isGameOver; i += 1) {
    next = advanceHour(next);
  }
  return next;
}

/** Завершить текущие сутки одним действием — продвигает время до полуночи. */
export function advanceToNextDay(state: GameState): GameState {
  const hoursLeft = HOURS_PER_DAY - state.hour;
  return advanceHours(state, hoursLeft === 0 ? HOURS_PER_DAY : hoursLeft);
}
