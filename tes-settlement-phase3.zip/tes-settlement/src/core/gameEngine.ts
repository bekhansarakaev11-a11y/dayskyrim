import { Survivor } from '../entities/survivor';
import { Building } from '../entities/building';
import { Faction } from '../entities/faction';
import { MapLocation } from '../entities/location';
import { ResourceCost } from '../entities/building';
import { Expedition } from '../entities/expedition';
import { ActiveFactionQuest } from '../entities/quest';
import { GameEvent } from '../entities/event';

export type ScenarioId = 'harsh_winter' | 'peaceful_times' | 'exiles';

export interface JournalEntry {
  day: number;
  text: string;
}

export type TradableResource = 'food' | 'water' | 'wood' | 'stone' | 'ore' | 'iron' | 'ingredients' | 'medicine' | 'fuel';

export interface CaravanState {
  active: boolean;
  arrivedOnDay: number;
  expiresAtHour: number; // абсолютный час с начала кампании (day*24+hour), когда караван уезжает
  priceBonus: number; // напр. 0.2 = продаём на 20% дороже, покупаем на 10% дешевле
}

export interface GameState {
  version: number;
  campaignId: string;
  day: number;
  hour: number; // 0-23, игровой час в текущих сутках
  maxDays: number;
  resources: Required<ResourceCost>;
  survivors: Survivor[];
  buildings: Building[];
  factions: Faction[];
  locations: MapLocation[];
  journal: JournalEntry[];
  isGameOver: boolean;
  endingId: string | null;
  createdAt: number;
  lastSavedAt: number;

  // PHASE 3: экономика
  marketPrices: Record<TradableResource, number>;
  caravan: CaravanState | null;
  foodShortageStreak: number; // сколько часов подряд еды не хватало
  lastHourResourceDelta: Partial<Record<keyof Required<ResourceCost>, number>>;
  expeditions: Expedition[];
  activeFactionQuests: ActiveFactionQuest[];

  // PHASE 8: события и отношения
  pendingEvent: GameEvent | null;

  // PHASE 9+: сценарий старта, влияющий на баланс
  scenarioId: ScenarioId;
  raidChanceMultiplier: number;
  negativeEventChanceMultiplier: number;

  // Block 10.5: приёмы пищи — статус последнего приёма "прилипает" на часы между
  // приёмами, чтобы почасовая механика голода не требовала переписывания.
  lastMealFed: boolean;
}

export const CURRENT_SAVE_VERSION = 8;

export function createInitialResources(): Required<ResourceCost> {
  return { food: 40, water: 30, wood: 25, stone: 10, ore: 8, iron: 5, ingredients: 5, medicine: 5, gold: 20, fuel: 10 };
}

export const BASE_MARKET_PRICES: Record<TradableResource, number> = {
  food: 2, water: 0.5, wood: 1, stone: 1.5, ore: 2, iron: 4, ingredients: 3, medicine: 6, fuel: 1.5,
};

export function createInitialMarketPrices(): Record<TradableResource, number> {
  return { ...BASE_MARKET_PRICES };
}
