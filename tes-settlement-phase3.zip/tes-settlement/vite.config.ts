import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// ВАЖНО: base должен совпадать с именем репозитория на GitHub Pages,
// например для https://username.github.io/tes-settlement-simulator/
// base: '/tes-settlement-simulator/'
// Для локальной разработки и превью используем '/'.
export default defineConfig({
  plugins: [react()],
  base: process.env.GITHUB_PAGES_BASE || '/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    sourcemap: false,
  },
});
